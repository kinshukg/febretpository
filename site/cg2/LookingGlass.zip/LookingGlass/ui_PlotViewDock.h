/********************************************************************************
** Form generated from reading ui file 'PlotViewDock.ui'
**
** Created: Thu 19. Mar 15:13:41 2009
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_PLOTVIEWDOCK_H
#define UI_PLOTVIEWDOCK_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDockWidget>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "QVTKWidget.h"

QT_BEGIN_NAMESPACE

class Ui_PlotViewDock
{
public:
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout;
    QVTKWidget *vtkView;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QComboBox *xAxisBox;
    QLabel *label_2;
    QComboBox *yAxisBox;

    void setupUi(QDockWidget *PlotViewDock)
    {
        if (PlotViewDock->objectName().isEmpty())
            PlotViewDock->setObjectName(QString::fromUtf8("PlotViewDock"));
        PlotViewDock->resize(390, 290);
        PlotViewDock->setFloating(false);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout = new QVBoxLayout(dockWidgetContents);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        vtkView = new QVTKWidget(dockWidgetContents);
        vtkView->setObjectName(QString::fromUtf8("vtkView"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(vtkView->sizePolicy().hasHeightForWidth());
        vtkView->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(vtkView);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetDefaultConstraint);
        label = new QLabel(dockWidgetContents);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(10, 0));
        label->setMaximumSize(QSize(10, 16777215));

        horizontalLayout_2->addWidget(label);

        xAxisBox = new QComboBox(dockWidgetContents);
        xAxisBox->setObjectName(QString::fromUtf8("xAxisBox"));

        horizontalLayout_2->addWidget(xAxisBox);

        label_2 = new QLabel(dockWidgetContents);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(10, 0));
        label_2->setMaximumSize(QSize(10, 16777215));

        horizontalLayout_2->addWidget(label_2);

        yAxisBox = new QComboBox(dockWidgetContents);
        yAxisBox->setObjectName(QString::fromUtf8("yAxisBox"));

        horizontalLayout_2->addWidget(yAxisBox);


        verticalLayout->addLayout(horizontalLayout_2);

        PlotViewDock->setWidget(dockWidgetContents);

        retranslateUi(PlotViewDock);

        QMetaObject::connectSlotsByName(PlotViewDock);
    } // setupUi

    void retranslateUi(QDockWidget *PlotViewDock)
    {
        PlotViewDock->setWindowTitle(QApplication::translate("PlotViewDock", "Plot View", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("PlotViewDock", "X:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("PlotViewDock", "Y:", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(PlotViewDock);
    } // retranslateUi

};

namespace Ui {
    class PlotViewDock: public Ui_PlotViewDock {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLOTVIEWDOCK_H
