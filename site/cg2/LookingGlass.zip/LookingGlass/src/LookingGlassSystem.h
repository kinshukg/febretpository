///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef LOOKINGGLASSSYSTEM_H
#define LOOKINGGLASSSYSTEM_H

///////////////////////////////////////////////////////////////////////////////////////////////////
// Library includes. This is EXTREMELY ugly (should include right headers in each source), but
// really speeds up developement since I don't have to care about including the right stuff everytime
// Standard Library
#include <cmath>
#include <fstream>
#include<limits>
// QT
#include <QtGui/QMainWindow>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QColorDialog>
#include <QtGui/QComboBox>
#include <QtGui/QLabel>
#include <QObject>
#include <QtGui/QColor>
#include <QtGui/QPushButton>
#include <QtGui/QColorDialog>
#include <QtGui/QComboBox>
// VTK
#include <vtkDoubleArray.h>
#include <vtkInteractorStyleTerrain.h>
#include <vtkRenderWindow.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkAlgorithmOutput.h>
#include <vtkActor.h>
#include <vtkAttributeDataToFieldDataFilter.h>
#include <vtkCamera.h>
#include <vtkCubeAxesActor2D.h>
#include <vtkCutter.h>
#include <vtkColorTransferFunction.h>
#include <vtkCommand.h>
#include <vtkClipVolume.h>
#include <vtkImageData.h>
#include <vtkImplicitPlaneRepresentation.h>
#include <vtkImplicitPlaneWidget2.h>
#include <vtkInteractorStyleTerrain.h>
#include <vtkLineWidget.h>
#include <vtkAxes.h>
#include <vtkDataSetMapper.h>
#include <vtkDelaunay2D.h>
#include <vtkFieldData.h>
#include <vtkJPEGReader.h>
#include <vtkImageShiftScale.h>
#include <vtkLookupTable.h>
#include <vtkMarchingCubes.h>
#include <vtkParticleReader.h>
#include <vtkPieceWiseFunction.h>
#include <vtkPlane.h>
#include <vtkPointData.h>
#include <vtkPointPicker.h>
#include <vtkPointSet.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkPolyDataNormals.h>
#include <vtkPolyDataReader.h>
#include <vtkProbeFilter.h>
#include <vtkProperty2D.h>
#include <vtkThreshold.h>
#include <vtkThresholdPoints.h>
#include <vtkPlaneSource.h>
#include <vtkProp.h>
#include <vtkProperty.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkScalarBarActor.h>
#include <vtkShepardMethod.h>
#include <vtkTexture.h>
#include <vtkTextProperty.h>
#include <vtkTransform.h>
#include <vtkTransformFilter.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkVolume.h>
#include <vtkVolumeProperty.h>
#include <vtkVolumeRayCastMapper.h>
#include <vtkColorTransferFunction.h>
#include <vtkVolumeRayCastCompositeFunction.h>
#include <vtkInteractorStyleRubberBand2D.h>

///////////////////////////////////////////////////////////////////////////////////////////////////
// Forward declaration of application classes
class DataSet;
class vtkLGXYPlotActor;
class vtkLGInteractorStyleRubberBand2D;
class Ui_MainWindow;
class VisualizationManager;
class PlotView;
class GeoDataView;
class SliceView;
class VolumeView;

///////////////////////////////////////////////////////////////////////////////////////////////////
#define enum_begin(name) \
	class name { \
	private: \
		name() {}; \
	public: \
	enum Enum { 

#define enum_end }; };

#define vtk_callback(name, obj, method) \
	class name: public vtkCommand { \
	private: \
		obj* mySelf; \
	public: \
		name(obj* self) { mySelf = self; } \
		virtual void Execute(vtkObject* caller, unsigned long, void*) { mySelf->method(); } };

#define QCOLOR_TO_VTK(color) (double)color.red() / 255, \
                             (double)color.green() / 255, \
                             (double)color.blue() / 255

///////////////////////////////////////////////////////////////////////////////////////////////////
void SetInitMessage(const char* msg);

#endif 
