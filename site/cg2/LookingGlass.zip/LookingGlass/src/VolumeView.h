///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef VOLUMEVIEW_H
#define VOLUMEVIEW_H

///////////////////////////////////////////////////////////////////////////////////////////////////
#include "LookingGlassSystem.h"
#include "Ui_VolumeViewDock.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
struct VolumeSectionInfo
{
    bool Used;
    int StartValue;
    int EndValue;
    QColor Color;
    float Opacity;
};

///////////////////////////////////////////////////////////////////////////////////////////////////
class VolumeView: QObject
{
	Q_OBJECT
public:
    /////////////////////////////////////////////////////// Ctor / Dtor.
    VolumeView();
    ~VolumeView();

    /////////////////////////////////////////////////////// Other Methods.
    void Initialize(VisualizationManager* msg);
    void Update();
	void Enable();
	void Disable();
	bool IsEnabled();

public slots:
	void SetEnabled(bool enabled);

protected slots:
    void AddVolumeSectionButtonClick();
    void RemoveVolumeSectionButtonClick();
    void EnableVolumeButtonToggle(bool);
    void VolumeComponentSelectionChanged(int i);
    void VolSectionColorClick();
    void VolSectionEndValueSliderReleased();
    void VolSectionOpacitySliderReleased();
    void VolSectionStartValueSliderReleased();
    void VolumeSectionListItemChanged(QListWidgetItem*, QListWidgetItem*);

protected:
     bool eventFilter(QObject *obj, QEvent *event);

private:
	VolumeSectionInfo* GetFreeVolumeSectionInfo();

private:
    /////////////////////////////////////////////////////// Constants.
    static const int myMaxVolumeSections;
    static const int myVolumeResolution;

	VisualizationManager* myVizMng;
	DataSet* myDataSet;

	// UI.
	QDockWidget* myDock;
	Ui_VolumeViewDock* myUI;
	QAction* myMenuAction;
	bool myEnabled;
    QColor myVolSectionColor;
    QWidget* myVolSectionColorButton;

	// Sonde volume data and display
    int myVisualizedVolumeData;
    VolumeSectionInfo* myVolumeSections;
    vtkImageShiftScale* mySondeVolumeRescaler;
    vtkShepardMethod* mySondeVolumeBuilder;
    vtkVolumeProperty* myVolumeProperty;
    vtkVolumeRayCastMapper* myVolumeMapper;
    vtkColorTransferFunction* myVolumeColorFunction;
    vtkPiecewiseFunction* myVolumeOpacityFunction;
    vtkVolume* myVolume;
};

#endif 
