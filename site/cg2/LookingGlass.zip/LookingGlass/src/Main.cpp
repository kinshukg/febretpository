///////////////////////////////////////////////////////////////////////////////////////////////////
#include <QtGui/QApplication>
#include <QtGui/QSplashScreen>
#include <QtGui/QPixmap>
#include <vtkXMLFileOutputWindow.h>

#include "DataSet.h"
#include "MainWindow.h"
#include "VisualizationManager.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
QSplashScreen* gSplashScreen;

///////////////////////////////////////////////////////////////////////////////////////////////////
void SetInitMessage(const char* msg)
{
	if(gSplashScreen != NULL)
	{
	    gSplashScreen->showMessage(msg, Qt::AlignRight | Qt::AlignBottom, Qt::white);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[])
{
	// Send vtk error output to an XML log file.
    vtkXMLFileOutputWindow* log = vtkXMLFileOutputWindow::New();
    vtkOutputWindow::SetInstance(log);

    QApplication a(argc, argv);

	// Setup splash screen.
    QSplashScreen splashScreen(QPixmap("./resources/splash.png"));
	gSplashScreen = &splashScreen;
    splashScreen.show();
    a.processEvents();

	// Initialize and load the ENDURANCE dataset.
	DataSet* dataSet = new DataSet();
	dataSet->Initialize();

	// Create setup and show the main window. Main window must be created
	// after dataset initialization, since it uses the dataset object.
    MainWindow* w = new MainWindow();

	// Create and initialize the visualization manager.
    VisualizationManager* vizManager = new VisualizationManager();
	vizManager->Initialize(dataSet, w->GetUI(), w);

	// TODO: remove the need of one of those two (w.SetVisualizationManager ?)
	// SetVisualizationManager useless: use VisualizationManager singleton.
	w->Initialize(dataSet, vizManager);

    splashScreen.finish(w);
	gSplashScreen = NULL;

    w->show();
    return a.exec();
}

