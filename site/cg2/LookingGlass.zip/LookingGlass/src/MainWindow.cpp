///////////////////////////////////////////////////////////////////////////////////////////////////
#include "MainWindow.h"
#include "DataSet.h"
#include "Ui_MainWindow.h"
#include "VisualizationManager.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
	myVizMng = NULL;

    myUI = new Ui_MainWindow();
    myUI->setupUi(this);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
MainWindow::~MainWindow()
{
    delete myUI;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::Initialize(DataSet* dataSet, VisualizationManager* manager)
{
    myVizMng = manager;
	myDataSet = dataSet;

    // Setup color buttons.
    myStartColorButton = new QWidget();
    myEndColorButton = new QWidget();
    QPushButton* startLabel = new QPushButton("Start");
    QPushButton* endLabel = new QPushButton("End");

    myStartColorButton->setMinimumSize(20, 20);
    //myStartColorButton->setFlat(true);
    myStartColorButton->setMaximumSize(20, 20);
    myEndColorButton->setMinimumSize(20, 20);
    myEndColorButton->setMaximumSize(20, 20);
    myEndColorButton->setAutoFillBackground(true);
    myStartColorButton->setAutoFillBackground(true);
    //myEndColorButton->setFlat(true);

    myUI->colorMapBox->addWidget(myStartColorButton);
    myUI->colorMapBox->addWidget(startLabel);
    myUI->colorMapBox->addWidget(myEndColorButton);
    myUI->colorMapBox->addWidget(endLabel);

    QObject::connect(startLabel, SIGNAL(clicked()), this, SLOT(StartColorClick()));
    QObject::connect(endLabel, SIGNAL(clicked()), this, SLOT(EndColorClick()));
    QObject::connect(myUI->divergingCheckBox, SIGNAL(clicked()), this, SLOT(UpdateColorTransferFunction()));

    // Setup the mission filter box.
    myUI->showAllMissionButton->setChecked(true);
    myUI->startMissionSlider->setEnabled(false);
    myUI->endMissionSlider->setEnabled(false);

    // Initialize the component visualization colors.
    myStartColor = Qt::blue;
    myEndColor = Qt::red;
    UpdateColorTransferFunction();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::StartColorClick()
{
    myStartColor = QColorDialog::getColor();
    UpdateColorTransferFunction();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::EndColorClick()
{
    myEndColor = QColorDialog::getColor();
    UpdateColorTransferFunction();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::UpdateColorTransferFunction()
{
    QPalette palette;
    palette = myStartColorButton->palette();
    palette.setColor(QPalette::Background, myStartColor);
    myStartColorButton->setPalette(palette);
    palette = myEndColorButton->palette();
    palette.setColor(QPalette::Background, myEndColor);
    myEndColorButton->setPalette(palette);

    myVizMng->SetColorTransferFunction(myStartColor, myEndColor,
            myUI->divergingCheckBox->checkState() == Qt::Checked ? true : false);
    myUI->vtkView->GetRenderWindow()->Render();
}


