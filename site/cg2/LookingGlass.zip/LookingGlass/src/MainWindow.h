///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

///////////////////////////////////////////////////////////////////////////////////////////////////
#include "LookingGlassSystem.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
class DataSet;
class QWidget;
class QListWidgetItem;
class Ui_MainWindow;
class VisualizationManager;

///////////////////////////////////////////////////////////////////////////////////////////////////
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

	void Initialize(DataSet* dataSet, VisualizationManager* manager);
	Ui_MainWindow* GetUI() { return myUI; }

protected slots:

    void EndColorClick();
    void StartColorClick();
    void UpdateColorTransferFunction();

private:
  //void InitBathymetry();

private:
    // User interface.
    Ui_MainWindow* myUI;

    // Visualization Manager instance.
    VisualizationManager* myVizMng;
	DataSet* myDataSet;

    // Main dock stuff.
    QColor myStartColor;
    QColor myEndColor;
    QWidget* myStartColorButton;
    QWidget* myEndColorButton;

};

#endif // MAINWINDOW_H
