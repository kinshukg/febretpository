///////////////////////////////////////////////////////////////////////////////////////////////////
#include "PlotView.h"
#include "vtkLGXYPlotActor.h"
#include "vtkLGInteractorStyleRubberBand2D.h"
#include "DataSet.h"
#include "GeoDataView.h"
#include "VisualizationManager.h"
#include "Ui_MainWindow.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
vtk_callback(DragEndCallback, PlotView, OnDragEnd);

///////////////////////////////////////////////////////////////////////////////////////////////////
PlotView::PlotView()
{
	myDataSet = NULL;
	myEnabled = false;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
PlotView::~PlotView()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::Initialize(VisualizationManager* mng, int index)
{
	myVizMng = mng;
	myDataSet = mng->GetDataSet();

	// Init UI.
	myDock = new QDockWidget(mng->GetMainWindow());
	myUI = new Ui_PlotViewDock();
	myEnabled = false;
	myDock->hide();
	myUI->setupUi(myDock);

	// Setup VTK stuff.
    myPlot = vtkLGXYPlotActor::New();
    myPlot->GetPositionCoordinate()->SetCoordinateSystemToNormalizedViewport();
    myPlot->GetPositionCoordinate()->SetValue(0.0f, 0.0f);
    myPlot->SetPlotPoints(0);
    myPlot->SetWidth(1.0f);
    myPlot->SetHeight(1.0f);

    myPlotRenderer = vtkRenderer::New();
	myPlotRenderer->SetBackground(0.15f, 0.16f, 0.2f);
    myPlotRenderer->AddActor2D(myPlot);
	
	myPlotRenderWindow = myUI->vtkView->GetRenderWindow();
	myInteractorStyle = vtkLGInteractorStyleRubberBand2D::New();
	myInteractorStyle->AddObserver("EndInteractionEvent", new DragEndCallback(this));
	myPlotRenderWindow->GetInteractor()->SetInteractorStyle(myInteractorStyle);

    myPlotDataFilter = vtkAttributeDataToFieldDataFilter::New();

	myUI->vtkView->GetRenderWindow()->AddRenderer(myPlotRenderer);

	// Setup UI
	for(int i = 0; i < myDataSet->GetNumVisualizableFields(); i++)
    {
        myUI->xAxisBox->addItem(myDataSet->GetFieldName(i), i);
        myUI->yAxisBox->addItem(myDataSet->GetFieldName(i), i);
    }
    QObject::connect(myUI->xAxisBox, SIGNAL(currentIndexChanged(int)), this, SLOT(OnAxisFieldChanged(int)));
    QObject::connect(myUI->yAxisBox, SIGNAL(currentIndexChanged(int)), this, SLOT(OnAxisFieldChanged(int)));

	myDock->installEventFilter(this);
	myMenuAction = myVizMng->AddWindowMenuAction(QString("Plot Window %1").arg(index));
	QObject::connect(myMenuAction, SIGNAL(triggered(bool)), this, SLOT(SetEnabled(bool)));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::Enable()
{
	myEnabled = true;
	myVizMng->GetMainWindow()->addDockWidget(Qt::RightDockWidgetArea, myDock);
	myDock->show();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::Disable()
{
	myEnabled = false;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool PlotView::IsEnabled()
{
	return myEnabled;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::SetEnabled(bool enabled)
{
	if(enabled)
	{
		Enable();
	}
	else
	{
		Disable();
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::Update()
{
	int xField = myUI->xAxisBox->currentIndex();
	int yField = myUI->yAxisBox->currentIndex();

	// If I use the same field on both coordinates, the XYPlotActor apparently gets stuck...
	if(xField != yField)
	{
		vtkPointData* dataPoints = myVizMng->GetFilteredValidData()->GetPointData();

		vtkDataArray* xData = dataPoints->GetArray(myDataSet->GetFieldName(xField));
		vtkDataArray* yData = dataPoints->GetArray(myDataSet->GetFieldName(yField));

		vtkFieldData* fieldData = vtkFieldData::New();
		fieldData->AddArray(xData);
		fieldData->AddArray(yData);

		vtkDataObject *dataObject = vtkDataObject::New();
		dataObject->SetFieldData(fieldData);

		myPlot->RemoveAllInputs();
		myPlot->AddDataObjectInput(dataObject);
		myPlot->SetPlotColor(0, 0.8f, 0, 0);
		myPlot->PlotCurveLinesOn();
		myPlot->SetPlotLines(0, 0);
		myPlot->PlotPointsOn();
		myPlot->SetXValuesToValue();
		//myPlot->SetReverseYAxis(1);
		myPlot->SetDataObjectXComponent(0, 0);
		myPlot->SetDataObjectYComponent(0, 1);

		char title[256];
		sprintf(title, "%s vs %s", myDataSet->GetFieldName(yField), myDataSet->GetFieldName(xField));
		myPlot->SetXTitle(title);
		myPlot->SetYTitle("");

		vtkPointData* selectedDataPoints = NULL;
		vtkFieldData* selectedFieldData = NULL;
		vtkDataObject *selectedDataObject = NULL;
		if(myVizMng->GetSelectedData() != NULL)
		{
			vtkPointData* selDataPoints = myVizMng->GetSelectedData()->GetPointData();

			vtkDataArray* xSelData = selDataPoints->GetArray(myDataSet->GetFieldName(xField));
			vtkDataArray* ySelData = selDataPoints->GetArray(myDataSet->GetFieldName(yField));

			selectedDataPoints = myVizMng->GetSelectedData()->GetPointData();
			selectedFieldData = vtkFieldData::New();
			selectedFieldData->AddArray(xSelData);
			selectedFieldData->AddArray(ySelData);
			selectedDataObject = vtkDataObject::New();
			selectedDataObject->SetFieldData(selectedFieldData);
			myPlot->AddDataObjectInput(selectedDataObject);
			myPlot->SetPlotLines(1, 1);
			myPlot->SetPlotColor(1, 0, 1, 1);
			myPlot->SetDataObjectXComponent(1, 0);
			myPlot->SetDataObjectYComponent(1, 1);
		}

		myPlot->SetXRange(myDataSet->GetFieldRange(xField));
		myPlot->SetYRange(myDataSet->GetFieldRange(yField));

		myPlotRenderWindow->Frame();
		myPlotRenderWindow->Render();

		fieldData->Delete();
		dataObject->Delete();

		if(myVizMng->GetSelectedData() != NULL)
		{
			selectedFieldData->Delete();
			selectedDataObject->Delete();
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool PlotView::eventFilter(QObject *obj, QEvent *event)
{
	if (event->type() == QEvent::Close) 
	{
		Disable();
		myMenuAction->setChecked(false);
		return false;
	} 
	else 
	{
		// standard event processing
		return QObject::eventFilter(obj, event);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::OnDragEnd()
{
	int xField = myUI->xAxisBox->currentIndex();
	int yField = myUI->yAxisBox->currentIndex();
	double x1 = myInteractorStyle->StartPosition[0];
	double y1 = myInteractorStyle->StartPosition[1];
	double x2 = myInteractorStyle->EndPosition[0];
	double y2 = myInteractorStyle->EndPosition[1];
	
	if(x1 == x2 && y1 == y2)
	{
		// If action was just a click, clear selected area.
		myVizMng->SetThresholdStage(1, false);
		myVizMng->SetThresholdStage(2, false);
	}
	else
	{
		myPlot->ViewportToPlotCoordinate(myPlotRenderer, x1, y1);
		myPlot->ViewportToPlotCoordinate(myPlotRenderer, x2, y2);
		
		if(x1 > x2)
		{
			double tmp = x1;
			x1 = x2;
			x2 = tmp;
		}
		if(y1 > y2)
		{
			double tmp = y1;
			y1 = y2;
			y2 = tmp;
		}
		myVizMng->SetThresholdStage(1, true, xField, x1, x2);
		myVizMng->SetThresholdStage(2, true, yField, y1, y2);
	}
	myVizMng->Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::OnAxisFieldChanged(int i)
{
	Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void PlotView::OnDockVisibilityChanged(bool visible)
{
	if(!visible)
	{
		Disable();
	}
}
