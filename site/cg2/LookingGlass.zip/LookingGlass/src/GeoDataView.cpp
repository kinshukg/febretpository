///////////////////////////////////////////////////////////////////////////////////////////////////
#include "GeoDataView.h"
#include "DataSet.h"
#include "VisualizationManager.h"
#include "Ui_MainWindow.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
//#define BATHY_TOLERANCE 0.05f
#define BATHY_TOLERANCE 0.005f

///////////////////////////////////////////////////////////////////////////////////////////////////
GeoDataView::GeoDataView()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
GeoDataView::~GeoDataView()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::Initialize(VisualizationManager* mng)
{
    SetInitMessage("Initializing Bathymetry Model...");

	myVizMng = mng;
	myDataSet = mng->GetDataSet();

	// Init UI.
	myDock = new QDockWidget(mng->GetMainWindow());
	myUI = new Ui_GeoDataViewDock();
	myUI->setupUi(myDock);
	Enable();

	vtkRenderer* renderer = mng->GetMainRenderer();

    vtkParticleReader* pReader;
    vtkDelaunay2D* lakeDelaunay;
    vtkPolyDataNormals* lakeNormals;

    pReader = vtkParticleReader::New();
    pReader->SetFileName("./data/bathymetry.txt");
    pReader->SetFileTypeToText();
    pReader->SetDataTypeToDouble();
    pReader->Update();


	// I have to rotate the points to perform a correct delaunay, then rotate them
	// back again.
	// TODO: Refactor & beautify this code a little bit..
	vtkTransform* xfd1 = vtkTransform::New();
	xfd1->RotateX(-90);
	vtkTransformFilter* xform1 = vtkTransformFilter::New();
	xform1->SetInput(pReader->GetOutputDataObject(0));
	xform1->SetTransform(xfd1);

	lakeDelaunay = vtkDelaunay2D::New();
    lakeDelaunay->SetInput(xform1->GetOutputDataObject(0));
    lakeDelaunay->BoundingTriangulationOff();
    lakeDelaunay->SetTolerance(BATHY_TOLERANCE);

	vtkTransform* xfd2 = vtkTransform::New();
	xfd2->RotateX(90);
	vtkTransformFilter* xform2 = vtkTransformFilter::New();
	xform2->SetInput(lakeDelaunay->GetOutputDataObject(0));
	xform2->SetTransform(xfd2);

    lakeNormals = vtkPolyDataNormals::New();
    lakeNormals->SetInput(xform2->GetOutputDataObject(0));
    lakeNormals->SetFeatureAngle(45);
	lakeNormals->Update();

	// black and white lake
	double* depthRange;
	vtkPolyDataMapper* lakeMapper;
	depthRange = lakeNormals->GetOutput()->GetScalarRange();
	vtkColorTransferFunction* lakeLut = vtkColorTransferFunction::New();
	lakeLut->AddRGBPoint(depthRange[1], 0, 0, 0);
	lakeLut->AddRGBPoint(depthRange[0], 0.8, 0.8, 0.8);

    lakeMapper = vtkPolyDataMapper::New();
	lakeMapper->SetInput(lakeNormals->GetOutput());
    lakeMapper->SetLookupTable(lakeLut);
    lakeMapper->SetScalarRange(lakeNormals->GetOutput()->GetScalarRange());
    lakeMapper->ScalarVisibilityOn();
    lakeMapper->SetColorModeToMapScalars();
    lakeMapper->Update();

    myLakeActor = vtkActor::New();
    myLakeActor->SetMapper(lakeMapper);
    myLakeActor->GetProperty()->BackfaceCullingOff();
    myLakeActor->GetProperty()->FrontfaceCullingOff();
    myLakeActor->GetProperty()->SetAmbientColor(0.7, 0.6, 0.6);
    myLakeActor->GetProperty()->SetAmbient(0.4);
	myLakeActor->SetPosition(0, 0, 0);
	myLakeActor->SetScale(1, 7, 1);
	myLakeActor->PickableOff();

    // a renderer and render window
    renderer->AddActor(myLakeActor);

	// Initialize the map overlay.
	myOverlayReader = vtkJPEGReader::New();
	myOverlayReader->SetFileName("./data/overlay.jpg");
	myOverlayTexture = vtkTexture::New();
	myOverlayTexture->SetInput(myOverlayReader->GetOutput());
	myOverlayTexture->InterpolateOn();
	myOverlayPlane = vtkPlaneSource::New();
	myOverlayPlane->SetOrigin(0, 0, 0);
	myOverlayPlane->SetPoint2(0, 0, -1);
	myOverlayPlane->SetPoint1(1, 0, 0);
	myOverlayMapper = vtkPolyDataMapper::New();
	myOverlayMapper->SetInput(myOverlayPlane->GetOutput());
	myOverlayActor = vtkActor::New();
	myOverlayActor->SetMapper(myOverlayMapper);
	myOverlayActor->SetTexture(myOverlayTexture);
	myOverlayActor->SetOrientation(0, 90, 0);
	myOverlayActor->SetScale(-2936, 1, -2284);
	myOverlayActor->SetPosition(1370239, 0, 434526);
	myOverlayActor->GetProperty()->SetOpacity(0);
	myOverlayActor->PickableOff();

	renderer->AddActor(myOverlayActor);
	myVizMng->Render();

	myAxesActor = vtkCubeAxesActor2D::New();
	myAxesActor->SetInput(myDataSet->GetVtkPointData()); 
	myAxesActor->SetCamera(renderer->GetActiveCamera());
	myAxesActor->SetFlyModeToClosestTriad();
	double* xrange = myDataSet->GetFieldRange(DataSetField::X);
	double* yrange = myDataSet->GetFieldRange(DataSetField::Y);
	double* zrange = myDataSet->GetFieldRange(DataSetField::Z);
	myAxesActor->SetRanges(xrange[0] / 100, xrange[1] / 100, -zrange[1], -zrange[0], yrange[0] / 100, yrange[1] / 100);
	myAxesActor->SetXLabel("");
	myAxesActor->SetZLabel("");
	myAxesActor->XAxisVisibilityOn();
	myAxesActor->ZAxisVisibilityOn();
	myAxesActor->SetZLabel("");
	myAxesActor->SetYLabel("Depth(m)");
	myAxesActor->UseRangesOn();
	myAxesActor->GetProperty()->SetColor(1, 1, 1);

	myLakeAxesActor = vtkCubeAxesActor2D::New();
	myLakeAxesActor->SetInput(lakeNormals->GetOutput()); //myLakeTransform->GetOutput());
	myLakeAxesActor->SetCamera(renderer->GetActiveCamera());
	myLakeAxesActor->SetFlyModeToOuterEdges();
	myLakeAxesActor->ZAxisVisibilityOff();
	myLakeAxesActor->GetProperty()->SetColor(1, 1, 0);

	// Setup UI
    myUI->opacitySlider->setValue(100);
    QObject::connect(myUI->opacitySlider, SIGNAL(valueChanged(int)), this, SLOT(OpacitySliderChanged(int)));
	QObject::connect(myUI->overlayOpacitySlider, SIGNAL(valueChanged(int)), this, SLOT(OnOverlayOpacitySliderChanged(int)));
	QObject::connect(myUI->axesButton, SIGNAL(toggled(bool)), this, SLOT(OnAxesButtonToggle(bool)));

	myDock->installEventFilter(this);
	myMenuAction = myVizMng->AddWindowMenuAction(QString("Geo Data"));
	QObject::connect(myMenuAction, SIGNAL(triggered(bool)), this, SLOT(SetEnabled(bool)));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::Enable()
{
	myEnabled = true;
	myVizMng->GetMainWindow()->addDockWidget(Qt::LeftDockWidgetArea, myDock);
	myDock->show();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::Disable()
{
	myEnabled = false;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool GeoDataView::IsEnabled()
{
	return myEnabled;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::SetEnabled(bool enabled)
{
	if(enabled)
	{
		Enable();
	}
	else
	{
		Disable();
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::OpacitySliderChanged(int value)
{
    myLakeActor->GetProperty()->SetOpacity(((double)value) / 100);
	myVizMng->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::SetDepthScale(int value)
{
	myLakeActor->SetScale(1, value, 1);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool GeoDataView::eventFilter(QObject *obj, QEvent *event)
{
	if (event->type() == QEvent::Close) 
	{
		Disable();
		myMenuAction->setChecked(false);
		return false;
	} 
	else 
	{
		// standard event processing
		return QObject::eventFilter(obj, event);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::OnOverlayOpacitySliderChanged(int value)
{
	myOverlayActor->GetProperty()->SetOpacity(((double)value) / 100);
	myVizMng->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void GeoDataView::OnAxesButtonToggle(bool checked)
{
	if(checked)
	{
		myVizMng->GetMainRenderer()->AddActor(myAxesActor);
		//myVizMng->GetMainRenderer()->AddActor(myLakeAxesActor);
	}
	else
	{
		myVizMng->GetMainRenderer()->RemoveActor(myAxesActor);
		//myVizMng->GetMainRenderer()->RemoveActor(myLakeAxesActor);
	}
	myVizMng->Render();
}
