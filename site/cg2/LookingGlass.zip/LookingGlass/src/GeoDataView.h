///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef GEODATAVIEW_H
#define GEODATAVIEW_H

///////////////////////////////////////////////////////////////////////////////////////////////////
#include "LookingGlassSystem.h"
#include "Ui_GeoDataViewDock.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
class DataSet;
class Ui_MainWindow;
class VisualizationManager;
class vtkActor;

///////////////////////////////////////////////////////////////////////////////////////////////////
class GeoDataView: QObject
{
    Q_OBJECT
public:
    /////////////////////////////////////////////////////// Ctor / Dtor.
    GeoDataView();
    ~GeoDataView();

	void Initialize(VisualizationManager* mng);
    void Update();
	void Enable();
	void Disable();
	bool IsEnabled();
    // Sets the bathymetry depth scale.
    void SetDepthScale(int value);
	
public slots:
	void SetEnabled(bool enabled);

protected slots:
    void OpacitySliderChanged(int value);
	void OnOverlayOpacitySliderChanged(int);
	void OnAxesButtonToggle(bool checked);

protected:
     bool eventFilter(QObject *obj, QEvent *event);

private:
	VisualizationManager* myVizMng;
	DataSet* myDataSet;

	// UI.
	QDockWidget* myDock;
	Ui_GeoDataViewDock* myUI;
	QAction* myMenuAction;
	bool myEnabled;

    // VTK stuff
    vtkActor* myLakeActor;
	vtkJPEGReader* myOverlayReader;
	vtkTexture* myOverlayTexture;
	vtkPlaneSource* myOverlayPlane;
	vtkPolyDataMapper* myOverlayMapper;
	vtkActor* myOverlayActor;
	vtkCubeAxesActor2D* myAxesActor;
	vtkCubeAxesActor2D* myLakeAxesActor;
};

#endif 
