///////////////////////////////////////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
//#include <vtkThreshold.h>
#include <vtkThresholdPoints.h>
#include <vtkTransform.h>
#include <vtkTransformFilter.h>

#include "DataSet.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// These macros are used by the Load Method.
#define MAXSTRING 1000
#define SET_FIELD(fieldName, data) \
	myData[numPoints].fieldName = data; \
	if(data > -999) { \
	if (myData[numPoints].fieldName > myFieldRange[DataSetField::fieldName][1]) \
	myFieldRange[DataSetField::fieldName][1] = myData[numPoints].fieldName; \
	if (myData[numPoints].fieldName < myFieldRange[DataSetField::fieldName][0]) \
		myFieldRange[DataSetField::fieldName][0] = myData[numPoints].fieldName; \
	}

///////////////////////////////////////////////////////////////////////////////////////////////////
const float DataSet::SondeDataOrientation = -31.5;
const float DataSet::SondeDataTranslateX = 435440;
const float DataSet::SondeDataTranslateY = 1370500;
const float DataSet::SondeDataTranslateZ = 0;
const float DataSet::SondeDataScaleX = 10;
const float DataSet::SondeDataScaleY = -10;

///////////////////////////////////////////////////////////////////////////////////////////////////
DataSet::DataSet()
{
	myData = NULL;
	myNumItems = 0;
    
	// initialize ranges array.
	for (int i = 0; i < DataSetField::NumFields; i++)
    {
        myFieldRange[i][0] =  10000.0;
        myFieldRange[i][1] =  -10000.0;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
DataSet::~DataSet()
{
	if(myData != NULL)
	{
		delete myData;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void DataSet::InitVtkData()
{
    SetInitMessage("Initializing Sonde Data...");

	// Read sonde data from ustructured grid file.
	// TODO: Change this. fill the unstructured grid from the main dataset.
    mySondeReader = vtkUnstructuredGridReader::New();
    mySondeReader->SetFileName("./data/sonde.vtk");
    mySondeReader->ReadAllScalarsOn();
    mySondeReader->ReadAllColorScalarsOn();
    mySondeReader->Update();

    // Setup a threshold filter to filter out invalid data.
	myTransformDef = vtkTransform::New();
	myTransformDef->Translate(SondeDataTranslateY, SondeDataTranslateZ, SondeDataTranslateX);
	myTransformDef->Scale(SondeDataScaleX, -6, SondeDataScaleY);
	myTransformDef->RotateX(-90);
	myTransformDef->RotateZ(SondeDataOrientation);

	mySondeTransform = vtkTransformFilter::New();
	mySondeTransform->SetInput(mySondeReader->GetOutput());
	mySondeTransform->SetTransform(myTransformDef);
	mySondeTransform->Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
const char* DataSet::GetFieldName(int index)
{
	switch(index)
	{
	case DataSetField::GridX:
		return "GridX";
	case DataSetField::GridY:
		return "GridY";
	case DataSetField::X:
		return "X";
	case DataSetField::Y:
		return "Y";
	case DataSetField::Depth:
		return "Depth_(m)_Corrected";
	case DataSetField::Z:
		return "Z";
	case DataSetField::CDOM:
		return "CDOM_(ru)";
	case DataSetField::ChlA:
		return "Chl-a_(ru)";
	case DataSetField::Conductivity:
		return "Conductivity_(S/m)";
	case DataSetField::Day:
		return "Day";
	case DataSetField::DCond:
		return "dcond/dz";
	case DataSetField::DTemp:
		return "dtemp/dz";
	case DataSetField::Hour:
		return "Hour";
	case DataSetField::Minutes:
		return "Minutes";
	case DataSetField::Month:
		return "Month";
	case DataSetField::Par:
		return "PAR_(umol/m^2*s^1)";
	case DataSetField::Ph:
		return "pH";
	case DataSetField::REDOX:
		return "REDOX_(meV)";
	case DataSetField::ScanId:
		return "Scan_Number";
	case DataSetField::Seconds:
		return "Seconds";
	case DataSetField::Temperature:
		return "Temperature_(C)";
	case DataSetField::Turbidity:
		return "Turbidity_(ru)";
	case DataSetField::Year:
		return "Year";
	}
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
double* DataSet::GetFieldRange(int index)
{
	return myFieldRange[index];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
DataItem* DataSet::GetItems()
{
	return myData;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void DataSet::Initialize()
{
	Load();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int DataSet::GetNumVisualizableFields()
{
	// TODO: This is a nasty hardcoded value.
	return 11;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int DataSet::GetNumItems()
{
	return myNumItems;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
vtkPointSet* DataSet::GetVtkPointData()
{
	return mySondeTransform->GetOutput();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void DataSet::Load()
{
    FILE* pointFile = NULL;
    char line[MAXSTRING];
	int numPoints = 0;

    float x1, y1, z1;
    float d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11;
    int i, j, k, l, m;

    // added for the final data format
    float z_corrected;

    char datetime[MAXSTRING];
    char date[20];
    char time[20];

    char* date2;
    char* date3;
    char* time1;
    char* time2;
    char* time3;

    int t1, t2, t3;
    int dat1, dat2, dat3;

	// Count the number of items.
    pointFile = fopen("./data/sondeData.csv", "r");
    while (!feof(pointFile))
    {
        fgets(line, MAXSTRING, pointFile);
		myNumItems++;
	}
	// Ignore first line.
	myNumItems--;
	fclose(pointFile);

	// Allocate data.
	myData = new DataItem[myNumItems];


	// Start reading data.
	pointFile = fopen("./data/sondeData.csv", "r");

    // process the first line which is a header
    fgets(line, MAXSTRING, pointFile);
    while (!feof(pointFile))
    {
        fgets(line, MAXSTRING, pointFile);

        // X, Y, Depth (m) uncorrect, Depth (m) Corrected,
        // Conductivity (S/m), Temperature (C ), CDOM (ru), Chl-a (ru), REDOX (meV), PAR (umol/m^2*s^1),pH, Turbidity (ru),
        // Scan number, dtemp/dz, dcond/dz
        // mm/dd/yyyy, hh:mm:ss,
        sscanf(line, "%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%s",
            &x1, &y1, &z1, &z_corrected,
            &d1, &d2, &d3, &d4, &d5, &d6, &d7, &d8, &d9, &d10, &d11,
            datetime);

		// Data.
		SET_FIELD(Conductivity, d1);
		SET_FIELD(Temperature, d2);
		SET_FIELD(CDOM, d3);
		SET_FIELD(ChlA, d4);
		SET_FIELD(REDOX, d5);
		SET_FIELD(Par, d6);
		SET_FIELD(Ph, d7);
		SET_FIELD(Turbidity, d8);
		SET_FIELD(ScanId, d9);
		SET_FIELD(DTemp, d10);
		SET_FIELD(DCond, d11);
		SET_FIELD(Depth, z_corrected);

		// Grid coordinates.
		SET_FIELD(GridX, x1);
		SET_FIELD(GridY, y1);

		// Generic uniform point coordinates.
		SET_FIELD(X, (x1 * 100));
		SET_FIELD(Y, (y1 * 100));
		SET_FIELD(Z, z_corrected);

		// Time.
        time1 = strchr(datetime, ',');
        sscanf(datetime, "%d/%d/%d", &dat1, &dat2, &dat3);
        sscanf(time1+1, "%d:%d:%d", &t1, &t2, &t3);

        if (dat1 == 0) // if we do not have any valid info on the date and time
        {
			SET_FIELD(Day, 16);
			SET_FIELD(Month, 12);
			SET_FIELD(Year, 2008);
        }
        else
        {
			SET_FIELD(Day, dat2);
			SET_FIELD(Month, dat1);
			SET_FIELD(Year, dat3);
        }

		SET_FIELD(Minutes, t2);
		SET_FIELD(Seconds, t3);
		SET_FIELD(Hour, t1);

        numPoints++;
    }

    fclose(pointFile);

	InitVtkData();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void DataSet::SetDepthScale(int value)
{
	myTransformDef->Identity();
	myTransformDef->Translate(
		SondeDataTranslateY, 
		(myFieldRange[DataSetField::Z][0] * value), 
		SondeDataTranslateX);
	myTransformDef->Scale(SondeDataScaleX, -value, SondeDataScaleY);
	myTransformDef->RotateX(-90);
	myTransformDef->RotateZ(SondeDataOrientation);
}
