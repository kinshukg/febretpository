///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef DATASET_H
#define DATASET_H

///////////////////////////////////////////////////////////////////////////////////////////////////
#include "LookingGlassSystem.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
#define INVALID_VALUE -999

///////////////////////////////////////////////////////////////////////////////////////////////////
//class vtkPolyData;
class vtkPointSet;
class vtkUnstructuredGrid;
class vtkUnstructuredGridReader;
class vtkTransform;
class vtkTransformFilter;
class vtkThresholdPoints;

///////////////////////////////////////////////////////////////////////////////////////////////////
enum_begin(DataSetFilter)
	NoFilter,
	MissionFilter
enum_end;

///////////////////////////////////////////////////////////////////////////////////////////////////
enum_begin(DataSetField)
	// Visualizable fields. 
	Conductivity,
	Temperature,
	CDOM,
	ChlA,
	REDOX,
	Par,
	Ph,
	Turbidity,
	DTemp,
	DCond,
	Depth,

	// Filtering fields. 
	GridX,
	GridY,
	X,
	Y,
	Z,
	ScanId,
	Month,
	Day,
	Year,
	Hour,
	Minutes,
	Seconds,

	NumFields
enum_end;

///////////////////////////////////////////////////////////////////////////////////////////////////
// Represents a single dataset item. 
struct DataItem
{
	int GridX;
	int GridY;
	int X;
	int Y;
	double Z;
	double Conductivity;
	double Temperature;
	double CDOM;
	double ChlA;
	double REDOX;
	double Par;
	double Ph;
	double Turbidity;
	double DTemp;
	double DCond;
	double Depth;
	int ScanId;
	int Month;
	int Day;
	int Year;
	int Hour;
	int Minutes;
	int Seconds;
};

///////////////////////////////////////////////////////////////////////////////////////////////////
class DataSet
{
public:
	/////////////////////////////////////////////////////// Ctor Dtor.
	DataSet();
	~DataSet();

	/////////////////////////////////////////////////////// Instance methods.
	void Initialize();
	const char* GetFieldName(int index);
	double* GetFieldRange(int index);
	DataItem* GetItems();
	int GetNumItems();
	int GetNumVisualizableFields();
	vtkPointSet* GetVtkPointData();
	void SetDepthScale(int value);

	// TODO: TEMPORARY
	//vtkUnstructuredGridReader* GetSondeReader() { return mySondeReader; }
	//vtkThresholdPoints* GetInvalidPointThreshold() { return myInvalidPointThreshold; }
	vtkTransformFilter* GetSondeTransform() { return mySondeTransform; }

public:
	/////////////////////////////////////////////////////// Constants.
	static const int InvalidValue = -999;
    static const float SondeDataOrientation;
    static const float SondeDataTranslateX;
    static const float SondeDataTranslateY;
    static const float SondeDataTranslateZ;
    static const float SondeDataScaleX;
    static const float SondeDataScaleY;

private:
	void Load();
	void InitVtkData();

private:
	/////////////////////////////////////////////////////// Singleton stuff.
	//static DataSet* myInstance;

	/////////////////////////////////////////////////////// Data.
	double myFieldRange[DataSetField::NumFields][2];
	DataItem* myData;
	int myNumItems;

	/////////////////////////////////////////////////////// Vtk.
	vtkUnstructuredGridReader* mySondeReader;
	vtkTransform* myTransformDef;
	vtkTransformFilter* mySondeTransform;

};

#endif 
