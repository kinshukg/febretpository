///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef PLOTVIEW_H
#define PLOTVIEW_H

///////////////////////////////////////////////////////////////////////////////////////////////////
#include "LookingGlassSystem.h"
#include "Ui_PlotViewDock.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
class PlotView: QObject
{
	Q_OBJECT
public:
    /////////////////////////////////////////////////////// Ctor / Dtor.
    PlotView();
    ~PlotView();

    /////////////////////////////////////////////////////// Other Methods.
    void Initialize(VisualizationManager* msg, int index);
    void Update();
	void Enable();
	void Disable();
	bool IsEnabled();
    void OnDragStart();
    void OnDragEnd();
    void OnDragMove();

public slots:
	void SetEnabled(bool enabled);

protected slots:
    void OnAxisFieldChanged(int i);
	void OnDockVisibilityChanged(bool visible);

protected:
     bool eventFilter(QObject *obj, QEvent *event);

private:
	VisualizationManager* myVizMng;
	DataSet* myDataSet;
	bool myEnabled;

	// UI.
	QDockWidget* myDock;
	Ui_PlotViewDock* myUI;
	QAction* myMenuAction;

    // Plot stuff.
    vtkRenderWindow* myPlotRenderWindow;
    vtkRenderer* myPlotRenderer;
    vtkAttributeDataToFieldDataFilter* myPlotDataFilter;
    vtkLGXYPlotActor* myPlot;
	vtkLGInteractorStyleRubberBand2D* myInteractorStyle;
};

#endif 
