///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef VISUALIZATIONMANAGER_H
#define VISUALIZATIONMANAGER_H

///////////////////////////////////////////////////////////////////////////////////////////////////
#include "LookingGlassSystem.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
#define MAX_PLOT_VIEWS 4
#define MAX_THRESHOLD_STAGES 4

///////////////////////////////////////////////////////////////////////////////////////////////////
class VisualizationManager: QObject
{
	Q_OBJECT
public:
    /////////////////////////////////////////////////////// Ctor / Dtor.
    VisualizationManager();
    ~VisualizationManager();

    /////////////////////////////////////////////////////// Other Methods.
	// Redraws the content of the main render window.
	void Render();
	// Updates the rendering pipeline and refreshed all the visualiztions.
	void Update();
	// Adds a 3D widget to the main render window.
	void Add3DWidget(vtkInteractorObserver* widget);
	// Gets the renderer associated to the main render window.
	vtkRenderer* GetMainRenderer();
	DataSet* GetDataSet();
	// This one should be removed if every view manages its own dock object.
	Ui_MainWindow* GetUI();
	// Gets the unique instance of the main application window.
	QMainWindow* GetMainWindow();
	int GetSelectedField();
	
	// Gets the set of filtered datapoints
	vtkPointSet* GetFilteredData(int stage); 
	// Gets the set of filtered and valid datapoints
	vtkPointSet* GetFilteredValidData(); 
	// Gets the set of currently selected datapoints.
	vtkPointSet* GetSelectedData(); 

	void OnUserEvent();

    void Initialize(DataSet* dataSet, Ui_MainWindow* ui, QMainWindow* win);
    // Sets the render window that will be used as the main visualization viewport.
    void SetRenderWindow(vtkRenderWindow* renderWindow) {myRenderWindow = renderWindow;}
    void SetColorTransferFunction(QColor start, QColor end, bool diverging);
    void SetMissionRange(int startDay, int endDay);
    void SetThresholdStage(int index, bool enabled, int field = 0, double min = 0, double max = 0);
	// Clears the sonde drop selection.
	void ClearSelection();
	QAction* AddWindowMenuAction(QString name);

protected slots:
	void OnSelectedFieldChanged(int i);
    void OnShowMissionButtonToggle(bool);
    void OnDepthScaleSliderChanged();
    void OnEndMissionSliderChange(int value);
    void OnStartMissionSliderChange(int value);

private:
    void UpdateMissionRange();
    void InitSonde();
    void InitUI();
    void InitPicking();
    //void InitVolumeMapper();
	void SetSelectedSondeDrop(double X, double Y);

private:
	// Dataset
	DataSet* myDataSet;

	// Reference to UI.
	QMainWindow* myMainWindow;
	Ui_MainWindow* myUI;

	// Views
	GeoDataView* myGeoDataView;
	PlotView* myPlotView[MAX_PLOT_VIEWS];
	SliceView* mySliceView;
	VolumeView* myVolumeView;

	// Filtering stuff.
    vtkThresholdPoints* myThresholdStage[MAX_THRESHOLD_STAGES];
	vtkThresholdPoints* myInvalidPointThreshold;
    vtkThresholdPoints* myXThreshold;
    vtkThresholdPoints* myYThreshold;

    // Main color scale objects.
    vtkScalarBarActor* myScalarBar;
    vtkColorTransferFunction* myScalarBarColorFunction;

	// Selected point data and representation.
    vtkDataSetMapper* mySelectionMapper;
    vtkActor* mySelectionActor;
	int mySelectedX;
	int mySelectedY;

	// Main sonde data view.
    vtkDataSetMapper* mySondeMapper;
    vtkActor* mySondeActor;

    vtkRenderer* myRenderer;
    vtkRenderWindow* myRenderWindow;
    int mySelectedField;

	// Picking.
	vtkPointPicker* myPicker;

    // Color transfer function
    QColor myStartColor;
    QColor myEndColor;
    bool myDiverging;
    vtkColorTransferFunction* myColorFunction;
};

#endif // MAINWINDOW_H
