///////////////////////////////////////////////////////////////////////////////////////////////////
#include "SliceView.h"
#include "DataSet.h"
#include "GeoDataView.h"
#include "VisualizationManager.h"
#include "Ui_MainWindow.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
//#define RESAMPLE_RESOLUTION 50
//#define FAST_SLICE

///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef FAST_SLICE
vtk_callback(PlaneProbeCallback, SliceView, Update);
#else
vtk_callback(BeginInteractionCallback, SliceView, OnBeginInteraction);
vtk_callback(EndInteractionCallback, SliceView, OnEndInteraction);
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
SliceView::SliceView()
{
	myDataSet = NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
SliceView::~SliceView()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::Initialize(VisualizationManager* mng)
{
	myVizMng = mng;
	myDataSet = mng->GetDataSet();

	// Initialize the UI.
	myDock = new QDockWidget(mng->GetMainWindow());
	mng->GetMainWindow()->addDockWidget(Qt::LeftDockWidgetArea, myDock);
	myUI = new Ui_SliceViewDock();
	myUI->setupUi(myDock);

	vtkPointSet* grid = myDataSet->GetVtkPointData();

    mySondeVolumeBuilder = vtkShepardMethod::New();
    mySondeVolumeBuilder->SetInput(grid);
	mySondeVolumeBuilder->SetModelBounds(grid->GetBounds());
    mySondeVolumeBuilder->SetSampleDimensions(10, 50, 10);
    mySondeVolumeBuilder->SetMaximumDistance(0.1f);
    mySondeVolumeBuilder->SetNullValue(999.0f);
	mySondeVolumeBuilder->Update();

	// Setup the implicit plane representation and widget
    /*bounds[0] -= 1000;
    bounds[1] += 300;
    bounds[2] -= 500;
    bounds[3] += 500;
    bounds[4] -= 200;
    bounds[5] += 200;*/
	double* bounds =  grid->GetBounds();
    myPlaneRep = vtkImplicitPlaneRepresentation::New();
	myPlaneRep->DrawPlaneOff();
	myPlaneRep->DragableOff();
	myPlaneRep->TubingOff();
	myPlaneRep->OutsideBoundsOn();
    myPlaneRep->PlaceWidget(bounds);
    myPlaneRep->SetPlaceFactor(1.0f);
    myPlaneRep->SetNormal(1.0f, 1.0f, 0.0f);
    myPlaneRep->SetOrigin(
		(bounds[0] + bounds[1]) / 2,
		(bounds[2] + bounds[3]) / 2,
		(bounds[4] + bounds[5]) / 2);
	myPlaneRep->GetOutlineProperty()->SetOpacity(0.0f);
	myPlaneRep->GetEdgesProperty()->SetOpacity(0.0f);

    myPlaneWidget = vtkImplicitPlaneWidget2::New();
    myPlaneWidget->SetRepresentation(myPlaneRep);
	myVizMng->Add3DWidget(myPlaneWidget);

#ifndef FAST_SLICE
	myPlaneWidget->AddObserver("InteractionEvent", new PlaneProbeCallback(this));
#else
	myPlaneWidget->AddObserver("StartInteractionEvent", new BeginInteractionCallback(this));
	myPlaneWidget->AddObserver("EndInteractionEvent", new EndInteractionCallback(this));
#endif

	// Setup the plane source and probe
	//myPlaneSource = vtkPlaneSource::New();
	//myPlaneSource->SetResolution(50, 50);

    // Setup a threshold filter to filter out invalid data.
    vtkThreshold*  invalidPointThreshold = vtkThreshold::New();
	invalidPointThreshold->SetInput(mySondeVolumeBuilder->GetOutput());
    invalidPointThreshold->ThresholdByLower(990);
	invalidPointThreshold->Update();

	//myPlaneProbe = vtkProbeFilter::New();
	myPlaneProbe = vtkCutter::New();
	myPlaneProbe->SetInput(invalidPointThreshold->GetOutput());

	// Setup the probe mapper and actor.
    myProbeMapper = vtkDataSetMapper::New();
    myProbeMapper->SetInput(myPlaneProbe->GetOutput());
	myProbeMapper->ScalarVisibilityOn();
    myProbeMapper->Update();

    myProbeActor = vtkActor::New();
    myProbeActor->SetMapper(myProbeMapper);
    myProbeActor->GetProperty()->BackfaceCullingOff();
    myProbeActor->GetProperty()->FrontfaceCullingOff();
    myProbeActor->GetProperty()->SetAmbientColor(0.7, 0.7, 0.7);
	myProbeActor->GetProperty()->SetAmbient(0.4);
	myProbeActor->SetEnableLighting(0);

    Update();

	myDock->installEventFilter(this);
	myMenuAction = myVizMng->AddWindowMenuAction(QString("Slice View"));
	QObject::connect(myMenuAction, SIGNAL(triggered(bool)), this, SLOT(SetEnabled(bool)));

	// UI
    QObject::connect(myUI->sliceEnableButton, SIGNAL(toggled(bool)), this, SLOT(OnSliceEnableButtonToggle(bool)));
    QObject::connect(myUI->lightEnableButton, SIGNAL(toggled(bool)), this, SLOT(OnLightEnableButtonToggle(bool)));
	QObject::connect(myUI->normalXButton, SIGNAL(clicked()), this, SLOT(OnNormalXButtonClick()));
	QObject::connect(myUI->normalYButton, SIGNAL(clicked()), this, SLOT(OnNormalYButtonClick()));
	QObject::connect(myUI->normalZButton, SIGNAL(clicked()), this, SLOT(OnNormalZButtonClick()));
	// bind_button_toggle(sliceEnableButton);

	// actor_visiblity_toggle(sliceEnableButton, myProbeActor);
	// actor_opacity_toggle(sliceEnableButton, myProbeActor);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::SetDepthScale(int value)
{
	vtkPointSet* grid = myDataSet->GetVtkPointData();
	mySondeVolumeBuilder->SetModelBounds(grid->GetBounds());
	mySondeVolumeBuilder->Update();
	double* bounds = grid->GetBounds();
	myPlaneRep->PlaceWidget(bounds);
	Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::Enable()
{
	myEnabled = true;
	myVizMng->GetMainWindow()->addDockWidget(Qt::LeftDockWidgetArea, myDock);
	myDock->show();
	Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::Disable()
{
	myEnabled = false;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool SliceView::IsEnabled()
{
	return myEnabled;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::SetEnabled(bool enabled)
{
	if(enabled)
	{
		Enable();
	}
	else
	{
		Disable();
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::OnSliceEnableButtonToggle(bool enabled)
{
	if(enabled)
	{
		myVizMng->GetMainRenderer()->AddActor(myProbeActor);
	}
	else
	{
		myVizMng->GetMainRenderer()->RemoveActor(myProbeActor);
	}
	myVizMng->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::OnLightEnableButtonToggle(bool enabled)
{
	if(enabled)
	{
		myProbeActor->SetEnableLighting(1);
	}
	else
	{
		myProbeActor->SetEnableLighting(0);
	}
	Update();
	myVizMng->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::Update()
{
    vtkPlane* pd = vtkPlane::New();

	myPlaneRep->GetPlane(pd);

	myPlaneProbe->SetCutFunction(pd);
    myProbeMapper->Update();

    pd->Delete();

	myVizMng->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::OnBeginInteraction()
{
	myProbeActor->VisibilityOff();
	myPlaneRep->DrawPlaneOn();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::OnEndInteraction()
{
	myProbeActor->VisibilityOn();
	myPlaneRep->DrawPlaneOff();
	Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::SetColorFunction(vtkColorTransferFunction* fx)
{
	myProbeMapper->SetLookupTable(fx);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::SetVisualizedField(int index)
{
	// Force an update of sonde transform BEFORE setting the active scalars on the output object.
	// If I set the active scalars before forcing the update, the active scalars will be reset by the
	// update itself.
	// NOTE: I have to force an update here because changing the active scalars on point data does not
	// trigger the main dataset modified flag, and the subsequent volume update will do nothing.
	myDataSet->GetSondeTransform()->Modified();
	myDataSet->GetSondeTransform()->Update();
	myDataSet->GetSondeTransform()->GetOutput()->GetPointData()->SetActiveScalars(myDataSet->GetFieldName(index));
	
	mySondeVolumeBuilder->Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool SliceView::eventFilter(QObject *obj, QEvent *event)
{
	if (event->type() == QEvent::Close) 
	{
		Disable();
		myMenuAction->setChecked(false);
		return false;
	} 
	else 
	{
		// standard event processing
		return QObject::eventFilter(obj, event);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::OnNormalXButtonClick()
{
    myPlaneRep->SetNormal(1.0f, 0.0f, 0.0f);
	Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::OnNormalYButtonClick()
{
    myPlaneRep->SetNormal(0.0f, 1.0f, 0.0f);
	Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void SliceView::OnNormalZButtonClick()
{
    myPlaneRep->SetNormal(0.0f, 0.0f, 1.0f);
	Update();
}

