/****************************************************************************
** Meta object code from reading C++ file 'VolumeView.h'
**
** Created: Thu 19. Mar 15:13:35 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "VolumeView.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'VolumeView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_VolumeView[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      20,   12,   11,   11, 0x0a,
      37,   11,   11,   11, 0x09,
      67,   11,   11,   11, 0x09,
     100,   11,   11,   11, 0x09,
     133,  131,   11,   11, 0x09,
     170,   11,   11,   11, 0x09,
     193,   11,   11,   11, 0x09,
     228,   11,   11,   11, 0x09,
     262,   11,   11,   11, 0x09,
     301,  299,   11,   11, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_VolumeView[] = {
    "VolumeView\0\0enabled\0SetEnabled(bool)\0"
    "AddVolumeSectionButtonClick()\0"
    "RemoveVolumeSectionButtonClick()\0"
    "EnableVolumeButtonToggle(bool)\0i\0"
    "VolumeComponentSelectionChanged(int)\0"
    "VolSectionColorClick()\0"
    "VolSectionEndValueSliderReleased()\0"
    "VolSectionOpacitySliderReleased()\0"
    "VolSectionStartValueSliderReleased()\0"
    ",\0VolumeSectionListItemChanged(QListWidgetItem*,QListWidgetItem*)\0"
};

const QMetaObject VolumeView::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_VolumeView,
      qt_meta_data_VolumeView, 0 }
};

const QMetaObject *VolumeView::metaObject() const
{
    return &staticMetaObject;
}

void *VolumeView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_VolumeView))
        return static_cast<void*>(const_cast< VolumeView*>(this));
    return QObject::qt_metacast(_clname);
}

int VolumeView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: SetEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: AddVolumeSectionButtonClick(); break;
        case 2: RemoveVolumeSectionButtonClick(); break;
        case 3: EnableVolumeButtonToggle((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: VolumeComponentSelectionChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: VolSectionColorClick(); break;
        case 6: VolSectionEndValueSliderReleased(); break;
        case 7: VolSectionOpacitySliderReleased(); break;
        case 8: VolSectionStartValueSliderReleased(); break;
        case 9: VolumeSectionListItemChanged((*reinterpret_cast< QListWidgetItem*(*)>(_a[1])),(*reinterpret_cast< QListWidgetItem*(*)>(_a[2]))); break;
        default: ;
        }
        _id -= 10;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
