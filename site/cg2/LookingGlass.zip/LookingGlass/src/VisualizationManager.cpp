///////////////////////////////////////////////////////////////////////////////////////////////////
#include "VisualizationManager.h"
#include "DataSet.h"
#include "GeoDataView.h"
#include "Ui_MainWindow.h"
#include "PlotView.h"
#include "SliceView.h"
#include "VolumeView.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
vtk_callback(UserEventCallback, VisualizationManager, OnUserEvent);

///////////////////////////////////////////////////////////////////////////////////////////////////
VisualizationManager::VisualizationManager()
{
	myDataSet = NULL;
    myRenderWindow = NULL;
	mySelectedField = 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VisualizationManager::~VisualizationManager()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::InitUI()
{
    // Setup the components box.
	for(int i = 0; i < myDataSet->GetNumVisualizableFields(); i++)
    {
        myUI->componentBox->addItem(myDataSet->GetFieldName(i), i);
    }

	// Setup UI
    myUI->depthScaleSlider->setValue(6);
    QObject::connect(myUI->depthScaleSlider, SIGNAL(sliderReleased()), this, SLOT(OnDepthScaleSliderChanged()));
    QObject::connect(myUI->componentBox, SIGNAL(currentIndexChanged(int)), this, SLOT(OnSelectedFieldChanged(int)));
	
	// Setup the mission filter UI.
    myUI->startMissionSlider->setRange(10, 17);
    myUI->endMissionSlider->setRange(10, 17);
    QObject::connect(myUI->showAllMissionButton, SIGNAL(toggled(bool)), this, SLOT(OnShowMissionButtonToggle(bool)));
    QObject::connect(myUI->showSingleMissionButton, SIGNAL(toggled(bool)), this, SLOT(OnShowMissionButtonToggle(bool)));
    QObject::connect(myUI->showIntervalMissionButton, SIGNAL(toggled(bool)), this, SLOT(OnShowMissionButtonToggle(bool)));
    QObject::connect(myUI->startMissionSlider, SIGNAL(valueChanged(int)), this, SLOT(OnStartMissionSliderChange(int)));
    QObject::connect(myUI->endMissionSlider, SIGNAL(valueChanged(int)), this, SLOT(OnEndMissionSliderChange(int)));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::SetSelectedSondeDrop(double X, double Y)
{
	mySelectedX = X;
	mySelectedY = Y;

	myXThreshold->ThresholdBetween(X - 0.1f, X + 0.1f);
	myYThreshold->ThresholdBetween(Y - 0.1f, Y + 0.1f);

	mySondeActor->GetProperty()->SetPointSize(2.0f);
	mySelectionMapper->Update();

	for(int i = 0; i < MAX_PLOT_VIEWS; i++)
	{
		if(myPlotView[i]->IsEnabled())
		{
			myPlotView[i]->Update();
		}
	}

	myUI->vtkView->GetRenderWindow()->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::ClearSelection()
{
	mySelectedX = -1;
	mySelectedY = -1;

	myXThreshold->ThresholdBetween(-999, -999);
	myYThreshold->ThresholdBetween(-999, -999);

	mySondeActor->GetProperty()->SetPointSize(6.0f);
	mySelectionMapper->Update();

	for(int i = 0; i < MAX_PLOT_VIEWS; i++)
	{
		if(myPlotView[i]->IsEnabled())
		{
			myPlotView[i]->Update();
		}
	}

	myUI->vtkView->GetRenderWindow()->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
QAction* VisualizationManager::AddWindowMenuAction(QString name)
{
	QAction* action = myUI->menuWindows->addAction(name);
	action->setCheckable(true);
	return action;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::UpdateMissionRange()
{
    if(myUI->showAllMissionButton->isChecked())
    {
        SetMissionRange(0, 100);
    }
    else if(myUI->showSingleMissionButton->isChecked())
    {
        SetMissionRange(
                myUI->startMissionSlider->value(),
                myUI->startMissionSlider->value());
    }
    else
    {
        SetMissionRange(
                myUI->startMissionSlider->value(),
                myUI->endMissionSlider->value());
    }
    myUI->vtkView->GetRenderWindow()->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
vtkPointSet* VisualizationManager::GetFilteredData(int stage) 
{ 
	return myThresholdStage[stage]->GetOutput(); 
}

///////////////////////////////////////////////////////////////////////////////////////////////////
vtkPointSet* VisualizationManager::GetFilteredValidData() 
{ 
	myInvalidPointThreshold->Update();
	return myInvalidPointThreshold->GetOutput(); 
}

///////////////////////////////////////////////////////////////////////////////////////////////////
vtkPointSet* VisualizationManager::GetSelectedData()
{
	if(mySelectedX != -1 && mySelectedY != -1)
	{
		return myYThreshold->GetOutput();
	} 
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::Initialize(DataSet* dataSet, Ui_MainWindow* ui, QMainWindow* win)
{
	myDataSet = dataSet;
	myUI = ui;
	myMainWindow = win;

	// Initialize threshold stage fielters.
	for(int i = 0; i < MAX_PLOT_VIEWS; i++)
	{
		myThresholdStage[i] = vtkThresholdPoints::New();
		if(i == 0)
		{
			myThresholdStage[0]->SetInput(myDataSet->GetVtkPointData());
		}
		else
		{
			myThresholdStage[i]->SetInput(myThresholdStage[i - 1]->GetOutput());
		}
		SetThresholdStage(i, false);
	}

	// Setup a threshold filter to filter out invalid data.
    myInvalidPointThreshold = vtkThresholdPoints::New();
	myInvalidPointThreshold->SetInput(myThresholdStage[MAX_THRESHOLD_STAGES - 1]->GetOutput());
    myInvalidPointThreshold->ThresholdByUpper(-990);
	myInvalidPointThreshold->Update();

	// Setup the main render window
	myRenderer = vtkRenderer::New();
	myRenderer->SetBackground(0.15f, 0.16f, 0.2f);
	//myRenderer->GetActiveCamera()->SetParallelProjection(1);
	myRenderWindow = myUI->vtkView->GetRenderWindow();
	myRenderWindow->AddRenderer(myRenderer);

    InitSonde();
	
	// Initialize the view objects.
	myGeoDataView = new GeoDataView();
	myGeoDataView->Initialize(this);

	for(int i = 0; i < MAX_PLOT_VIEWS; i++)
	{
		myPlotView[i] = new PlotView();
		myPlotView[i]->Initialize(this, i + 1);
	}

	mySliceView = new SliceView();
	mySliceView->Initialize(this);

	myVolumeView = new VolumeView();
	myVolumeView->Initialize(this);

	// Set the main view interactor to terrain.
	vtkInteractorStyleTerrain* terrainInteractor = vtkInteractorStyleTerrain::New();
	myUI->vtkView->GetInteractor()->AddObserver("UserEvent", new UserEventCallback(this));
    myUI->vtkView->GetInteractor()->SetInteractorStyle(terrainInteractor);

	InitUI();
	InitPicking();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::InitPicking()
{
	mySelectedX = -1;
	mySelectedY = -1;
	myPicker = vtkPointPicker::New();

	// Setup thresholds
    myXThreshold = vtkThresholdPoints::New();
    myXThreshold->SetInputArrayToProcess(0, 0, 0, vtkDataObject::FIELD_ASSOCIATION_POINTS, "X");
    myXThreshold->SetInput(myDataSet->GetVtkPointData());
    myYThreshold = vtkThresholdPoints::New();
    myYThreshold->SetInputArrayToProcess(0, 0, 0, vtkDataObject::FIELD_ASSOCIATION_POINTS, "Y");
    myYThreshold->SetInput(myXThreshold->GetOutput());

	myXThreshold->ThresholdBetween(-999, -999);
	myYThreshold->ThresholdBetween(-999, -999);

	// Setup selected point visualization
    mySelectionMapper = vtkDataSetMapper::New();
	mySelectionMapper->SetInput(myYThreshold->GetOutput());
    //mySelectionMapper->ImmediateModeRenderingOn();

    mySelectionActor = vtkActor::New();
    mySelectionActor->GetProperty()->SetPointSize(10.0f);
    mySelectionActor->SetMapper(mySelectionMapper);
	mySelectionActor->GetProperty()->SetRepresentationToPoints();

    myRenderer->AddActor(mySelectionActor);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::InitSonde()
{
    SetInitMessage("Initializing Sonde Data...");

    myColorFunction = vtkColorTransferFunction::New();
	
    mySondeMapper = vtkDataSetMapper::New();
	mySondeMapper->SetInput(myThresholdStage[MAX_THRESHOLD_STAGES - 1]->GetOutput());
    //mySondeMapper->ImmediateModeRenderingOn();
    mySondeMapper->Update();

	// Setup the scalar color bar.
    myScalarBar = vtkScalarBarActor::New();
    myScalarBar->GetPositionCoordinate()->SetCoordinateSystemToDisplay();
    myScalarBar->GetPositionCoordinate()->SetValue(30, 5);
	myScalarBar->GetPosition2Coordinate()->SetCoordinateSystemToDisplay();
    myScalarBar->GetPosition2Coordinate()->SetValue(280, 50);
	myScalarBar->SetOrientationToHorizontal();
    myScalarBar->GetTitleTextProperty()->ShadowOff();

	myScalarBarColorFunction = vtkColorTransferFunction::New();

    mySondeActor = vtkActor::New();
    mySondeActor->GetProperty()->SetPointSize(6.0f);
    mySondeActor->SetMapper(mySondeMapper);
	mySondeActor->GetProperty()->SetRepresentationToPoints();
    mySondeActor->GetProperty()->BackfaceCullingOff();
    mySondeActor->GetProperty()->FrontfaceCullingOff();
    mySondeActor->PickableOn();

    myRenderer->AddActor(mySondeActor);
    myRenderer->AddActor2D(myScalarBar);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::Update()
{
	Render();
	for(int i = 0; i < MAX_PLOT_VIEWS; i++)
	{
		if(myPlotView[i]->IsEnabled())
		{
			myPlotView[i]->Update();
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::SetThresholdStage(int index, bool enabled, int field, double min, double max)
{
	if(enabled)
	{
		myThresholdStage[index]->SetInputArrayToProcess(
				0,0,0, vtkDataObject::FIELD_ASSOCIATION_POINTS,
				myDataSet->GetFieldName(field));
		myThresholdStage[index]->ThresholdBetween(min, max);
	}
	else
	{
		// using the double datatype extreme values does not seem to be working.
		// TODO: Anyway, fix this to use range + or - epsilon, instead of + - 10000.
		//	std::numeric_limits<double>::min(), std::numeric_limits<double>::max());
		myThresholdStage[index]->ThresholdBetween(-10000, 10000);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::SetColorTransferFunction(QColor start, QColor end, bool diverging)
{
    myStartColor = start;
    myEndColor = end;
    myDiverging = diverging;
	double* range = myDataSet->GetFieldRange(mySelectedField);
    if(diverging)
    {
        myColorFunction->SetColorSpaceToDiverging();
		myScalarBarColorFunction->SetColorSpaceToDiverging();
    }
    else
    {
        myColorFunction->SetColorSpaceToRGB();
		myScalarBarColorFunction->SetColorSpaceToRGB();
    }
    myColorFunction->RemoveAllPoints();
    myColorFunction->AddRGBPoint(range[0], QCOLOR_TO_VTK(myStartColor));
    myColorFunction->AddRGBPoint(range[1], QCOLOR_TO_VTK(myEndColor));
	myColorFunction->AddRGBPoint(-999, 0, 0, 0);

	mySondeMapper->SetLookupTable(myColorFunction);
	mySliceView->SetColorFunction(myColorFunction);
	mySelectionMapper->SetLookupTable(myColorFunction);

	myScalarBarColorFunction->RemoveAllPoints();
    myScalarBarColorFunction->AddRGBPoint(range[0], QCOLOR_TO_VTK(myStartColor));
    myScalarBarColorFunction->AddRGBPoint(range[1], QCOLOR_TO_VTK(myEndColor));
    myScalarBar->SetLookupTable(myScalarBarColorFunction);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::SetMissionRange(int startDay, int endDay)
{
    myThresholdStage[0]->SetInputArrayToProcess(
            0,0,0, vtkDataObject::FIELD_ASSOCIATION_POINTS_THEN_CELLS,
            "mm/dd/yyyy");
    myThresholdStage[0]->ThresholdBetween(startDay, endDay);
    
	myInvalidPointThreshold->Update();

	for(int i = 0; i < MAX_PLOT_VIEWS; i++)
	{
		if(myPlotView[i]->IsEnabled())
		{
			myPlotView[i]->Update();
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::Render()
{
	myUI->vtkView->GetRenderWindow()->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::Add3DWidget(vtkInteractorObserver* widget)
{
	widget->SetInteractor(myUI->vtkView->GetRenderWindow()->GetInteractor());
}

///////////////////////////////////////////////////////////////////////////////////////////////////
vtkRenderer* VisualizationManager::GetMainRenderer() 
{ 
	return myRenderer; 
}

///////////////////////////////////////////////////////////////////////////////////////////////////
DataSet* VisualizationManager::GetDataSet() 
{ 
	return myDataSet; 
}

///////////////////////////////////////////////////////////////////////////////////////////////////
Ui_MainWindow* VisualizationManager::GetUI() 
{ 
	return myUI; 
}

///////////////////////////////////////////////////////////////////////////////////////////////////
QMainWindow* VisualizationManager::GetMainWindow() 
{ 
	return myMainWindow; 
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int VisualizationManager::GetSelectedField() 
{
	return mySelectedField; 
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::OnUserEvent()
{
	// Called on user event (usually keypress 'u'). Identify the
	// selected point and get grid coordinates for it.
	int* pos = myRenderWindow->GetInteractor()->GetEventPosition();
	myPicker->Pick(pos[0], pos[1], 0, myRenderer);

	if(myPicker->GetPointId() != -1)
	{
		vtkIdType ptId = myPicker->GetPointId();
		
		// A point has been selected. retrieve grid coords from its Id.
		vtkDoubleArray* arX = vtkDoubleArray::New();
		myDataSet->GetVtkPointData()->GetPointData()->GetArray("X")->GetData(
			ptId, ptId, 0, 0, arX);

		vtkDoubleArray* arY = vtkDoubleArray::New();
		myDataSet->GetVtkPointData()->GetPointData()->GetArray("Y")->GetData(
			ptId, ptId, 0, 0, arY);

		double* X = arX->GetPointer(0);
		double* Y = arY->GetPointer(0);

		SetSelectedSondeDrop(X[0], Y[0]);
		
		// Release allocated arrays.
		arX->Delete();
		arY->Delete();
	}
	else
	{
		// No valid point selected: clear selection.
		ClearSelection();
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::OnDepthScaleSliderChanged()
{
	int value = myUI->depthScaleSlider->value();
	myDataSet->SetDepthScale(value);
	if(mySliceView->IsEnabled())
	{
		mySliceView->SetDepthScale(value);
	}
	myGeoDataView->SetDepthScale(value);
    mySondeMapper->Update();
    myUI->vtkView->GetRenderWindow()->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::OnShowMissionButtonToggle(bool)
{
    if(myUI->showAllMissionButton->isChecked())
    {
        myUI->startMissionSlider->setEnabled(false);
        myUI->endMissionSlider->setEnabled(false);
    }
    else if(myUI->showSingleMissionButton->isChecked())
    {
        myUI->startMissionSlider->setEnabled(true);
        myUI->endMissionSlider->setEnabled(false);
    }
    else
    {
        myUI->startMissionSlider->setEnabled(true);
        myUI->endMissionSlider->setEnabled(true);
    }
    UpdateMissionRange();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::OnStartMissionSliderChange(int value)
{
    myUI->startMissionLabel->setText(QString("12/%1/2008").arg(value));
    UpdateMissionRange();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::OnEndMissionSliderChange(int value)
{
    myUI->endMissionLabel->setText(QString("12/%1/2008").arg(value));
    UpdateMissionRange();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VisualizationManager::OnSelectedFieldChanged(int i)
{
    mySelectedField = i;

    // Set the scalar array on which to do invalid point filtering.
    myInvalidPointThreshold->SetInputArrayToProcess(
      0,0,0, vtkDataObject::FIELD_ASSOCIATION_POINTS_THEN_CELLS,
      myDataSet->GetFieldName(mySelectedField));
    myInvalidPointThreshold->Update();

    /*mySondeMapper->SetScalarRange(
            mySondeReader->GetOutput()->GetPointData()->GetScalars()->GetRange());*/
    mySondeMapper->SetScalarModeToUsePointFieldData();
    mySondeMapper->SelectColorArray(mySelectedField);
    mySondeMapper->Update();

    myScalarBar->SetTitle(myDataSet->GetFieldName(mySelectedField));

	mySliceView->SetVisualizedField(i);

    SetColorTransferFunction(myStartColor, myEndColor, myDiverging);

	for(int i = 0; i < MAX_PLOT_VIEWS; i++)
	{
		if(myPlotView[i]->IsEnabled())
		{
			myPlotView[i]->Update();
		}
	}

	myUI->vtkView->GetRenderWindow()->Render();
}