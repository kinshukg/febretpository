///////////////////////////////////////////////////////////////////////////////////////////////////
#include "VolumeView.h"
#include "VisualizationManager.h"
#include "DataSet.h"
#include "Ui_MainWindow.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
const int VolumeView::myMaxVolumeSections = 10;
const int VolumeView::myVolumeResolution = 10;

///////////////////////////////////////////////////////////////////////////////////////////////////
VolumeView::VolumeView()
{
	myDataSet = NULL;
	myVisualizedVolumeData = 0;

    myVolumeSections = new VolumeSectionInfo[myMaxVolumeSections];
    for(int i = 0; i < myMaxVolumeSections; i++)
    {
        myVolumeSections[i].Used = false;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VolumeView::~VolumeView()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::AddVolumeSectionButtonClick()
{
    VolumeSectionInfo* info = GetFreeVolumeSectionInfo();
    info->Used = true;
    info->StartValue = 60;
    info->EndValue = 70;
    info->Opacity = 1.0f;
    info->Color = Qt::red;

    QListWidgetItem* item = new QListWidgetItem();
    item->setText("Volume Section");
    item->setData(Qt::UserRole, qVariantFromValue((void*)info));

    myUI->volumeSectionsList->addItem(item);

    Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::EnableVolumeButtonToggle(bool enabled)
{
    if(enabled)
    {
		myVizMng->GetMainRenderer()->AddVolume(myVolume);
    }
    else
    {
        myVizMng->GetMainRenderer()->RemoveVolume(myVolume);
    }

	myVizMng->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::RemoveVolumeSectionButtonClick()
{
    QListWidgetItem* item = myUI->volumeSectionsList->currentItem();
    if(item != NULL)
    {
        myUI->volumeSectionsList->removeItemWidget(item);

        VolumeSectionInfo* info = (VolumeSectionInfo*)item->data(Qt::UserRole).value<void*>();
        info->Used = false;

        Update();

        delete item;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::VolumeComponentSelectionChanged(int i)
{
    myVisualizedVolumeData = i;
	Update();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::VolSectionColorClick()
{
    myVolSectionColor = QColorDialog::getColor();
    QPalette palette;
    palette = myVolSectionColorButton->palette();
    palette.setColor(QPalette::Background, myVolSectionColor);
    myVolSectionColorButton->setPalette(palette);

    QListWidgetItem* item = myUI->volumeSectionsList->currentItem();
    if(item != NULL)
    {
        VolumeSectionInfo* info = (VolumeSectionInfo*)item->data(Qt::UserRole).value<void*>();
        info->Color = myVolSectionColor;
        Update();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::VolumeSectionListItemChanged(QListWidgetItem* current, QListWidgetItem * previous)
{
    if(current != NULL)
    {
        VolumeSectionInfo* info = (VolumeSectionInfo*)current->data(Qt::UserRole).value<void*>();

        QPalette palette;
        palette = myVolSectionColorButton->palette();
        palette.setColor(QPalette::Background, info->Color);
        myVolSectionColorButton->setPalette(palette);

        myUI->volSectionEndValueSlider->setValue(info->EndValue);
        myUI->volSectionStartValueSlider->setValue(info->StartValue);
        myUI->volSectionOpacitySlider->setValue(info->Opacity * 100);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::VolSectionEndValueSliderReleased()
{
    QListWidgetItem* item = myUI->volumeSectionsList->currentItem();
    if(item != NULL)
    {
        VolumeSectionInfo* info = (VolumeSectionInfo*)item->data(Qt::UserRole).value<void*>();
        info->EndValue = myUI->volSectionEndValueSlider->value();
        Update();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::VolSectionOpacitySliderReleased()
{
    QListWidgetItem* item = myUI->volumeSectionsList->currentItem();
    if(item != NULL)
    {
        VolumeSectionInfo* info = (VolumeSectionInfo*)item->data(Qt::UserRole).value<void*>();
        info->Opacity = (float)myUI->volSectionOpacitySlider->value() / 100;
        Update();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::VolSectionStartValueSliderReleased()
{
    QListWidgetItem* item = myUI->volumeSectionsList->currentItem();
    if(item != NULL)
    {
        VolumeSectionInfo* info = (VolumeSectionInfo*)item->data(Qt::UserRole).value<void*>();
        info->StartValue = myUI->volSectionStartValueSlider->value();
        Update();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::Initialize(VisualizationManager* mng)
{
	myVizMng = mng;
	myDataSet = mng->GetDataSet();

	// Initialize the UI.
	myDock = new QDockWidget(mng->GetMainWindow());
	myUI = new Ui_VolumeViewDock();
	myEnabled = false;
	myDock->hide();
	myUI->setupUi(myDock);

	vtkPointSet* grid = myDataSet->GetVtkPointData();

    mySondeVolumeBuilder = vtkShepardMethod::New();
    mySondeVolumeBuilder->SetInput(grid);
	mySondeVolumeBuilder->SetModelBounds(grid->GetBounds());
    mySondeVolumeBuilder->SetSampleDimensions(myVolumeResolution, myVolumeResolution, myVolumeResolution);
    mySondeVolumeBuilder->SetMaximumDistance(0.1f);
    mySondeVolumeBuilder->SetNullValue(999.0f);
	mySondeVolumeBuilder->Update();
	
	vtkImageData* imgData = mySondeVolumeBuilder->GetOutput();

	double* bounds = imgData->GetBounds();

    myVolumeOpacityFunction = vtkPiecewiseFunction::New();
    myVolumeOpacityFunction->ClampingOff();

    myVolumeColorFunction = vtkColorTransferFunction::New();
    myVolumeColorFunction->ClampingOff();

    myVolumeProperty = vtkVolumeProperty::New();
    myVolumeProperty->SetColor(myVolumeColorFunction);
    myVolumeProperty->SetScalarOpacity(myVolumeOpacityFunction);
    myVolumeProperty->SetInterpolationTypeToLinear();
	myVolumeProperty->ShadeOn();
	myVolumeProperty->SetAmbient(0.6);
	myVolumeProperty->SetSpecular(0.5);

    mySondeVolumeRescaler  = vtkImageShiftScale::New();
    mySondeVolumeRescaler->SetInputConnection(mySondeVolumeBuilder->GetOutputPort());
    mySondeVolumeRescaler->SetOutputScalarTypeToUnsignedShort();

    myVolumeMapper = vtkVolumeRayCastMapper::New();
    myVolumeMapper->SetInput(mySondeVolumeRescaler->GetOutput());
    myVolumeMapper->SetVolumeRayCastFunction(vtkVolumeRayCastCompositeFunction::New());
    myVolumeMapper->SetMinimumImageSampleDistance(2.0f);
    myVolumeMapper->SetMaximumImageSampleDistance(10.0f);

    myVolume = vtkVolume::New();
    myVolume->SetMapper(myVolumeMapper);
    myVolume->SetProperty(myVolumeProperty);
    myVolume->Update();

	// Init UI
    // Setup the components box.
	for(int i = 0; i < myDataSet->GetNumVisualizableFields(); i++)
    {
        myUI->volumeComponentBox->addItem(myDataSet->GetFieldName(i), i);
    }

    myVolSectionColorButton = new QWidget();
    myVolSectionColorButton->setMinimumSize(20, 20);
    myVolSectionColorButton->setMaximumSize(20, 20);
    myVolSectionColorButton->setAutoFillBackground(true);
    QPushButton* volSectionColorLabel = new QPushButton("Color");
    myUI->volSectionColorBox->addWidget(myVolSectionColorButton);
    myUI->volSectionColorBox->addWidget(volSectionColorLabel);
    QObject::connect(volSectionColorLabel, SIGNAL(clicked()), this, SLOT(VolSectionColorClick()));

    QObject::connect(myUI->enableVolumeButton, SIGNAL(toggled(bool)), this, SLOT(EnableVolumeButtonToggle(bool)));
    QObject::connect(myUI->volumeComponentBox, SIGNAL(currentIndexChanged(int)), this, SLOT(VolumeComponentSelectionChanged(int)));
    QObject::connect(myUI->addVolumeSectionButton, SIGNAL(clicked()), this, SLOT(AddVolumeSectionButtonClick()));
    QObject::connect(myUI->removeVolumeSectionButton, SIGNAL(clicked()), this, SLOT(RemoveVolumeSectionButtonClick()));
    QObject::connect(myUI->volumeSectionsList, SIGNAL(currentItemChanged ( QListWidgetItem*, QListWidgetItem*)), this, SLOT(VolumeSectionListItemChanged(QListWidgetItem*, QListWidgetItem*)));
    QObject::connect(myUI->volSectionStartValueSlider, SIGNAL(sliderReleased()), this, SLOT(VolSectionStartValueSliderReleased()));
    QObject::connect(myUI->volSectionEndValueSlider, SIGNAL(sliderReleased()), this, SLOT(VolSectionEndValueSliderReleased()));
    QObject::connect(myUI->volSectionOpacitySlider, SIGNAL(sliderReleased()), this, SLOT(VolSectionOpacitySliderReleased()));

	myDock->installEventFilter(this);
	myMenuAction = myVizMng->AddWindowMenuAction(QString("Volume View"));
	QObject::connect(myMenuAction, SIGNAL(triggered(bool)), this, SLOT(SetEnabled(bool)));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
VolumeSectionInfo* VolumeView::GetFreeVolumeSectionInfo()
{
    for(int i = 0; i < myMaxVolumeSections; i++)
    {
        if(!myVolumeSections[i].Used)
        {
            return &myVolumeSections[i];

        }
    }
    return NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::Enable()
{
	myEnabled = true;
	myVizMng->GetMainWindow()->addDockWidget(Qt::RightDockWidgetArea, myDock);
	myDock->show();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::Disable()
{
	myEnabled = false;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool VolumeView::IsEnabled()
{
	return myEnabled;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::SetEnabled(bool enabled)
{
	if(enabled)
	{
		Enable();
	}
	else
	{
		Disable();
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void VolumeView::Update()
{
	const char* scalarsName = myDataSet->GetFieldName(myVisualizedVolumeData);
	vtkPointSet* data = myDataSet->GetVtkPointData();
    data->GetPointData()->SetActiveScalars(scalarsName);

    myVolumeOpacityFunction->RemoveAllPoints();
    myVolumeColorFunction->RemoveAllPoints();

    for(int i = 0; i < myMaxVolumeSections; i++)
    {
        if(myVolumeSections[i].Used)
        {
            float thickness = myVolumeSections[i].EndValue - myVolumeSections[i].StartValue;
            for(int c = myVolumeSections[i].StartValue; c <= myVolumeSections[i].EndValue; c++)
            {
                float opacityFactor = (((float)(c - myVolumeSections[i].StartValue)) / thickness) * 2 - 1;
                float opacity = myVolumeSections[i].Opacity * (1 - fabs(opacityFactor));
                myVolumeOpacityFunction->AddPoint(c, opacity);
                myVolumeColorFunction->AddRGBPoint(c, QCOLOR_TO_VTK(myVolumeSections[i].Color));
            }
        }
    }

    // Rescale the data depending on the currently selected component.
    double* range = data->GetPointData()->GetScalars(scalarsName)->GetRange();
    mySondeVolumeRescaler->SetOutputScalarTypeToUnsignedShort();
    mySondeVolumeRescaler->SetShift(-range[0]);
    mySondeVolumeRescaler->SetScale(100 / (range[1] - range[0]));

    myVolume->Update();
	myVizMng->Render();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool VolumeView::eventFilter(QObject *obj, QEvent *event)
{
	if (event->type() == QEvent::Close) 
	{
		Disable();
		myMenuAction->setChecked(false);
		return false;
	} 
	else 
	{
		// standard event processing
		return QObject::eventFilter(obj, event);
	}
}
