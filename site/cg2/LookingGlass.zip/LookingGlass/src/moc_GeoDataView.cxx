/****************************************************************************
** Meta object code from reading C++ file 'GeoDataView.h'
**
** Created: Thu 19. Mar 15:13:37 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "GeoDataView.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GeoDataView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_GeoDataView[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      21,   13,   12,   12, 0x0a,
      44,   38,   12,   12, 0x09,
      70,   12,   12,   12, 0x09,
     113,  105,   12,   12, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_GeoDataView[] = {
    "GeoDataView\0\0enabled\0SetEnabled(bool)\0"
    "value\0OpacitySliderChanged(int)\0"
    "OnOverlayOpacitySliderChanged(int)\0"
    "checked\0OnAxesButtonToggle(bool)\0"
};

const QMetaObject GeoDataView::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_GeoDataView,
      qt_meta_data_GeoDataView, 0 }
};

const QMetaObject *GeoDataView::metaObject() const
{
    return &staticMetaObject;
}

void *GeoDataView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GeoDataView))
        return static_cast<void*>(const_cast< GeoDataView*>(this));
    return QObject::qt_metacast(_clname);
}

int GeoDataView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: SetEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: OpacitySliderChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: OnOverlayOpacitySliderChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: OnAxesButtonToggle((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
