///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef SLICEVIEW_H
#define SLICEVIEW_H

///////////////////////////////////////////////////////////////////////////////////////////////////
#include "LookingGlassSystem.h"
#include "Ui_SliceViewDock.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
class SliceView: QObject
{
	Q_OBJECT
public:
    /////////////////////////////////////////////////////// Ctor / Dtor.
    SliceView();
    ~SliceView();

    /////////////////////////////////////////////////////// Other Methods.
    void Initialize(VisualizationManager* msg);
    void Update();
	void SetVisualizedField(int index);
    void SetColorFunction(vtkColorTransferFunction* fx);
	void Enable();
	void Disable();
	bool IsEnabled();
	void OnBeginInteraction();
	void OnEndInteraction();
	void SetDepthScale(int value);

public slots:
	void SetEnabled(bool enabled);

protected slots:
	void OnSliceEnableButtonToggle(bool enabled);
	void OnLightEnableButtonToggle(bool enabled);
	void OnNormalXButtonClick();
	void OnNormalYButtonClick();
	void OnNormalZButtonClick();

protected:
     bool eventFilter(QObject *obj, QEvent *event);

private:
	VisualizationManager* myVizMng;
	DataSet* myDataSet;

	// UI.
	QDockWidget* myDock;
	Ui_SliceViewDock* myUI;
	QAction* myMenuAction;
	bool myEnabled;

    vtkImplicitPlaneRepresentation* myPlaneRep;
    vtkImplicitPlaneWidget2* myPlaneWidget;
    //vtkProbeFilter* myPlaneProbe;
    vtkCutter* myPlaneProbe;
    vtkPlaneSource* myPlaneSource;
    vtkDataSetMapper* myProbeMapper;
    vtkShepardMethod* mySondeVolumeBuilder;
    vtkActor* myProbeActor;
};

#endif 
