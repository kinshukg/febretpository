/********************************************************************************
** Form generated from reading ui file 'SliceViewDock.ui'
**
** Created: Thu 19. Mar 15:13:41 2009
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_SLICEVIEWDOCK_H
#define UI_SLICEVIEWDOCK_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDockWidget>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SliceViewDock
{
public:
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout;
    QCheckBox *sliceEnableButton;
    QCheckBox *lightEnableButton;
    QHBoxLayout *horizontalLayout;
    QPushButton *normalXButton;
    QPushButton *normalYButton;
    QPushButton *normalZButton;
    QLabel *label_9;
    QSpacerItem *verticalSpacer;

    void setupUi(QDockWidget *SliceViewDock)
    {
        if (SliceViewDock->objectName().isEmpty())
            SliceViewDock->setObjectName(QString::fromUtf8("SliceViewDock"));
        SliceViewDock->resize(257, 279);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout = new QVBoxLayout(dockWidgetContents);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        sliceEnableButton = new QCheckBox(dockWidgetContents);
        sliceEnableButton->setObjectName(QString::fromUtf8("sliceEnableButton"));

        verticalLayout->addWidget(sliceEnableButton);

        lightEnableButton = new QCheckBox(dockWidgetContents);
        lightEnableButton->setObjectName(QString::fromUtf8("lightEnableButton"));

        verticalLayout->addWidget(lightEnableButton);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        normalXButton = new QPushButton(dockWidgetContents);
        normalXButton->setObjectName(QString::fromUtf8("normalXButton"));

        horizontalLayout->addWidget(normalXButton);

        normalYButton = new QPushButton(dockWidgetContents);
        normalYButton->setObjectName(QString::fromUtf8("normalYButton"));

        horizontalLayout->addWidget(normalYButton);

        normalZButton = new QPushButton(dockWidgetContents);
        normalZButton->setObjectName(QString::fromUtf8("normalZButton"));

        horizontalLayout->addWidget(normalZButton);


        verticalLayout->addLayout(horizontalLayout);

        label_9 = new QLabel(dockWidgetContents);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label_9->setFont(font);

        verticalLayout->addWidget(label_9);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        SliceViewDock->setWidget(dockWidgetContents);

        retranslateUi(SliceViewDock);

        QMetaObject::connectSlotsByName(SliceViewDock);
    } // setupUi

    void retranslateUi(QDockWidget *SliceViewDock)
    {
        SliceViewDock->setWindowTitle(QApplication::translate("SliceViewDock", "Slice Settings", 0, QApplication::UnicodeUTF8));
        sliceEnableButton->setText(QApplication::translate("SliceViewDock", "Enable slice", 0, QApplication::UnicodeUTF8));
        lightEnableButton->setText(QApplication::translate("SliceViewDock", "Lighting", 0, QApplication::UnicodeUTF8));
        normalXButton->setText(QApplication::translate("SliceViewDock", "Normal X", 0, QApplication::UnicodeUTF8));
        normalYButton->setText(QApplication::translate("SliceViewDock", "Normal Y", 0, QApplication::UnicodeUTF8));
        normalZButton->setText(QApplication::translate("SliceViewDock", "Normal Z", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("SliceViewDock", "To enable slice interaction press 'i'", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(SliceViewDock);
    } // retranslateUi

};

namespace Ui {
    class SliceViewDock: public Ui_SliceViewDock {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SLICEVIEWDOCK_H
