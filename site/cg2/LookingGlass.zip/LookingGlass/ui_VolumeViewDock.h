/********************************************************************************
** Form generated from reading ui file 'VolumeViewDock.ui'
**
** Created: Thu 19. Mar 15:13:41 2009
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_VOLUMEVIEWDOCK_H
#define UI_VOLUMEVIEWDOCK_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDockWidget>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_VolumeViewDock
{
public:
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout;
    QCheckBox *enableVolumeButton;
    QLabel *label_5;
    QComboBox *volumeComponentBox;
    QListWidget *volumeSectionsList;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *addVolumeSectionButton;
    QPushButton *removeVolumeSectionButton;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *volSectionColorBox;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_6;
    QSlider *volSectionStartValueSlider;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_7;
    QSlider *volSectionEndValueSlider;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_8;
    QSlider *volSectionOpacitySlider;

    void setupUi(QDockWidget *VolumeViewDock)
    {
        if (VolumeViewDock->objectName().isEmpty())
            VolumeViewDock->setObjectName(QString::fromUtf8("VolumeViewDock"));
        VolumeViewDock->resize(274, 499);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout = new QVBoxLayout(dockWidgetContents);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        enableVolumeButton = new QCheckBox(dockWidgetContents);
        enableVolumeButton->setObjectName(QString::fromUtf8("enableVolumeButton"));

        verticalLayout->addWidget(enableVolumeButton);

        label_5 = new QLabel(dockWidgetContents);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        volumeComponentBox = new QComboBox(dockWidgetContents);
        volumeComponentBox->setObjectName(QString::fromUtf8("volumeComponentBox"));

        verticalLayout->addWidget(volumeComponentBox);

        volumeSectionsList = new QListWidget(dockWidgetContents);
        volumeSectionsList->setObjectName(QString::fromUtf8("volumeSectionsList"));

        verticalLayout->addWidget(volumeSectionsList);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        addVolumeSectionButton = new QPushButton(dockWidgetContents);
        addVolumeSectionButton->setObjectName(QString::fromUtf8("addVolumeSectionButton"));

        horizontalLayout_4->addWidget(addVolumeSectionButton);

        removeVolumeSectionButton = new QPushButton(dockWidgetContents);
        removeVolumeSectionButton->setObjectName(QString::fromUtf8("removeVolumeSectionButton"));

        horizontalLayout_4->addWidget(removeVolumeSectionButton);


        verticalLayout->addLayout(horizontalLayout_4);

        groupBox_4 = new QGroupBox(dockWidgetContents);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        verticalLayout_7 = new QVBoxLayout(groupBox_4);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        volSectionColorBox = new QHBoxLayout();
        volSectionColorBox->setObjectName(QString::fromUtf8("volSectionColorBox"));

        verticalLayout_7->addLayout(volSectionColorBox);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_6 = new QLabel(groupBox_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_7->addWidget(label_6);

        volSectionStartValueSlider = new QSlider(groupBox_4);
        volSectionStartValueSlider->setObjectName(QString::fromUtf8("volSectionStartValueSlider"));
        volSectionStartValueSlider->setOrientation(Qt::Horizontal);

        horizontalLayout_7->addWidget(volSectionStartValueSlider);


        verticalLayout_7->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_7 = new QLabel(groupBox_4);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_8->addWidget(label_7);

        volSectionEndValueSlider = new QSlider(groupBox_4);
        volSectionEndValueSlider->setObjectName(QString::fromUtf8("volSectionEndValueSlider"));
        volSectionEndValueSlider->setOrientation(Qt::Horizontal);

        horizontalLayout_8->addWidget(volSectionEndValueSlider);


        verticalLayout_7->addLayout(horizontalLayout_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_8 = new QLabel(groupBox_4);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_9->addWidget(label_8);

        volSectionOpacitySlider = new QSlider(groupBox_4);
        volSectionOpacitySlider->setObjectName(QString::fromUtf8("volSectionOpacitySlider"));
        volSectionOpacitySlider->setOrientation(Qt::Horizontal);

        horizontalLayout_9->addWidget(volSectionOpacitySlider);


        verticalLayout_7->addLayout(horizontalLayout_9);


        verticalLayout->addWidget(groupBox_4);

        VolumeViewDock->setWidget(dockWidgetContents);

        retranslateUi(VolumeViewDock);

        QMetaObject::connectSlotsByName(VolumeViewDock);
    } // setupUi

    void retranslateUi(QDockWidget *VolumeViewDock)
    {
        VolumeViewDock->setWindowTitle(QApplication::translate("VolumeViewDock", "Volume Rendering", 0, QApplication::UnicodeUTF8));
        enableVolumeButton->setText(QApplication::translate("VolumeViewDock", "Enable VolumeRendering", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("VolumeViewDock", "Component", 0, QApplication::UnicodeUTF8));
        addVolumeSectionButton->setText(QApplication::translate("VolumeViewDock", "Add", 0, QApplication::UnicodeUTF8));
        removeVolumeSectionButton->setText(QApplication::translate("VolumeViewDock", "Remove", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QApplication::translate("VolumeViewDock", "Volume Section Settings", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("VolumeViewDock", "Start Value", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("VolumeViewDock", "End Value", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("VolumeViewDock", "Opacity", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(VolumeViewDock);
    } // retranslateUi

};

namespace Ui {
    class VolumeViewDock: public Ui_VolumeViewDock {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VOLUMEVIEWDOCK_H
