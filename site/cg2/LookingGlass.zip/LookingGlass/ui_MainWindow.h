/********************************************************************************
** Form generated from reading ui file 'MainWindow.ui'
**
** Created: Thu 19. Mar 15:13:41 2009
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDockWidget>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QRadioButton>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QStatusBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "QVTKWidget.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionQuit;
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QVTKWidget *vtkView;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuWindows;
    QStatusBar *statusbar;
    QDockWidget *viewOptionsDock;
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_3;
    QSlider *depthScaleSlider;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_2;
    QComboBox *componentBox;
    QLabel *label;
    QHBoxLayout *colorMapBox;
    QCheckBox *divergingCheckBox;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_3;
    QRadioButton *showAllMissionButton;
    QRadioButton *showSingleMissionButton;
    QRadioButton *showIntervalMissionButton;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QSlider *startMissionSlider;
    QLabel *startMissionLabel;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QSlider *endMissionSlider;
    QLabel *endMissionLabel;
    QSpacerItem *verticalSpacer;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(675, 475);
        QIcon icon;
        icon.addPixmap(QPixmap(QString::fromUtf8("resources/LookingGlass.png")), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setDockOptions(QMainWindow::AllowTabbedDocks|QMainWindow::AnimatedDocks);
        MainWindow->setUnifiedTitleAndToolBarOnMac(false);
        actionQuit = new QAction(MainWindow);
        actionQuit->setObjectName(QString::fromUtf8("actionQuit"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        vtkView = new QVTKWidget(centralwidget);
        vtkView->setObjectName(QString::fromUtf8("vtkView"));

        horizontalLayout->addWidget(vtkView);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 675, 23));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuWindows = new QMenu(menubar);
        menuWindows->setObjectName(QString::fromUtf8("menuWindows"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        viewOptionsDock = new QDockWidget(MainWindow);
        viewOptionsDock->setObjectName(QString::fromUtf8("viewOptionsDock"));
        QIcon icon1;
        icon1.addPixmap(QPixmap(QString::fromUtf8("../resources/LookingGlass.png")), QIcon::Normal, QIcon::Off);
        viewOptionsDock->setWindowIcon(icon1);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout = new QVBoxLayout(dockWidgetContents);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        groupBox_3 = new QGroupBox(dockWidgetContents);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        verticalLayout_5 = new QVBoxLayout(groupBox_3);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_3 = new QLabel(groupBox_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(60, 0));

        horizontalLayout_6->addWidget(label_3);

        depthScaleSlider = new QSlider(groupBox_3);
        depthScaleSlider->setObjectName(QString::fromUtf8("depthScaleSlider"));
        depthScaleSlider->setMinimum(1);
        depthScaleSlider->setMaximum(20);
        depthScaleSlider->setOrientation(Qt::Horizontal);

        horizontalLayout_6->addWidget(depthScaleSlider);


        verticalLayout_5->addLayout(horizontalLayout_6);


        verticalLayout->addWidget(groupBox_3);

        groupBox = new QGroupBox(dockWidgetContents);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout_2 = new QVBoxLayout(groupBox);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        componentBox = new QComboBox(groupBox);
        componentBox->setObjectName(QString::fromUtf8("componentBox"));

        verticalLayout_2->addWidget(componentBox);

        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_2->addWidget(label);

        colorMapBox = new QHBoxLayout();
        colorMapBox->setObjectName(QString::fromUtf8("colorMapBox"));

        verticalLayout_2->addLayout(colorMapBox);

        divergingCheckBox = new QCheckBox(groupBox);
        divergingCheckBox->setObjectName(QString::fromUtf8("divergingCheckBox"));

        verticalLayout_2->addWidget(divergingCheckBox);


        verticalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(dockWidgetContents);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        verticalLayout_3 = new QVBoxLayout(groupBox_2);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        showAllMissionButton = new QRadioButton(groupBox_2);
        showAllMissionButton->setObjectName(QString::fromUtf8("showAllMissionButton"));

        verticalLayout_3->addWidget(showAllMissionButton);

        showSingleMissionButton = new QRadioButton(groupBox_2);
        showSingleMissionButton->setObjectName(QString::fromUtf8("showSingleMissionButton"));

        verticalLayout_3->addWidget(showSingleMissionButton);

        showIntervalMissionButton = new QRadioButton(groupBox_2);
        showIntervalMissionButton->setObjectName(QString::fromUtf8("showIntervalMissionButton"));

        verticalLayout_3->addWidget(showIntervalMissionButton);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(32, 0));

        horizontalLayout_2->addWidget(label_2);

        startMissionSlider = new QSlider(groupBox_2);
        startMissionSlider->setObjectName(QString::fromUtf8("startMissionSlider"));
        startMissionSlider->setOrientation(Qt::Horizontal);

        horizontalLayout_2->addWidget(startMissionSlider);

        startMissionLabel = new QLabel(groupBox_2);
        startMissionLabel->setObjectName(QString::fromUtf8("startMissionLabel"));

        horizontalLayout_2->addWidget(startMissionLabel);


        verticalLayout_3->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(32, 0));

        horizontalLayout_3->addWidget(label_4);

        endMissionSlider = new QSlider(groupBox_2);
        endMissionSlider->setObjectName(QString::fromUtf8("endMissionSlider"));
        endMissionSlider->setOrientation(Qt::Horizontal);

        horizontalLayout_3->addWidget(endMissionSlider);

        endMissionLabel = new QLabel(groupBox_2);
        endMissionLabel->setObjectName(QString::fromUtf8("endMissionLabel"));

        horizontalLayout_3->addWidget(endMissionLabel);


        verticalLayout_3->addLayout(horizontalLayout_3);


        verticalLayout->addWidget(groupBox_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        viewOptionsDock->setWidget(dockWidgetContents);
        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), viewOptionsDock);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuWindows->menuAction());
        menuFile->addAction(actionQuit);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "LookingGlass", 0, QApplication::UnicodeUTF8));
        actionQuit->setText(QApplication::translate("MainWindow", "Quit", 0, QApplication::UnicodeUTF8));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0, QApplication::UnicodeUTF8));
        menuWindows->setTitle(QApplication::translate("MainWindow", "Windows", 0, QApplication::UnicodeUTF8));
        viewOptionsDock->setWindowTitle(QApplication::translate("MainWindow", "View Options", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Bathymetry", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "Depth Scale", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MainWindow", "Component", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "Color Map", 0, QApplication::UnicodeUTF8));
        divergingCheckBox->setText(QApplication::translate("MainWindow", "Diverging", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Missions", 0, QApplication::UnicodeUTF8));
        showAllMissionButton->setText(QApplication::translate("MainWindow", "Show All", 0, QApplication::UnicodeUTF8));
        showSingleMissionButton->setText(QApplication::translate("MainWindow", "Show Single", 0, QApplication::UnicodeUTF8));
        showIntervalMissionButton->setText(QApplication::translate("MainWindow", "Show Interval", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "Start", 0, QApplication::UnicodeUTF8));
        startMissionLabel->setText(QApplication::translate("MainWindow", "12/01/2008", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "End", 0, QApplication::UnicodeUTF8));
        endMissionLabel->setText(QApplication::translate("MainWindow", "12/18/2008", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
