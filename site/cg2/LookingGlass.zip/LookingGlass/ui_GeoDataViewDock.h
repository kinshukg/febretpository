/********************************************************************************
** Form generated from reading ui file 'GeoDataViewDock.ui'
**
** Created: Thu 19. Mar 15:13:41 2009
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_GEODATAVIEWDOCK_H
#define UI_GEODATAVIEWDOCK_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDockWidget>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GeoDataViewDock
{
public:
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout;
    QCheckBox *axesButton;
    QHBoxLayout *horizontalLayout_5;
    QLabel *Opacity;
    QSlider *opacitySlider;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QSlider *overlayOpacitySlider;
    QSpacerItem *verticalSpacer;

    void setupUi(QDockWidget *GeoDataViewDock)
    {
        if (GeoDataViewDock->objectName().isEmpty())
            GeoDataViewDock->setObjectName(QString::fromUtf8("GeoDataViewDock"));
        GeoDataViewDock->resize(311, 458);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout = new QVBoxLayout(dockWidgetContents);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        axesButton = new QCheckBox(dockWidgetContents);
        axesButton->setObjectName(QString::fromUtf8("axesButton"));

        verticalLayout->addWidget(axesButton);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        Opacity = new QLabel(dockWidgetContents);
        Opacity->setObjectName(QString::fromUtf8("Opacity"));
        Opacity->setMinimumSize(QSize(60, 0));

        horizontalLayout_5->addWidget(Opacity);

        opacitySlider = new QSlider(dockWidgetContents);
        opacitySlider->setObjectName(QString::fromUtf8("opacitySlider"));
        opacitySlider->setOrientation(Qt::Horizontal);

        horizontalLayout_5->addWidget(opacitySlider);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(dockWidgetContents);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        overlayOpacitySlider = new QSlider(dockWidgetContents);
        overlayOpacitySlider->setObjectName(QString::fromUtf8("overlayOpacitySlider"));
        overlayOpacitySlider->setOrientation(Qt::Horizontal);

        horizontalLayout->addWidget(overlayOpacitySlider);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        GeoDataViewDock->setWidget(dockWidgetContents);

        retranslateUi(GeoDataViewDock);

        QMetaObject::connectSlotsByName(GeoDataViewDock);
    } // setupUi

    void retranslateUi(QDockWidget *GeoDataViewDock)
    {
        GeoDataViewDock->setWindowTitle(QApplication::translate("GeoDataViewDock", "Geo Data", 0, QApplication::UnicodeUTF8));
        axesButton->setText(QApplication::translate("GeoDataViewDock", "Enable Axes", 0, QApplication::UnicodeUTF8));
        Opacity->setText(QApplication::translate("GeoDataViewDock", "Opacity", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("GeoDataViewDock", "Overlay Opacity:", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(GeoDataViewDock);
    } // retranslateUi

};

namespace Ui {
    class GeoDataViewDock: public Ui_GeoDataViewDock {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GEODATAVIEWDOCK_H
