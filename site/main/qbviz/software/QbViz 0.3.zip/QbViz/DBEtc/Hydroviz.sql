-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema hydroviz
--

CREATE DATABASE IF NOT EXISTS hydroviz;
USE hydroviz;

--
-- Definition of table `datapoints`
--

DROP TABLE IF EXISTS `datapoints`;
CREATE TABLE `datapoints` (
  `id` int(10) unsigned NOT NULL default '0',
  `x` float NOT NULL,
  `y` float NOT NULL,
  `layer` int(10) unsigned NOT NULL,
  `salt` float NOT NULL,
  `vx` float NOT NULL,
  `vy` float NOT NULL,
  `time` float NOT NULL,
  `detail` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_6` USING HASH (`time`,`layer`,`detail`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='InnoDB free: 25600 kB';

--
-- Dumping data for table `datapoints`
--

/*!40000 ALTER TABLE `datapoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `datapoints` ENABLE KEYS */;


--
-- Definition of table `layers`
--

DROP TABLE IF EXISTS `layers`;
CREATE TABLE `layers` (
  `layer` int(10) unsigned NOT NULL auto_increment,
  `z` float NOT NULL,
  PRIMARY KEY  (`layer`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `layers`
--

/*!40000 ALTER TABLE `layers` DISABLE KEYS */;
/*!40000 ALTER TABLE `layers` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
