using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using System.Threading;

using MySql.Data.MySqlClient;

namespace HeightmapGen
{
    class Program
    {
        ///////////////////////////////////////////////////////////////////////////////////////////
        public static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;

            if(args.Length < 2)
            {
                Console.WriteLine(
                    "Command Syntax: HeightmapGen <dataRoot> <imgDest>\n" +
                    "\tdataRoot: the source dataset path.\n" +
                    "\timgDest: the destination path for the generated image.\n");
                return;
            }

            float alpha = 0.6f;
            int xres = 800;
            int yres = 800;

            if(args.Length >= 3)
            {
                alpha = float.Parse(args[2]);
            }
            if(args.Length == 4)
            {
                xres = int.Parse(args[3]);
                yres = xres;
            }

            List<BathymetryDataItem> al = ReadBathymetry(args[0]);

            // Compute the bathymetry boundaries.
            float maxx = 0;
            float maxy = 0;
            float minx = float.MaxValue;
            float miny = float.MaxValue;
            foreach(BathymetryDataItem item in al)
            {
                if(item.X > maxx) maxx = (float)item.X;
                if(item.X < minx) minx = (float)item.X;
                if(item.Y > maxy) maxy = (float)item.Y;
                if(item.Y < miny) miny = (float)item.Y;
            }

            Bitmap bmp = new Bitmap(xres, yres);
            Bitmap resultBmp = new Bitmap(xres, yres);
            float posx = minx;
            float posy = miny;
            float dx = (maxx - minx) / xres;
            float dy = (maxy - miny) / yres;

            Console.WriteLine("Generating bitmap...");
            foreach(BathymetryDataItem item in al)
            {
                int px = (int)((float)(item.X - minx) * (xres - 1) / (maxx - minx));
                int py = (int)((float)(item.Y - miny) * (yres - 1) / (maxy - miny));
                if(bmp.GetPixel(px, py).A != 0)
                {
                    Console.WriteLine("Clash at " + dx + " " + dy);
                }
                else
                {
                    int c = 255 - (int)((item.Depth / 20) * 255);
                    bmp.SetPixel(px, py, Color.FromArgb(255, c, c, c));
                }
            }

            Console.WriteLine("Interpolating");
            BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            byte[] srcData = new byte[(bmp.Width * bmp.Height) * 4];
            System.Runtime.InteropServices.Marshal.Copy(bmpData.Scan0, srcData, 0, srcData.Length);

            bmpData = resultBmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            byte[] destData = new byte[(bmp.Width * bmp.Height) * 4];
            System.Runtime.InteropServices.Marshal.Copy(bmpData.Scan0, destData, 0, destData.Length);

            for(int x = 0; x < xres; x++)
            {
                for(int y = 0; y < yres; y++)
                {
                    int index = (y * xres + x) * 4;
                    if(srcData[index] != 0)
                    {
                        destData[index] = srcData[index];
                        destData[index + 1] = srcData[index + 1];
                        destData[index + 2] = srcData[index + 2];
                        destData[index + 3] = srcData[index + 3];
                    }
                    else
                    {
                        SetInterpolatedPixel(x, y, xres, yres, srcData, destData, alpha);
                    }
                }
                Console.Write(".");
            }

            System.Runtime.InteropServices.Marshal.Copy(destData, 0, bmpData.Scan0, destData.Length);
            resultBmp.UnlockBits(bmpData);
            resultBmp.RotateFlip(RotateFlipType.RotateNoneFlipY);
            resultBmp.Save(args[1] + @"\bathymetry.png", System.Drawing.Imaging.ImageFormat.Png);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        ///     Compute the distance between two points.
        /// </summary>
        private static float GetDist(float x1, float y1, float x2, float y2)
        {
            float dx = x1 - x2;
            float dy = y1 - y2;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        private static ColorSample GetMinDistanceSample(List<ColorSample> samples)
        {
            float res = float.MaxValue;
            ColorSample result = null;
            foreach(ColorSample smp in samples)
            {
                if(smp.Dist < res)
                {
                    res = smp.Dist;
                    result = smp;
                }
            }
            return result;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        private static float GetNearestSample(int x, int y, int width, int height, byte[] data)
        {
            float minDist = float.MaxValue;
            int zoneSize = 16;
            for(int dx = x - zoneSize; dx < x + zoneSize; dx++)
            {
                if(dx > 0 && dx < width)
                {
                    for(int dy = y - zoneSize; dy < y + zoneSize; dy++)
                    {
                        if(dy > 0 && dy < height)
                        {
                            int index = (dy * width + dx) * 4;
                            if(data[index + 3] != 0)
                            {
                                float dist = GetDist(x, y, dx, dy);
                                if(dist > 0 && dist < minDist)
                                {
                                    minDist = dist;
                                }
                            }
                        }
                    }
                }
            }
            return minDist;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        private static float GetMeanIntersampleDistance(List<ColorSample> samples, int width, int height, byte[] data)
        {
            float result = 0;
            int c = 0;
            for(int i = 0; i < samples.Count - 1; i++)
            {
                result += GetNearestSample(samples[i].X, samples[i].Y, width, height, data);
                c++;
            }
            return result / c;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        private static void SetInterpolatedPixel(int x, int y, int width, int height, byte[] src, byte[] dst, float alpha)
        {
            List<ColorSample> samples = new List<ColorSample>();
            int zoneSize = 16;
            for(int dx = x - zoneSize; dx < x + zoneSize; dx++)
            {
                if(dx > 0 && dx < width)
                {
                    for(int dy = y - zoneSize; dy < y + zoneSize; dy++)
                    {
                        if(dy > 0 && dy < height)
                        {
                            int index = (dy * width + dx) * 4;
                            if(src[index + 3] != 0)
                            {
                                float dist = GetDist(x, y, dx, dy);
                                if(dist > 0 && dist <= zoneSize)
                                {
                                    samples.Add(new ColorSample(dx, dy, dist, src[index + 3], src[index + 2], src[index + 1], src[index]));
                                }
                            }
                        }
                    }
                }
            }
            if(samples.Count > 0)
            {
                int index = ((y * width) + x) * 4;
                ColorSample nearSample = GetMinDistanceSample(samples);
                float meandist = GetMeanIntersampleDistance(samples, width, height, src);
                if(nearSample.Dist * alpha > meandist)
                {
                    dst[index + 3] = 0;
                    dst[index + 2] = 0;
                    dst[index + 1] = 0;
                    dst[index] = 0;
                    return;
                }
                dst[index + 3] = 255;

                dst[index + 2] = nearSample.R;
                dst[index + 1] = nearSample.G;
                dst[index] = nearSample.B;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        ///     Reads a bathymetry datafile from the specified dataroot path.
        /// </summary>
        private static List<BathymetryDataItem> ReadBathymetry(string path)
        {
            List<BathymetryDataItem> bathy = new List<BathymetryDataItem>();

            StreamReader reader = new StreamReader(path + @"\ccb_jmbath.txt");
            while(!reader.EndOfStream)
            {
                string record = reader.ReadLine();
                // Skip comment lines.
                if(!record.StartsWith("%"))
                {
                    string[] field = record.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                    int id = int.Parse(field[0]);
                    float x = float.Parse(field[1]);
                    float y = float.Parse(field[2]);
                    float depth = float.Parse(field[3]);

                    bathy.Add(new BathymetryDataItem(x, y, depth));
                }
            }
            reader.Close();
            return bathy;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        private static BathymetryDataItem getBathymetryPoint(double x, double y, ArrayList data)
        {
            double resultDist = double.MaxValue;
            double minDist = 1.0f;
            double maxDist = 2000;
            BathymetryDataItem result = null;
            foreach(BathymetryDataItem item in data)
            {
                double dx = x - item.X;
                double dy = y - item.Y;
                double dist = Math.Sqrt(dx * dx + dy * dy);
                if(dist < minDist)
                {
                    return item;
                }
                if(dist < resultDist)
                {
                    resultDist = dist;
                    result = item;
                }
            }
            if(resultDist < maxDist)
            {
                return result;
            }
            return null;
        }

    }
}
