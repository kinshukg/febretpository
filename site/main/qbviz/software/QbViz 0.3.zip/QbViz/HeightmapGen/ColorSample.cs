using System;
using System.Collections.Generic;
using System.Text;

namespace HeightmapGen
{
    class ColorSample
    {
        public float Dist;
        public int X;
        public int Y;
        public byte A;
        public byte R;
        public byte G;
        public byte B;
        public ColorSample(int x, int y, float dist, byte a, byte r, byte g, byte b)
        {
            X = x;
            Y = y;
            Dist = dist;
            A = a;
            R = r;
            G = g;
            B = b;
        }
    }
}
