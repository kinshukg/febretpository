using System;
using System.Collections.Generic;
using System.Text;

namespace Hydroviz
{
    class DataItem
    {
        public float x;
        public float y;
        public float z;
        public float salt;
        public float vx;
        public float vy;

        public DataItem(float x, float y, float z, float salt, float vx, float vy)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.salt = salt;
            this.vx = vx;
            this.vy = vy;
        }

        public float DistanceTo(DataItem item)
        {
            float dx = x - item.x;
            float dy = y - item.y;
            //float dz = z - item.z;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }
    }
}
