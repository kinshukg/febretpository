using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using QbViz;
using Weborb.Activation;
using MySql.Data.MySqlClient;
using System.IO;
using System.Threading;
using System.Diagnostics;

namespace Hydroviz
{
    public class DataPoint
    {
        public float X;
        public float Y;
        public int Id;

        public DataPoint(int id, float x, float y)
        {
            X = x;
            Y = y;
            Id = id;
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    class LayerData
    {
        public float X;
        public float Y;
        public float VX;
        public float VY;
        public float Salt;

        /////////////////////////////////////////////////////////////////////////////////
        public LayerData(float x, float y, float vx, float vy, float salt)
        {
            X = x;
            Y = y;
            VY = vy;
            VX = vx;
            Salt = salt;
        }
    }

    [ApplicationActivation]
    public class HydrovizService
    {
        private Dictionary<int, float> myLayers;
        private MySqlConnection myConnection;

        /////////////////////////////////////////////////////////////////////////////////
        private MySqlConnection GetConnection()
        {
            if(myConnection == null)
            {
                myConnection = new MySqlConnection("server=localhost;user id=root; password=root; database=mysql; pooling=false");
                myConnection.Open();
                myConnection.ChangeDatabase("hydroviz");
            }
            return myConnection;
        }

        /////////////////////////////////////////////////////////////////////////////////
        private void InitTables()
        {
            Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
            myLayers = new Dictionary<int, float>();
            
            MySqlConnection conn = GetConnection();

            MySqlCommand command = new MySqlCommand();
            command.Connection = conn;
            command.CommandText = "SELECT layer, z FROM layers;";

            MySqlDataReader reader = command.ExecuteReader();
            while(reader.Read())
            {
                myLayers.Add(reader.GetInt32(0), reader.GetFloat(1));
            }
            reader.Close();
        }

        /////////////////////////////////////////////////////////////////////////////////
        private void ReadData(DataBlock db, CubeInfo info)
        {
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);

            Filter x = info.GetFilter("x");
            Filter y = info.GetFilter("y");
            Filter t = info.GetFilter("t");
            Filter layer = info.GetFilter("layer");
            Filter delta = info.GetFilter("delta");

            MySqlConnection conn = GetConnection();
            MySqlCommand command = new MySqlCommand();
            command.Connection = conn;

            string detailQuery = "";
            for(int d = 0; d <= delta.value; d++)
            {
                detailQuery += "detail = " + d + " or ";
            }
            detailQuery = "(" + detailQuery + "false) ";

            string layerQuery = "";
            for(int l = (int)layer.min; l <= (int)layer.max; l += (int)layer.dps)
            {
                layerQuery += "layer = " + l + " or ";
            }
            layerQuery = "(" + layerQuery + "false) ";

            command.CommandText = "SELECT x, y, layer, salt, vx, vy FROM datapoints where " +
                " time = " + (int)t.value +
                " and " + detailQuery +
                " and " + layerQuery +
                " and x <= " + (int)x.max +
                " and x >= " + (int)x.min +
                " and y <= " + (int)y.max +
                " and y >= " + (int)y.min +
                ";";

            MySqlDataReader reader = command.ExecuteReader();

            db.length = 0; //reader.FieldCount;
            //db.data = new byte[db.length * db.GetDataPointSize()];
            MemoryStream stream = new MemoryStream(/*db.data*/);
            BinaryWriter writer = new BinaryWriter(stream);

            while(reader.Read())
            {
                writer.Write(reader.GetFloat(0));
                writer.Write(reader.GetFloat(1));
                writer.Write(myLayers[reader.GetInt32(2)]);
                writer.Write(reader.GetFloat(3));
                writer.Write(reader.GetFloat(4));
                writer.Write(reader.GetFloat(5));

                db.length++;
            }
            reader.Close();

            db.data = stream.GetBuffer();
        }

        /////////////////////////////////////////////////////////////////////////////////
        private List<LayerData> ReadLayerData(int layer, int time)
        {
            MySqlConnection conn = GetConnection();
            MySqlCommand command = new MySqlCommand();
            command.Connection = conn;

            command.CommandText = "SELECT x, y, vx, vy, salt FROM datapoints where " +
                " time = " + time +
                " and detail <= 10 " +
                " and layer = " + layer +
                ";";

            MySqlDataReader reader = command.ExecuteReader();

            List<LayerData> result = new List<LayerData>();
            while(reader.Read())
            {
                result.Add(new LayerData(
                    reader.GetFloat(0),
                    reader.GetFloat(1),
                    reader.GetFloat(2),
                    reader.GetFloat(3),
                    reader.GetFloat(4)));
            }
            reader.Close();

            return result;
        }

        /////////////////////////////////////////////////////////////////////////////////
        private LayerData GetNearestPoint(List<LayerData> layerData, float x, float y)
        {
            float minL = 1000;
            LayerData result = null;
            float minL2 = 1000;
            LayerData result2 = null;
            foreach(LayerData item in layerData)
            {
                float dx = x - item.X;
                float dy = y - item.Y;
                float l = (float)Math.Sqrt(dx*dx + dy*dy);
                if(l < minL)
                {
                    result2 = result;
                    minL2 = minL;
                    minL = l;
                    result = item;
                }
                else if(l < minL2)
                {
                    result2 = item;
                    minL2 = l;
                }
            }
            if(result2 != null)
            {
                float w = minL2 / (minL2 + minL);
                LayerData interp = new LayerData(0, 0, 0, 0, 0);
                interp.VX = result.VX * w + result2.VX * (1 - w);
                interp.VY = result.VY * w + result2.VY * (1 - w);
                interp.Salt = result.Salt * w + result2.Salt * (1 - w);
                return interp;
            }
            return result;
        }

        /////////////////////////////////////////////////////////////////////////////////
        private List<LayerData> ComputeStreamline(List<LayerData> layerData, float x, float y, float length, float dps)
        {
            List<LayerData> result = new List<LayerData>();
            int i = 0;
            int maxLength = (int)(length / dps);

            LayerData pt = null;
            do
            {
                pt = GetNearestPoint(layerData, x, y);
                if(pt != null)
                {
                    float l = (float)Math.Sqrt(pt.VX * pt.VX + pt.VY * pt.VY);
                    result.Add(new LayerData(x, y, l, l, pt.Salt));

                    float dx = pt.VX / l * dps;
                    float dy = pt.VY / l * dps;

                    x += dx;
                    y += dy;

                }
            } while(pt != null && ++i < maxLength);

            return result;
        }
        /////////////////////////////////////////////////////////////////////////////////
        private void ReadStreamline(DataBlock db, CubeInfo info)
        {
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);
            db.AddDefinitionElement(DefinitionElement.Float);

            Filter x = info.GetFilter("x");
            Filter y = info.GetFilter("y");
            Filter t = info.GetFilter("t");
            Filter layer = info.GetFilter("layer");
            Filter length = info.GetFilter("length");

            List<LayerData> layerData = ReadLayerData((int)layer.value, (int)t.value);

            List<LayerData> streamline = ComputeStreamline(layerData, x.value, y.value, length.value, length.dps);

            db.length = streamline.Count; 
            MemoryStream stream = new MemoryStream(/*db.data*/);
            BinaryWriter writer = new BinaryWriter(stream);

            foreach(LayerData item in streamline)
            {
                writer.Write(item.X);
                writer.Write(item.Y);
                writer.Write(item.VX);
                writer.Write(item.Salt);
            }

            db.data = stream.GetBuffer();
        }

        /////////////////////////////////////////////////////////////////////////////////
        public CubeInfo createCube(string cubeName, string datasetName)
        {
            CubeInfo info = new CubeInfo();
            info.dataSetName = datasetName;
            info.serviceName = "Hydroviz.TestRemoteService";
            info.name = cubeName;
            if(datasetName == "Data")
            {
            }
            return info;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public ArrayList getAvailableDataCubes()
        {
            ArrayList res = new ArrayList();
            res.Add("Data");
            res.Add("Streamline");
            return res;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public DataBlock getData(CubeInfo info)
        {
            if(myLayers == null)
            {
                InitTables();
            }

            DataBlock db = new DataBlock();

            if(info.dataSetName == "Data")
            {
                Stopwatch sw = Stopwatch.StartNew();
                ReadData(db, info);
                sw.Stop();
                HydrovizWorkspace.Instance.broadcast(new ChatMessage("PROF", "Layer proc time: " + sw.ElapsedMilliseconds + "ms"));
            }
            else if(info.dataSetName == "Streamline")
            {
                Stopwatch sw = Stopwatch.StartNew();
                ReadStreamline(db, info);
                sw.Stop();
                HydrovizWorkspace.Instance.broadcast(new ChatMessage("PROF", "Streamline proc time: " + sw.ElapsedMilliseconds + "ms"));
            }

            return db;
        }
    }
}
