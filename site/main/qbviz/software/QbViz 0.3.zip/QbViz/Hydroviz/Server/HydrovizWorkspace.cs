using System;
using System.Collections.Generic;
using System.Text;
using Weborb.Activation;
using MySql.Data.MySqlClient;
using QbViz;

namespace Hydroviz
{
    [ApplicationActivation]
    public class HydrovizWorkspace: WorkspaceService
    {
    }
}
