using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    /////////////////////////////////////////////////////////////////////////////////////
    public class DimensionInfo
    {
        private double myMinValue;
        private double myMaxValue;
        private string myName;
        private int myDataPointCount;

        /////////////////////////////////////////////////////////////////////////////////
        public DimensionInfo(string name, double minValue, double maxValue, int dataPoints)
        {
            myName = name;
            myMinValue = minValue;
            myMaxValue = maxValue;
            myDataPointCount = dataPoints;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public DimensionInfo()
        {
        }

        /////////////////////////////////////////////////////////////////////////////////
        public string name
        {
            get
            {
                return myName;
            }
            set
            {
                myName = value;
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public double maxValue
        {
            get
            {
                return myMaxValue;
            }
            set
            {
                myMaxValue = value;
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public double minValue
        {
            get
            {
                return myMinValue;
            }
            set
            {
                myMinValue = value;
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public int dataPointCount
        {
            get
            {
                return myDataPointCount;
            }
            set
            {
                myDataPointCount = value;
            }
        }
    }
}
