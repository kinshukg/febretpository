using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class ChatMessage: WorkspaceMessage
    {
        public string user;
        public string message;

        public ChatMessage(string user, string message)
        {
            this.user = user;
            this.message = message;
        }
    }
}
