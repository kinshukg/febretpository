using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    class ViewAddedMessage: WorkspaceMessage
    {
        public string name;
        public string thumbUrl;

        public ViewAddedMessage(string name, string thumbUrl)
        {
            this.name = name;
            this.thumbUrl = thumbUrl;
        }
    }
}
