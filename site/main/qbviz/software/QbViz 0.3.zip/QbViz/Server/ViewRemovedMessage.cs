using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    class ViewRemovedMessage: WorkspaceMessage
    {
        public string name;

        public ViewRemovedMessage(string name)
        {
            this.name = name;
        }
    }
}
