using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Configuration;
using System.Web.Configuration;
using System.Web;


namespace QbViz
{
    /////////////////////////////////////////////////////////////////////////////////////
    class ViewEntry
    {
        public View View;
        public string ThumbUrl;
        public List<string> Users;

        public ViewEntry(View view, string thumbUrl)
        {
            View = view;
            ThumbUrl = thumbUrl;
            Users = new List<string>();
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////
    public class Workspace: IWorkspace
    {
        #region Private

        // UBERMEGA HACK!!!!
        //private string appRoot = "D:/Workspace/qbviz/www/hydroviz/";
        private string appRoot = HttpContext.Current.Server.MapPath("./../hydroviz/");//"C:/Inetpub/wwwroot/qbviz/hydroviz/";

        private Dictionary<string, User> myUsers;
        private Dictionary<string, ViewEntry> myViews;
        private Stopwatch myTimer;

        /////////////////////////////////////////////////////////////////////////////////
        private bool ProcessCommand(User usr, string cmd)
        {
            string[] args = cmd.Split(' ');

            if(args[0] == "!users")
            {
                string res = "";
                foreach(string usrName in myUsers.Keys)
                {
                    res += usrName + " ";
                }
                usr.Messages.Add(new ChatMessage("RESULT", res));
                return true;
            }
            return false;
        }

        /////////////////////////////////////////////////////////////////////////////////
        private void PruneInactiveUsers()
        {
            long timeout = 30000;
            List<User> deadUsers = new List<User>();
            foreach(User usr in myUsers.Values)
            {
                if(myTimer.ElapsedMilliseconds - usr.LastInteractionTime > timeout)
                {
                    sendMessage(usr.Name, "DISCONNECTED");
                    deadUsers.Add(usr);
                }
            }
            foreach(User usr in deadUsers)
            {
                myUsers.Remove(usr.Name);
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        private void Broadcast(WorkspaceMessage msg)
        {
            foreach(User u in myUsers.Values)
            {
                u.Messages.Add(msg);
            }
        }
        #endregion

        #region Public

        public string name;

        /////////////////////////////////////////////////////////////////////////////////
        public Workspace(string name)
        {
            this.name = name;
            myUsers = new Dictionary<string, User>();
            myViews = new Dictionary<string, ViewEntry>();
            myTimer = Stopwatch.StartNew();
            Utils.Trace("wrkspace created.");
        }

        /////////////////////////////////////////////////////////////////////////////////
        public bool login(string name)
        {
            User ue = new User(name);
            ue.LastInteractionTime = myTimer.ElapsedMilliseconds;
            myUsers.Add(name, ue);

            foreach(ViewEntry ve in myViews.Values)
            {
                ue.Messages.Add(new ViewAddedMessage(ve.View.name, ve.ThumbUrl));
                ue.Messages.Add(new ViewUpdateMessage(ve.View, null, ve.Users));
            }

            return true;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void logout(string name)
        {
            myUsers.Remove(name);
            foreach(ViewEntry ve in myViews.Values)
            {
                if(ve.Users.Contains(name))
                {
                    ve.Users.Remove(name);
                    foreach(User u in myUsers.Values)
                    {
                        u.Messages.Add(new ViewUpdateMessage(ve.View, null, ve.Users));
                    }
                }
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void getView(string usrName, string name)
        {
            if(myUsers.ContainsKey(usrName) && myViews.ContainsKey(name))
            {
                View v = myViews[name].View;
                User usr = myUsers[usrName];

                usr.Messages.Add(new ViewUpdateMessage(v));
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void sendMessage(string usrName, string message)
        {
            if(myUsers.ContainsKey(usrName))
            {
                User usr = myUsers[usrName];
                bool isCommand = false;
                if(message.StartsWith("!"))
                {
                    isCommand = ProcessCommand(usr, message);
                }
                if(!isCommand)
                {
                    foreach(User u in myUsers.Values)
                    {
                        u.Messages.Add(new ChatMessage(usr.Name, message));
                    }
                }
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public List<WorkspaceMessage> poll(string name)
        {
            if(myUsers.ContainsKey(name))
            {
                User usr = myUsers[name];
                usr.LastInteractionTime = myTimer.ElapsedMilliseconds;

                PruneInactiveUsers();

                List<WorkspaceMessage> result = usr.Messages;
                usr.Messages = new List<WorkspaceMessage>();
                return result;
            }
            return null;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void broadcast(WorkspaceMessage msg)
        {
            foreach(User u in myUsers.Values)
            {
                u.Messages.Add(msg);
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void addView(View view, byte[] data)
        {
            string thumbUrl = "./data/thumb_" + Utils.GetRandomId() + ".png";
            string thumbPath = appRoot + thumbUrl;
            File.WriteAllBytes(thumbPath, data);

            if(myViews.ContainsKey(view.name))
            {
                removeView(view.name);
            }

            myViews.Add(view.name, new ViewEntry(view, thumbUrl));

            foreach(User u in myUsers.Values)
            {
                u.Messages.Add(new ViewAddedMessage(view.name, thumbUrl));
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void attachToView(string name, string viewName)
        {
            if(myViews.ContainsKey(viewName))
            {
                myViews[viewName].Users.Add(name);
                foreach(User u in myUsers.Values)
                {
                    View view = new View();
                    view.name = viewName;
                    u.Messages.Add(new ViewUpdateMessage(view, null, myViews[viewName].Users));
                }
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void detachFromView(string name, string viewName)
        {
            if(myViews.ContainsKey(viewName))
            {
                myViews[viewName].Users.Remove(name);
                foreach(User u in myUsers.Values)
                {
                    View view = new View();
                    view.name = viewName;
                    u.Messages.Add(new ViewUpdateMessage(view, null, myViews[viewName].Users));
                }
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void updateView(string name, View view, bool cameraUpdate)
        {
            if(myViews.ContainsKey(view.name))
            {
                myViews[view.name].View = view;
                foreach(User u in myUsers.Values)
                {
                    // TODO: send view updates only to attached users.
                    if(u.Name != name)
                    {
                        u.Messages.Add(new ViewUpdateMessage(view, null, cameraUpdate));
                    }
                }
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void removeView(string name)
        {
            if(myViews.ContainsKey(name))
            {
                ViewEntry v = myViews[name];
                string thumbPath = appRoot + v.ThumbUrl;
                File.Delete(thumbPath);
                foreach(User u in myUsers.Values)
                {
                    u.Messages.Add(new ViewRemovedMessage(name));
                }
                myViews.Remove(name);
            }
        }

        #endregion
    }
}
