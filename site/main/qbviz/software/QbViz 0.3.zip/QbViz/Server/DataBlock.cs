using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    /////////////////////////////////////////////////////////////////////////////////////
    public class DataBlock
    {
        /////////////////////////////////////////////////////////////////////////////////
        public DataBlock()
        {
            extraData = new Hashtable();
            dataDefinition = new ArrayList();
        }

        /////////////////////////////////////////////////////////////////////////////////
        public int GetDataPointSize()
        {
            int size = 0;
            foreach(DefinitionElement de in dataDefinition)
            {
                size += de.GetSize();
            }
            return size;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void AddDefinitionElement(int type)
        {
            dataDefinition.Add(new DefinitionElement(type));
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void AddDefinitionElement(int type, string name)
        {
            dataDefinition.Add(new DefinitionElement(type, name));
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void AddDefinitionElement(int type, string name, string unit)
        {
            dataDefinition.Add(new DefinitionElement(type, name, unit));
        }

        /////////////////////////////////////////////////////////////////////////////////
        public byte[] data;
        public Hashtable extraData;
        public ArrayList dataDefinition;
        public int length;
    }
}
