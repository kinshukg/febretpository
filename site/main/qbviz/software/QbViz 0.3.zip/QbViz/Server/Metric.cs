using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class Metric
    {
        public string name;
        public float offset;
        public float multiplier;
    }
}
