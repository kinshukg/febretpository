using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class DefinitionElement
    {
        public const int Double = 1;
        public const int Float = 2;
        public const int Int = 3;

        public int type;
        public string name;
        public string unit;

        public DefinitionElement(int type, string name, string unit)
        {
            this.type = type;
            this.name = name;
            this.unit = unit;
        }
        public DefinitionElement(int type, string name)
            : this(type, name, null)
        {
        }
        public DefinitionElement(int type)
            : this(type, null, null)
        {
        }

        public int GetSize()
        {
            switch(type)
            {
                case Float:
                case Int:
                    return 4;
                case Double:
                    return 8;
            }
            return 0;
        }
    }
}
