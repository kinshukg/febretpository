using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class WorkspaceService: IWorkspace
    {
        private static Workspace myWorkspace;

        public static Workspace Instance
        {
            get
            {
                if(myWorkspace == null)
                {
                    myWorkspace = new Workspace("Hydroviz");
                }
                return myWorkspace;
            }
        }

        #region IWorkspace Members

        public bool login(string name)
        {
            return Instance.login(name);
        }

        public void logout(string name)
        {
            Instance.logout(name);
        }

        public void sendMessage(string usrName, string message)
        {
            Instance.sendMessage(usrName, message);
        }

        public List<WorkspaceMessage> poll(string name)
        {
            return Instance.poll(name);
        }

        public void addView(View view, byte[] data)
        {
            Instance.addView(view, data);
        }

        public void detachFromView(string name, string viewName)
        {
            Instance.detachFromView(name, viewName);
        }

        public void attachToView(string name, string viewName)
        {
            Instance.attachToView(name, viewName);
        }

        public void getView(string usrName, string viewName)
        {
            Instance.getView(usrName, viewName);
        }

        public void removeView(string name)
        {
            Instance.removeView(name);
        }

        public void updateView(string name, View view, bool cameraUpdate)
        {
            Instance.updateView(name, view, cameraUpdate);
        }

        #endregion
    }
}
