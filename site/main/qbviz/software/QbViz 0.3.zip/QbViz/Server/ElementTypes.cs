using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class ElementTypes
    {
        public static string Scalar = "scalar";
        public static string Vector2 = "vector2";
        public static string Vector3 = "vector3";
        public static string Vector4 = "vector4";
    }
    public class Vector2
    {
        public Vector2(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
        public Vector2()
        {
        }
        public double x;
        public double y;
    }
    public class Vector3
    {
        public Vector3(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }
        public Vector3()
        {
        }
        public double x;
        public double y;
        public double z;
    }
}
