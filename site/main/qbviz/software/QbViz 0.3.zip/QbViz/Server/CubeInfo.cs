using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class CubeInfo
    {
        public Boolean dirty;
        public string name;
        public string dataSetName;
        public string serviceName;
        public List<Filter> filters;
        //public ArrayList dataElements;
        /*public Filter x;
        public Filter y;
        public Filter z;
        public Filter t;
        public Filter u;
        public Filter v;
        public Filter w;*/

        public Filter GetFilter(string name)
        {
            foreach(Filter filter in filters)
            {
                if(filter.name == name)
                {
                    return filter;
                }
            }
            return null;
        }

        public CubeInfo()
        {
            //dataElements = new ArrayList();
        }
    }
}
