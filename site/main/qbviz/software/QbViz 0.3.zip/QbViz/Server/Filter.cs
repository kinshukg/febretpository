using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class FilterTypes
    {
        public const string Interval = "interval";
        public const string Point = "point";
    }

    public class Filter
    {
        public float min;
        public float max;
        public float value;
        public float dps;
        public string key;
        public string unit;
        public string name;
        public string type;

        public Filter()
        {
        }

        public static Filter CreatePoint(float value, string name, string unit)
        {
            Filter filter = new Filter();
            filter.type = FilterTypes.Point;
            filter.name = name;
            filter.unit = unit;
            filter.value = value;
            return filter;
        }

        public static Filter CreateInterval(float min, float max, float dps, string name, string unit)
        {
            Filter filter = new Filter();
            filter.type = FilterTypes.Interval;
            filter.name = name;
            filter.unit = unit;
            filter.min = min;
            filter.max = max;
            filter.dps = dps;
            return filter;
        }

        public float getSize()
        {
            return max - min;
        }

        public float getDelta()
        {
            return (max - min) / dps;
        }
    }
}
