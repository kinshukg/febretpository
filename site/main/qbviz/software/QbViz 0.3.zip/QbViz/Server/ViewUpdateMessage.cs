using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public class ViewUpdateMessage: WorkspaceMessage
    {
        public View view;
        public string thumbUrl;
        public bool cameraUpdate;
        public bool stateUpdate;
        public List<string> users;

        public ViewUpdateMessage(View view)
        {
            this.view = view;
            this.stateUpdate = false;
        }

        public ViewUpdateMessage(View view, string thumbUrl)
        {
            this.view = view;
            this.thumbUrl = thumbUrl;
            this.stateUpdate = false;
        }

        public ViewUpdateMessage(View view, string thumbUrl, bool cameraUpdate)
        {
            this.view = view;
            this.thumbUrl = thumbUrl;
            this.cameraUpdate = cameraUpdate;
            this.stateUpdate = false;
        }

        public ViewUpdateMessage(View view, string thumbUrl, List<string> users)
        {
            this.view = view;
            this.thumbUrl = thumbUrl;
            this.stateUpdate = true;
            this.users = users;
        }
    }
}
