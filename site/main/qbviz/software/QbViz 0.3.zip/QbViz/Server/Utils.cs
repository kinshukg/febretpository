using System;
using System.Collections.Generic;
using System.Text;
using Weborb.Util.Logging;

namespace QbViz
{
    /////////////////////////////////////////////////////////////////////////////////////
    public class Utils
    {
        private static Random myRandomGenerator;

        /////////////////////////////////////////////////////////////////////////////////
        public static DimensionInfo GetDimension(string name, DimensionInfo[] dims)
        {
            foreach(DimensionInfo di in dims)
            {
                if(di.name == name)
                {
                    return di;
                }
            }
            return null;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public static double GetDelta(DimensionInfo dimension)
        {
            return (dimension.maxValue - dimension.minValue) / dimension.dataPointCount;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public static void Trace(string message)
        {
            Log.log("MYLOG", message);
        }

        /////////////////////////////////////////////////////////////////////////////////
        public static string GetRandomId()
        {
            byte[] bytes = new byte[4];
            if(myRandomGenerator == null)
            {
                myRandomGenerator = new Random();
            }
            myRandomGenerator.NextBytes(bytes);
            string res = "";
            bool ln = false;
            foreach(byte b in bytes)
            {
                res += Utils.ByteToHex((byte)(b & 0x0F));
                res += Utils.ByteToHex((byte)(b >> 4));
                if(ln)
                {
                    res += "_";
                }
                ln = !ln;
            }
            return res.TrimEnd('_');
        }
        public static char ByteToHex(byte b)
        {
            switch(b)
            {
                case 0:
                    return '0';
                case 1:
                    return '1';
                case 2:
                    return '2';
                case 3:
                    return '3';
                case 4:
                    return '4';
                case 5:
                    return '5';
                case 6:
                    return '6';
                case 7:
                    return '7';
                case 8:
                    return '8';
                case 9:
                    return '9';
                case 10:
                    return 'A';
                case 11:
                    return 'B';
                case 12:
                    return 'C';
                case 13:
                    return 'D';
                case 14:
                    return 'E';
                case 15:
                    return 'F';
            }
            return '0';
        }
    }
}
