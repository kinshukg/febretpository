using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    /////////////////////////////////////////////////////////////////////////////////////
    public interface IRemoteDataService
    {
        CubeInfo createCube(string cubeName, string datasetName);
        DataBlock getData(CubeInfo info);
        ArrayList getAvailableDataCubes();
    }
}
