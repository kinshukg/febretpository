using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    public interface IWorkspace
    {
        bool login(string name);
        void logout(string name);
        void sendMessage(string usrName, string message);
        List<WorkspaceMessage> poll(string name);
        void addView(View view, byte[] data);
        void getView(string usrName, string name);
        void removeView(string name);
        void updateView(string name, View view, bool cameraUpdate);
    }
}
