using System;
using System.Collections.Generic;
using System.Text;
using Weborb.Activation;

namespace QbViz
{
    [ApplicationActivation]
    public class WorkspaceManager
    {
        private Dictionary<string, Workspace> myWorkspaces;

        public static WorkspaceManager Instance;

        public WorkspaceManager()
        {
            Instance = this;
            myWorkspaces = new Dictionary<string, Workspace>();
        }

        public Workspace getWorkspace(string name)
        {
            if(!myWorkspaces.ContainsKey(name))
            {
                myWorkspaces.Add(name, new Workspace(name));
            }

            return myWorkspaces[name];
        }
    }
}
