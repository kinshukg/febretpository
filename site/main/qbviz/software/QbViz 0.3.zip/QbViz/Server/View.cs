using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace QbViz
{
    public class View
    {
        public string name;
        public float rotX;
        public float rotY;
        public float rotZ;
        public float zoom;
        public List<Metric> metrics;
        public List<CubeInfo> cubes;
        public List<VisualizerInfo> visualizers;
    }
}
