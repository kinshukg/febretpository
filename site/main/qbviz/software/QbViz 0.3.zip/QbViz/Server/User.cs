using System;
using System.Collections.Generic;
using System.Text;

namespace QbViz
{
    /////////////////////////////////////////////////////////////////////////////////////
    class User
    {
        public string Name;
        public List<WorkspaceMessage> Messages;
        public long LastInteractionTime;

        public User(string name)
        {
            Name = name;
            Messages = new List<WorkspaceMessage>();
        }
    }
}
