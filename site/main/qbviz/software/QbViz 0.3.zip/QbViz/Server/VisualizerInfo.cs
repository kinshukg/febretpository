using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace QbViz
{
    public class VisualizerInfo
    {
        public Boolean dirty;
        public int refreshType;
        public int x;
        public int y;
        public int z;
        public int t;
        public string name;
        public string cubeName;
        public string type;
        public bool visible;
        public List<Property> properties;
        public bool enableImpostors;
    }
}
