using System;
using System.Collections.Generic;
using System.Text;

namespace DBUpdater
{
    public class ConsoleProgressIndicator
    {
        private float myProgress;
        private float myLastProgress;
        private int myProgressPts;
        private int myProgressPercent;

        /////////////////////////////////////////////////////////////////////////////////
        public void Reset()
        {
            myProgress = 0;
            myLastProgress = 0;
            myProgressPts = 0;
            myProgressPercent = 0;
        }

        /////////////////////////////////////////////////////////////////////////////////
        public void Update(float progress, bool showPercent)
        {
            myProgress += progress;
            if(myProgress - myLastProgress >= 0.01f)
            {
                myLastProgress = myProgress;
                Console.Write(".");
                if(showPercent)
                {
                    myProgressPts++;
                    if(myProgressPts == 10)
                    {
                        myProgressPts = 0;
                        myProgressPercent++;
                        Console.Write(myProgressPercent.ToString() + "0%");
                    }
                }
            }
        }
    }
}
