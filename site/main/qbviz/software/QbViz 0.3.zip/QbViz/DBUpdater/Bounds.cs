using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace DBUpdater
{
    public class Bounds
    {
        public float maxX;
        public float minX;
        public float maxY;
        public float minY;
        public float maxSalt;
        public float minSalt;
        public float maxVX;
        public float minVX;
        public float maxVY;
        public float minVY;
        public float minZ;
        public float maxZ;

        public Bounds()
        {
            minSalt = float.MaxValue;
            minX = float.MaxValue;
            minY = float.MaxValue;
            minZ = float.MaxValue;
            minVX = float.MaxValue;
            minVY = float.MaxValue;
            maxSalt = 0;
            maxX = 0;
            maxY = 0;
            maxZ = 0;
            maxVX = 0;
            maxVY = 0;
        }

        public void Save(string path)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Bounds));
            serializer.Serialize(new StreamWriter(path), this);
        }
    }
}
