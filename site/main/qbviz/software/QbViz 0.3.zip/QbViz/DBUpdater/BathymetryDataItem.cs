using System;
using System.Collections.Generic;
using System.Text;

namespace DBUpdater
{
    class BathymetryDataItem
    {
        public double X;
        public double Y;
        public double Depth;

        public BathymetryDataItem(double x, double y, double depth)
        {
            X = x;
            Y = y;
            Depth = depth;
        }
    }
}
