using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;
using System.Drawing;
using System.Drawing.Imaging;
using MySql.Data.MySqlClient;

namespace DBUpdater
{
    ///////////////////////////////////////////////////////////////////////////////////////////////
    class DataIndex: IEquatable<DataIndex>
    {
        public int PointID;
        public int LayerID;
        public float Time;

        public override int GetHashCode()
        {
            return (PointID + (LayerID << 16)) ^ (int)Time;
        }

        public DataIndex(int pointID, int layerID, float time)
        {
            PointID = pointID;
            LayerID = layerID;
            Time = time;
        }

        #region IEquatable<DataIndex> Members

        public bool Equals(DataIndex other)
        {
            return (PointID == other.PointID) && (LayerID == other.LayerID) && ((int)Time == (int)other.Time);
        }

        #endregion
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    class DataPoint
    {
        public float VelX;
        public float VelY;
        public float X;
        public float Y;
        public float Z;
        public float Time;
        public int Detail;
        public int Id;
        public float Salt;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    class Coord
    {
        public const int InvalidDetail = -1;

        public float X;
        public float Y;
        public int Detail;

        /////////////////////////////////////////////////////////////////////////////////
        public Coord(float x, float y)
        {
            X = x;
            Y = y;
            Detail = 0;
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////
    class Program
    {
        private static Dictionary<int, Coord> myCoords;
        private static Dictionary<int, float> myLayers;
        private static Bounds myBounds;
        private static Dictionary<DataIndex, DataPoint> myData;

        private static string myDataRoot;
        private static string myDBMSAddr;
        private static string myDBMSUser;
        private static string myDBMSPassword;
        
        /////////////////////////////////////////////////////////////////////////////////
        public static void Main(string[] args)
        {
            if(args.Length != 5)
            {
                return;
            }
            else
            {
                myDataRoot = args[0];
                myDBMSAddr = args[2];
                myDBMSUser = args[3];
                myDBMSPassword = args[4];
            }

            Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;

            // Config
            Config.Load();

            Config.Instance.DataSrcPath = myDataRoot;
            Config.Instance.DataDestPath = args[1];
            Config.Instance.ConnectionString =
                "server=" + myDBMSAddr +
                ";user id=" + myDBMSUser +
                ";password=" + myDBMSPassword + ";database=mysql; pooling=false";

            myBounds = new Bounds();

            LoadCoordLookup();
            LoadLayerLookup();
            GenerateDetailLevels();
            ReadData();
            WriteDB();

            myBounds.Save(Config.Instance.DataDestPath + @"\" + Config.Instance.BoundsFilename + ".xml");

            Console.ReadKey();
        }

        /////////////////////////////////////////////////////////////////////////////////
        private static float GetDist(float x1, float y1, float x2, float y2)
        {
            float dx = x1 - x2;
            float dy = y1 - y2;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }

        /////////////////////////////////////////////////////////////////////////////////
        private static void SetBounds(float val, ref float max, ref float min)
        {
            if(val > max)
            {
                max = val;
            }
            if(val < min)
            {
                max = min;
            }
        }

        /////////////////////////////////////////////////////////////////////////////////
        private static void LoadCoordLookup()
        {
            Console.Write("Loading coord lookup table...");

            myCoords = new Dictionary<int, Coord>();

            StreamReader reader = new StreamReader(Config.Instance.DataSrcPath + @"\ccb_jmbath.txt");
            while(!reader.EndOfStream)
            {
                string record = reader.ReadLine();

                string[] field = record.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                int id = int.Parse(field[0]);
                float x = float.Parse(field[1]);
                float y = float.Parse(field[2]);

                SetBounds(x, ref myBounds.maxX, ref myBounds.minX);
                SetBounds(x, ref myBounds.maxY, ref myBounds.minY);

                myCoords.Add(id, new Coord(x, y));
            }
            reader.Close();

            Console.WriteLine("OK");
        }

        /////////////////////////////////////////////////////////////////////////////////
        private static void GenerateDetailLevels()
        {
            Console.Write("Generating detail levels...");

            float dist = Config.Instance.MinDetailDistance;
            float distStep = (Config.Instance.MinDetailDistance - Config.Instance.MaxDetailDistance) / 
                Config.Instance.DetailLevels;
            for(int lod = 0; lod < Config.Instance.DetailLevels; lod++)
            {
                for(int i = 1; i <= myCoords.Count; i++)
                {
                    Coord pt1 = myCoords[i];
                    if(pt1.Detail <= lod)
                    {
                        for(int j = i + 1; j <= myCoords.Count; j++)
                        {
                            Coord pt2 = myCoords[j];
                            if(GetDist(pt1.X, pt1.Y, pt2.X, pt2.Y) < dist)
                            {
                                if(pt2.Detail == lod)
                                {
                                    pt2.Detail = lod + 1;
                                }
                                //break;
                            }
                        }
                    }
                }
                dist -= distStep;
            }

            float mean = 0;
            foreach(Coord c in myCoords.Values)
            {
                mean += c.Detail;
            }
            mean = mean / myCoords.Count;

            Console.WriteLine("OK. Mean detail level: " + mean);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        ///     Loads the layer lookup table from a text file.
        /// </summary>
        public static void LoadLayerLookup()
        {
            Console.Write("Loading layer lookup table...");

            myLayers = new Dictionary<int, float>();

            StreamReader reader = new StreamReader(Config.Instance.DataSrcPath + @"\layer_to_z.txt");
            string line = reader.ReadLine();
            while(line != null)
            {
                if(line.Trim().Length > 0)
                {
                    string[] field = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                    int layer = (int)(int.Parse(field[0]));
                    float z = float.Parse(field[1]);

                    myLayers.Add(layer, z);

                    SetBounds(z, ref myBounds.maxZ, ref myBounds.minZ);
                }
                line = reader.ReadLine();
            }
            reader.Close();

            Console.WriteLine("OK");
        }

        /////////////////////////////////////////////////////////////////////////////////
        private static void ReadData()
        {
            Console.WriteLine("Reading source data...");

            myData = new Dictionary<DataIndex, DataPoint>();
            ConsoleProgressIndicator progress = new ConsoleProgressIndicator();

            string fileName = Config.Instance.SalinityFilePrefix;
            for(int fileID = 1; fileID <= 4; fileID++)
            {
                StreamReader reader = new StreamReader(
                    Config.Instance.DataSrcPath + @"\" + fileName + fileID.ToString() + ".txt");

                Console.Write(fileName + fileID.ToString());

                progress.Reset();
                string line = reader.ReadLine();
                while(line != null)
                {
                    if(line[0] != '!' && line.Trim().Length > 0)
                    {
                        // Read & parse data fields.
                        string[] field = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                        float time = float.Parse(field[0]);
                        int layer = int.Parse(field[2]);
                        int ptID = int.Parse(field[1]);
                        float value = float.Parse(field[3]);

                        DataPoint dp = new DataPoint();
                        dp.Salt = value;
                        myData.Add(new DataIndex(ptID, layer, time), dp);

                        progress.Update(0.0000005f, false);
                    }
                    line = reader.ReadLine();
                }
                reader.Close();
            }

            fileName = Config.Instance.VelocityFilePrefix;
            for(int fileID = 1; fileID <= 4; fileID++)
            {
                StreamReader reader = new StreamReader(Config.Instance.DataSrcPath + @"\" + fileName + fileID.ToString() + ".txt");
                Console.Write(fileName + fileID.ToString());
                progress.Reset();
                string line = reader.ReadLine();
                while(line != null)
                {
                    if(line[0] != '!' && line.Trim().Length > 0)
                    {
                        string[] field = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                        float time = float.Parse(field[0]);
                        int layer = int.Parse(field[2]);
                        int ptID = int.Parse(field[1]);
                        float vx = float.Parse(field[3]);
                        float vy = float.Parse(field[4]);

                        DataPoint pt = myData[new DataIndex(ptID, layer, time)];
                        pt.VelX = vx;
                        pt.VelY = vy;

                        progress.Update(0.0000005f, false);
                    }
                    line = reader.ReadLine();
                }
                reader.Close();
            }
            Console.WriteLine("Done!");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        public static void WriteDB()
        {
            Console.Write("Connecting to DB...");
            
            MySqlConnection conn = new MySqlConnection(Config.Instance.ConnectionString);
            conn.Open();
            conn.ChangeDatabase("hydroviz");

            Console.WriteLine("OK");


            Console.Write("Deleting old data...");

            MySqlCommand command = new MySqlCommand();
            command.Connection = conn;
            command.CommandText = "DELETE FROM datapoints";
            command.ExecuteNonQuery();
            command.CommandText = "DELETE FROM layers";
            command.ExecuteNonQuery();

            Console.WriteLine("OK");

            Console.Write("Writing data");

            foreach(KeyValuePair<int, float> item in myLayers)
            {
                command.CommandText = "INSERT INTO layers VALUES (" + 
                    item.Key + ", " + 
                    item.Value + ")";
                command.ExecuteNonQuery();
            }

            ConsoleProgressIndicator progress = new ConsoleProgressIndicator();

            int insertSize = 1000;
            int count = myData.Count;
            int pointID = 0;
            int insertCount = 0;
            string curQuery = "";
            foreach(DataIndex index in myData.Keys)
            {
                DataPoint dp = myData[index];

                //float z = myLayers[index.LayerID];
                Coord coord = myCoords[index.PointID];

                string value = "(";
                value += pointID.ToString() + ", " +
                    coord.X + ", " +
                    coord.Y + ", " +
                    index.LayerID + ", " + //z + ", " +
                    dp.Salt + ", " +
                    dp.VelX + ", " +
                    dp.VelY + ", " +
                    index.Time + ", " +
                    coord.Detail + ")";

                pointID++;
                insertCount++;
                if(insertCount < insertSize && pointID < count)
                {
                    curQuery += value + ", ";
                }
                else
                {
                    insertCount = 0;
                    curQuery += value + ";";
                    command.CommandText = "INSERT INTO datapoints VALUES " + curQuery;
                    command.ExecuteNonQuery();
                    curQuery = "";
                    progress.Update(((float)insertSize) / count, true);
                }
            }

            conn.Close();
            Console.WriteLine("OK");
        }
    }
}
