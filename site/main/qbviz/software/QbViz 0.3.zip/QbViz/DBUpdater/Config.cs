using System;
using System.Collections.Generic;
using System.Text;

namespace DBUpdater
{
    /////////////////////////////////////////////////////////////////////////////////////
    class Config
    {
        public static Config Instance;
        public string DataSrcPath;
        public string DataDestPath;
        public string SalinityFilePrefix;
        public string VelocityFilePrefix;
        public string BathymetryFileName;
        public string BoundsFilename;
        public string ConnectionString;
        public int DetailLevels;
        public float MinDetailDistance;
        public float MaxDetailDistance;

        public static void Load()
        {
            Instance = new Config();
            Instance.DataSrcPath = @"..\..\..\datasrc\";
            Instance.DataDestPath = @"..\..\..\www\hydroviz\data\";
            Instance.SalinityFilePrefix = "salt";
            Instance.VelocityFilePrefix = "vel";
            Instance.BathymetryFileName = "ccb_jmbath";
            Instance.BoundsFilename = "bounds";
            Instance.MaxDetailDistance = 0;
            Instance.MinDetailDistance = 1200;
            Instance.DetailLevels = 10;
            Instance.ConnectionString = "server=argo;user id=root; password=root; database=mysql; pooling=false";
        }
    }
}
