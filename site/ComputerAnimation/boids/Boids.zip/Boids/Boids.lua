--------------------------------------------------------------------------------
-- init_scene
--	Creates the basic initial scene.
--------------------------------------------------------------------------------
function init_scene()
	E.enable_timer(true)
	
	rotate = false
	move = false
	zoom = false
	drag = false
	
	state_begin = 1
	state_intro = 2
	state_idle = 3
	state_animation = 4
	show_gui = false
	
	state = state_begin

	mouse_x = 0
	mouse_y = 0
	
	time = 0
	
	optimization_window = 0
	
	boid_chars = {"i","I","j","J","l","L","f","F","t","T", "(", ")",
				  "{","}","[","]"}

	-- This table will contain all the boids in the flock.
	boids = {}
	nonboids = {}

	predator = {0, 0}

	bh_target = 
	{
		speed = 8,
		steer_friction = 5,
		avoidance_dist = 0,
		coordination_dist = 0,
		coordination = 0.4,
		optimization = 0,
		name = "Target Rule Only"
	}	
	
	bh_collision = 
	{
		speed = 8,
		steer_friction = 5,
		avoidance_dist = 1,
		coordination_dist = 0,
		coordination = 0.4,
		optimization = 0,
		name = "Target + Avodidance Rules"
	}	
	
	bh_coordination = 
	{
		speed = 8,
		steer_friction = 5,
		avoidance_dist = 1,
		coordination_dist = 2,
		coordination = 0.4,
		optimization = 0,
		name = "Target + Avoidance + Coordination Rules"
	}	
	
	bh_manyboids = 
	{
		speed = 9,
		steer_friction = 8,
		avoidance_dist = 0.5,
		coordination_dist = 1,
		coordination = 0.6,
		optimization = 6,
		name = "200 Boids"
	}	
	
	bh_target.next = bh_collision
	bh_collision.next = bh_coordination
	bh_coordination.next = bh_manyboids
	bh_manyboids.next = bh_target

	behavior = bh_target
	
	-- Initialize the gui
	create_gui()
	E.set_background(1.0, 1.0, 1.0, 0.1, 0.2, 0.4)
	
	-- Create scene camera
	camera = E.create_camera(E.camera_type_perspective)
	camera_x = 0
	camera_z = 0
	camera_dist = 100
	camera_angle_x = 0
	camera_angle_y = -20

	-- Create scene light
	light = E.create_light(E.light_type_positional)
	E.parent_entity(light, camera)
	E.set_entity_position(light, 0, 300, 200)
	
	-- Every scene object will be attached to this pivot.
	scene = E.create_pivot()
	E.parent_entity(scene, light)
	
	-- Create the predator and food markers.
	predator_marker = create_marker(1, 0, 0)
	E.parent_entity(predator_marker, scene)
	E.set_entity_geom_type(
		predator_marker, 
		E.geom_type_box, 
		1.5, 1, 1.5)
	E.set_entity_position(predator_marker, 5, 0.3, 5)
	E.set_entity_rotation(predator_marker, 0, 0, 0)
	--E.set_entity_flags(predator_marker, E.entity_flag_visible_geom, true)
	E.set_entity_geom_attr(predator_marker, E.geom_attr_category, 1)

	food_marker = create_marker(0, 0, 1)
	E.parent_entity(food_marker, scene)
	E.set_entity_geom_type(
		food_marker, 
		E.geom_type_box, 
		1.5, 1, 1.5)
	E.set_entity_position(food_marker, 0, 0.1, -5)
	E.set_entity_rotation(food_marker, 0, 0, 0)
	--E.set_entity_flags(food_marker, E.entity_flag_visible_geom, true)
	E.set_entity_geom_attr(food_marker, E.geom_attr_category, 1)
	
	cup = create_cup(1, 1, 0.8)
	E.parent_entity(cup, scene)
	E.set_entity_geom_type(
		cup, 
		E.geom_type_box, 
		4, 12, 4)
	E.set_entity_position(cup, 10, 1, -10)
	E.set_entity_rotation(cup, 0, 20, 0)
	--E.set_entity_flags(cup, E.entity_flag_visible_geom, true)
	E.set_entity_geom_attr(cup, E.geom_attr_category, 1)
	
	-- Create a couple of pieces of paper.
	paper = create_paper()
	E.set_entity_position(paper, 0, -0.1, 0)
	paper2 = create_paper()
	E.set_entity_position(paper2, 4, -0.2, 0)
	E.set_entity_rotation(paper2, 0, 20, 0)
	paper3 = create_paper()
	E.parent_entity(paper, scene)
	E.parent_entity(paper2, scene)
	
	-- Create the desk
	desk = create_desk()
	E.set_entity_position(desk, 0, -2.5, 0)
	E.parent_entity(desk, scene)
	
	-- Initialize the mouse ray
	mouse_ray = E.create_pivot()
	E.parent_entity(mouse_ray, camera)
	E.set_entity_geom_attr(mouse_ray, E.geom_attr_category, 1)
	
	dofile("Text.txt")
	
end

function create_marker(red, green, blue)
	local marker = E.create_pivot()
	local marker_main = E.create_object("marker.obj")
	local marker_outline = E.create_object("marker.obj")

	E.parent_entity(marker, scene)
	E.parent_entity(marker_main, marker)
	E.parent_entity(marker_outline, marker)
	
	local b = E.create_brush()
	E.set_brush_color(b, red, green, blue, 1.0)
	E.set_mesh(marker_main, 0, b)
	E.set_entity_position(marker_main, 0, 0, 0)
	
	E.set_entity_scale(marker_outline, 1.2, 1.2, 1.2)
	E.set_entity_position(marker_outline, 0, 0, 0)
	b = E.create_brush()
	E.set_brush_color(b, 0.0, 0.0, 0.0, 1.0)
	E.set_brush_flags(b, E.brush_flag_transparent, true)
	E.set_mesh(marker_outline, 0, b)
	
	
	return marker
end

function create_cup(red, green, blue)
	local marker = E.create_pivot()
	local marker_main = E.create_object("cup.obj")
	local marker_outline = E.create_object("cup.obj")

	E.parent_entity(marker, scene)
	E.parent_entity(marker_main, marker)
	E.parent_entity(marker_outline, marker)
	
	local b = E.create_brush()
	E.set_brush_color(b, red, green, blue, 1.0)
	E.set_mesh(marker_main, 0, b)
	E.set_entity_position(marker_main, 0, 0, 0)
	
	E.set_entity_scale(marker_outline, 1.1, 1, 1.1)
	E.set_entity_position(marker_outline, 0, 0, 0)
	b = E.create_brush()
	E.set_brush_color(b, 0.0, 0.0, 0.0, 1.0)
	E.set_brush_flags(b, E.brush_flag_transparent, true)
	E.set_mesh(marker_outline, 0, b)
	
	
	return marker
end

function create_paper()
	local paper = E.create_pivot()

	paper_main = E.create_object("Paper.obj")
	paper_outline = E.create_object("Paper.obj")

	E.parent_entity(paper_main, paper)
	E.parent_entity(paper_outline, paper)
	
	local b = E.create_brush()
	E.set_brush_color(b, 1.0, 1.0, 1.0, 1.0)
	E.set_mesh(paper_main, 0, b)
	
	E.set_entity_scale(paper_outline, 1.02, 1.02, 1.02)
	b = E.create_brush()
	E.set_brush_color(b, 0.0, 0.0, 0.0, 1.0)
	E.set_brush_flags(b, E.brush_flag_transparent, true)
	E.set_mesh(paper_outline, 0, b)
	
	return paper
end

function create_desk()
	local desk = E.create_pivot()

	local desk_main = E.create_object("table.obj")
	local desk_outline = E.create_object("table.obj")

	E.parent_entity(desk_main, desk)
	E.parent_entity(desk_outline, desk)
	
	E.set_entity_scale(desk_outline, 1.03, 1.03, 1.03)
	b = E.create_brush()
	E.set_brush_color(b, 0.0, 0.0, 0.0, 1.0)
	E.set_brush_flags(b, E.brush_flag_transparent, true)
	E.set_mesh(desk_outline, 0, b)
	
	return desk
end

--------------------------------------------------------------------------------
-- create_gui
--	Initializes the 2D components of the view.
--------------------------------------------------------------------------------
function create_gui()
	_,_,width,height = E.get_display_union()

	-- Create gui camera
	gui = E.create_camera(E.camera_type_orthogonal)
	
	-- Create two black bands to create a fancy movie fx.
	uband = create_sprite("black.png")
	E.set_entity_position(uband, width / 2, 20, 0)
	E.set_entity_scale(uband, 50, 2, 1)
	E.parent_entity(uband, gui)

	lband = E.create_clone(uband)
	E.set_entity_position(lband, width / 2, height - 20, 0)
	E.set_entity_scale(lband, 50, 2, 1)
	E.parent_entity(lband, gui)
	
	black = create_sprite("Title.png")
	E.set_entity_position(black, width / 2, height / 2, 0)
	E.parent_entity(black, gui)
	
	lpivot = E.create_pivot()
	E.parent_entity(lpivot, gui)
	
	
	speed_text = create_gui_text("(12)Speed: "..behavior.speed, 0, 0)
	steer_friction_text = create_gui_text("(34)Steer Friction: "..behavior.steer_friction, 0, 20)
	coordination_text = create_gui_text("(56)Coordination: "..behavior.coordination, 200, 0)
	coordination_dist_text = create_gui_text("(78)Coordination Distance: "..behavior.coordination_dist, 200, 20)
	avoidance_dist_text = create_gui_text("(90)Avoidance Distance: "..behavior.avoidance_dist, 400, 0)
	
	upivot = E.create_pivot()
	E.parent_entity(upivot, gui)
	
	behavior_head_text = create_gui_text("Current behavior", 5, 15)
	E.parent_entity(behavior_head_text, upivot)
	behavior_text = create_gui_text("Default", 20, -10)
	E.parent_entity(behavior_text, upivot)
	E.set_entity_scale(behavior_text, 32, 32, 1)
	set_text_color(behavior_text, 1, 0.2, 0.2)
end

function create_gui_text(s, x, y)
	local s = create_string(s, "seguibk.ttf", 0.02)
	E.set_entity_position(s, x, y, 1) 
	E.set_entity_scale(s, 15, 15, 1)
	E.parent_entity(s, lpivot)
	set_text_color(s, 1, 1, 1)
	return s
end

--------------------------------------------------------------------------------
function animate_camera()
	local scroll_x = 0
	local scroll_y = 0
	if rotate then
		camera_angle_y = camera_angle_y + delta_x
	elseif zoom then
		camera_dist = camera_dist + delta_y
	elseif move then
		scroll_x = delta_x*camera_dist/100
		scroll_y = delta_y*camera_dist/100
	end
	
	delta_x = 0
	delta_y = 0
	
	local s = math.sin(math.rad(camera_angle_y))
	local c = math.cos(math.rad(camera_angle_y))
	camera_x = camera_x + scroll_x*c + scroll_y*s
	camera_z = camera_z + scroll_x*(-s) + scroll_y*c
	E.set_entity_position(
		camera, 
		camera_x + s * camera_dist, 
		camera_dist, 
		camera_z + c * camera_dist)
	E.set_entity_rotation(camera, -45, camera_angle_y, 0)
end

--------------------------------------------------------------------------------
-- create_text
--	Creates the 3D text on the paper.
--------------------------------------------------------------------------------
function create_text(s)
	-- Position of the currect text character.
	local x = 0
	local z = 0
	
	-- Iterate through the entire string and generate a single sprite for
	-- each character in it.
	local l = string.len(s)
	for i = 1, l do
		local c = string.sub(s, i, i)
		if c == "\n" then
			z = z + 1.5
			x = 0
		elseif c == " " then
			x = x + 0.5
		else	
			local o
			for i,v in ipairs(boid_chars) do
				if c == v then
					o, xc = create_boid(c)
					break
				end
			end
			if o == nil then
				o, xc = create_nonboid(c)
			end
			o.position = {x - 9.5, z - 13.5}
			o.direction = {0, -1}
			o.transition = 0
			E.parent_entity(o.e, camera)
			E.set_entity_position(o.e, x - 9.5, 0, z - 13.5)
			E.set_entity_rotation(o.e, -90, 0, 0)
			E.set_entity_scale(o.e, 0.8, 0.8, 0.8)
				
			local x1,y1,z1,x2,y2,z2 = E.get_entity_bound(o.e)
			x = x + math.abs(x1- x2)
		end
	end
end

--------------------------------------------------------------------------------
function create_boid(c)
	boid = {}
	boid.height = 5
	boid.e = create_string(c, "seguibd.ttf",0)
	table.insert(boids, boid)
	return boid
end

--------------------------------------------------------------------------------
function create_nonboid(c)
	nonboid = {}
	nonboid.e = create_string(c, "seguibd.ttf",0)
	table.insert(nonboids, nonboid)
	return nonboid
end

--------------------------------------------------------------------------------
function animate_nonboid(nb)
	local x, z = unpack(nb.position)
	E.set_entity_position(nb.e, x + math.sin(time*10 +  z) / 8, 0.2, z + math.sin(time*10 + x) / 8)
end

--------------------------------------------------------------------------------
function animate_boid(boid)
	local mx, my, mz = E.get_entity_position(food_marker)
	local x, y, z = E.get_entity_position(boid.e)

	local tx = mx - x
	local tz = mz - z 
	local l = math.sqrt(tx*tx + tz*tz)
	tx = tx / l
	tz = tz / l

	local cx = 0
	local cz = 0
	
	local c = 1
	local j = 0
	for i, v in ipairs(boids) do
		if v ~= boid then
			bx, by, bz = E.get_entity_position(v.e)
			local dx = bx - x
			local dz = bz - z
			l = math.sqrt(dx*dx + dz*dz)
			if l < behavior.avoidance_dist then
				c = c + 1
				local nx = dx / l
				local nz = dz / l
				tx = tx - nx
				tz = tz - nz
			end
			if l < behavior.coordination_dist then
				j = j + 1
				cx = cx + v.direction[1]
				cz = cz + v.direction[2]
			end
		end
	end
	
	-- calculate target vector
	tx = tx / c
	tz = tz / c
	l  = math.sqrt(tx*tx + tz*tz)
	tx = tx / l
	tz = tz / l
		
	-- calculate coordination vector
	if j ~= 0 then
		cx = cx / j
		cz = cz / j
		l  = math.sqrt(cx*cx + cz*cz)
		cx = cx / l
		cz = cz / l
	end
	
	local px, py, pz = E.get_entity_position(predator_marker)
	px = x - px
	pz = z - pz
	l  = -math.sqrt(px*px + pz*pz) / 5
	px = px / l^4
	pz = pz / l^4

	local px2, py2, pz2 = E.get_entity_position(cup)
	px2 = x - px2
	pz2 = z - pz2
	l  = -math.sqrt(px2*px2 + pz2*pz2) / 3
	px2 = px2 / l^8
	pz2 = pz2 / l^8
	
	-- blend vectors together (steer vector)
	local sx = tx * (1 - behavior.coordination) + cx * behavior.coordination + px + px2
	local sz = tz * (1 - behavior.coordination) + cz * behavior.coordination + pz + pz2

	steer_boid(boid, {sx, sz})
end

--------------------------------------------------------------------------------
function move_boid(boid, speed)
	local l = speed * delta * behavior.speed
	local x, y, z = E.get_entity_position(boid.e)
	x = x + boid.direction[1] * l
	z = z + boid.direction[2] * l
	E.set_entity_position(boid.e, x, y, z)
	--boid.height = y
end

--------------------------------------------------------------------------------
function steer_boid(boid, steer_vector)
	local s = behavior.steer_friction - behavior.optimization
	if s < 1 then
		s = 1
	end
	boid.direction = v_norm(v_mult(v_add(v_mult(boid.direction, s - 1), steer_vector), 1 / s)) 
	
	local angle = 0
	local a1 = math.deg(math.acos(boid.direction[1]))
	local a2 = math.deg(math.asin(boid.direction[2]))
	if a2 > 0 then
		if a1 > 90 then
			angle = 180 - a2
		else
			angle = a1
		end
	else
		if a1 > 90 then
			angle = - a1
		else
			angle = a2
		end
	end
	E.set_entity_rotation(boid.e, 90, 0, 90 + angle)
end

--------------------------------------------------------------------------------
function animate_boid_transition(v)
	local nbx, nby, nbz = E.get_entity_position(v.e)
	E.set_entity_position(v.e, nbx, v.transition, nbz)
end

--------------------------------------------------------------------------------
function animate_nonboid_transition(v)
	local nbx, nby, nbz = E.get_entity_position(v.e)
	local y = 1 - v.transition * 0.8
	local x = 1 + v.transition
	E.set_entity_scale(v.e, x, y, 1)
	
	--local b = E.get_mesh(v.e, 0)
	--E.set_brush_color(b, 0, 0, v.transition, 1.0)
	--E.set_string_fill(v.e, b)
end

--------------------------------------------------------------------------------
function do_point(x, y)
	delta_x = x
	delta_y = y
	mouse_x = mouse_x + x
	mouse_y = mouse_y + y
	
	local v = {E.get_camera_vector(camera, mouse_x, mouse_y)}
	local p = {E.get_entity_position(camera)}

	-- Recalculate the map pointer vector.
	-- Compute the point of intersection between the mouse ray and the 
	-- map plane. In this version of the code, the map is assumed to 
	-- be a perfect plane, defined by the point {0, 0, 0} and the 
	-- normal {0, 1, 0}
	local  n = {0, 1, 0}
	local  s = -v_dot(n, p) / v_dot(n, v)
	pointer = v_add({p[1], p[3]}, v_mult({v[1], v[3]}, s))	
	
	if selected ~= nil then
		E.set_entity_position(selected, pointer[1], 0.1, pointer[2])
	end
end

--------------------------------------------------------------------------------
function do_click(b, s)
	if b == 1 and s then
		if state ~= state_begin then
			-- Enable the mouse ray.
			local v = {E.get_camera_vector(camera, mouse_x, mouse_y)}
			local p = {E.get_entity_position(camera)}
			E.set_entity_geom_type(
				mouse_ray, 
				E.geom_type_ray, 
				p[1], p[2], p[3],
				v[1]*100, v[2]*100, v[3]*100)

			E.set_entity_geom_attr(mouse_ray, E.geom_attr_callback, 1)
		else
			state = state_intro
			time = 0
		end
	elseif b == 1 and not s then
		selected = nil
	end
end

--------------------------------------------------------------------------------
function do_keyboard(b, s)
	if b == E.key_z and s then
		zoom = true
	end
	if b == E.key_z and not s then
		zoom = false
	end
	if b == E.key_x and s then
		rotate = true
	end
	if b == E.key_x and not s then
		rotate = false
	end
	if b == E.key_c and s then
		move = true
	end
	if b == E.key_c and not s then
		move = false
	end
	if b == E.key_space and s then
		show_gui = not show_gui 
	end
	if b == E.key_n and s then
		behavior = behavior.next
	end
	if b == E.key_1 and s then
		behavior.speed = behavior.speed + 1
	end
	if b == E.key_2 and s then
		behavior.speed = behavior.speed - 1
	end
	if b == E.key_3 and s then
		behavior.steer_friction = behavior.steer_friction + 1
	end
	if b == E.key_4 and s then
		behavior.steer_friction = behavior.steer_friction - 1
	end
	if b == E.key_5 and s then
		behavior.coordination = behavior.coordination + 0.1
	end
	if b == E.key_6 and s then
		behavior.coordination = behavior.coordination - 0.1
	end
	if b == E.key_7 and s then
		behavior.coordination_dist = behavior.coordination_dist + 0.5
	end
	if b == E.key_8 and s then
		behavior.coordination_dist = behavior.coordination_dist - 0.5
	end
	if b == E.key_9 and s then
		behavior.avoidance_dist = behavior.avoidance_dist + 0.5
	end
	if b == E.key_0 and s then
		behavior.avoidance_dist = behavior.avoidance_dist - 0.5
	end
	if b == E.key_s and s and state == state_idle then
		state = state_animation
	end
	
	if b == E.key_t and s then
		optimization =  optimization + 1
		E.print_console(optimization.."\n")
	end
	if b == E.key_u and s then
		optimization =  optimization - 1
		E.print_console(optimization.."\n")
	end
	reset_gui_text()
end

function reset_gui_text()
	E.set_string_text(avoidance_dist_text, "(90)Avoidance Distance: "..behavior.avoidance_dist)
	E.set_string_text(coordination_dist_text, "(78)Coordination Distance: "..behavior.coordination_dist)
	E.set_string_text(coordination_text, "(56)Coordination: "..behavior.coordination)
	E.set_string_text(steer_friction_text, "(34)Steer Friction: "..behavior.steer_friction)
	E.set_string_text(speed_text, "(12)Speed: "..behavior.speed)
	E.set_string_text(behavior_text, behavior.name)
end

--------------------------------------------------------------------------------
-- do_contact
--	Electro contact callback
--------------------------------------------------------------------------------
function do_contact(a, b, px, py, pz, nx, ny, nz, d)
	if selected == nil then
		local t = nil
		if a == mouse_ray then
			t = b
		else
			t = a
		end
		
		selected = t
		
		-- disable mouse ray.
		E.set_entity_geom_type(
			mouse_ray, 
			E.geom_type_ray, 
			0, 0, 0,
			0, 0, 0)
	end
end

--------------------------------------------------------------------------------
function do_timer(dt)
	delta = dt
	time = time + dt
	
	if show_gui then
		local x = E.get_entity_position(lpivot)
		x = x * 9  / 10
		E.set_entity_position(lpivot, x, 15, 1)
		E.set_entity_position(upivot, x, height - 30, 1)
	else
		local x = E.get_entity_position(lpivot)
		x = (x*9 - 800) / 10
		E.set_entity_position(lpivot, x, 15, 1)
		E.set_entity_position(upivot, x, height - 30, 1)
	end
	
	animate_camera()
	local c = optimization_window
	if state == state_animation then
		for i, v in ipairs(boids) do
			if v.transition < 0.99 then
				v.transition = v.transition + delta / 2
				animate_boid_transition(v)
			else
				transition = 1
			end
			
			if c == behavior.optimization then
				c = 0
				animate_boid(v)
			else
				c = c + 1
			end
			move_boid(v, v.transition)
	 	end
		for i, v in ipairs(nonboids) do
			if v.transition < 0.99 then
				v.transition = v.transition + delta / 2
				animate_nonboid_transition(v)
			else
				transition = 1
			end
			animate_nonboid(v)
	 	end
	elseif state == state_intro then
		if time > 10 then
			state = state_idle
			E.delete_entity(black)
		else
			E.set_entity_alpha(black, 1 - time / 2)
			local s = (camera_dist - 30)*dt
			if s > 1 then 
				s = 1
			end
			camera_dist = camera_dist - s
		end
	end
	
	optimization_window = optimization_window + 1
	if optimization_window > behavior.optimization then
		optimization_window = 0
	end
end

--------------------------------------------------------------------------------
function create_string(text, font,outline)
    local string = E.create_string(text)
	
    E.set_typeface(font, 0.00001, outline)

    local text_line = E.create_brush()
    local text_fill = E.create_brush()

    E.set_brush_flags(text_line, E.brush_flag_unlit, true)
    E.set_brush_flags(text_fill, E.brush_flag_unlit, true)

    E.set_brush_color(text_line, 0.0, 0.0, 0.0, 0.5)
    E.set_brush_color(text_fill, 0.0, 0.0, 0.0, 1.0)
	
    E.set_string_line(string, text_line)
    E.set_string_fill(string, text_fill)

	return string
end

--------------------------------------------------------------------------------
function set_text_color(text, r, g, b)
    local text_line = E.create_brush()
    local text_fill = E.create_brush()

    E.set_brush_flags(text_line, E.brush_flag_unlit, true)
    E.set_brush_flags(text_fill, E.brush_flag_unlit, true)

    E.set_brush_color(text_line, r, g, b, 0.5)
    E.set_brush_color(text_fill, r, g, b, 1.0)
	
    E.set_string_line(text, text_line)
    E.set_string_fill(text, text_fill)
end

--------------------------------------------------------------------------------
function create_sprite(filename)
    local image  = E.create_image(filename)
    local brush  = E.create_brush()
    E.set_brush_image(brush, image)
    E.set_brush_flags(brush, E.brush_flag_unlit, true)
    E.set_brush_flags(brush, E.brush_flag_transparent, true)
    local sprite = E.create_sprite(brush)

	return sprite
end
	
--------------------------------------------------------------------------------
function v_len(v) 
	return math.sqrt(v[1]*v[1] + v[2]*v[2])
end

--------------------------------------------------------------------------------
function v_add(a, b)
	return {a[1]+b[1], a[2]+b[2]}
end

--------------------------------------------------------------------------------
function v_sub(a, b)
	return {a[1]-b[1], a[2]-b[2]}
end

--------------------------------------------------------------------------------
function v_mult(v, c)
	return {v[1]*c, v[2]*c}
end

--------------------------------------------------------------------------------
function v_norm(v)
	local l = v_len(v)
	return {v[1]/l, v[2]/l}
end

--------------------------------------------------------------------------------
function v_dot(a, b)
	return a[1]*b[1] + a[2]*b[2] + a[3]*b[3]
end


function load(txt)
	state = state_idle
	
	for i,v in ipairs(boids) do
		E.delete_entity(v.e)
	end
	
	for i, v in ipairs(nonboids) do
		E.delete_entity(v.e)
	end
	
	boids = {}
	nonboids = {}
	
	dofile(txt)
end

--------------------------------------------------------------------------------
init_scene()
