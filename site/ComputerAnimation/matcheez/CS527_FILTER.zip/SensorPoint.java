
public class SensorPoint {
	private float[] xyz = new float[3];
	private int[] angles = new int[3];
	
	public SensorPoint(String x, String y, String z, String yaw, String roll, String pitch) {
		xyz[0] = getPosition(x);
		xyz[1] = getPosition(y);
		xyz[2] = getPosition(z);
		angles[0] = getAngle(yaw);
		angles[1] = getAngle(roll);
		angles[2] = getAngle(pitch);
	}
	
	public SensorPoint(String x) {
		xyz[0] = getPosition(x);
	}
	
	public void setData(String data, int type) {
		switch (type) {
		case 1:
			xyz[0] = getPosition(data);
			break;
		case 2:
			xyz[1] = getPosition(data);
			break;
		case 3:
			xyz[2] = getPosition(data);
			break;
		case 4:
			angles[0] = getAngle(data);
			break;
		case 5:
			angles[1] = getAngle(data);
			break;
		case 6:
			angles[2] = getAngle(data);
			break;
		}
	}
	
	public void setAngles(int[] angles) {
		this.angles = angles;
	}

	public void setXyz(float[] xyz) {
		this.xyz = xyz;
	}

	public int[] getAngles() {
		return angles;
	}

	public float[] getXyz() {
		return xyz;
	}
	
	public String pointToString() {
		String result = "";
		for(int i = 0; i < 3; i++) {
			if(xyz[i] < 0) {
				result = result + " ";
				result = result + String.valueOf(xyz[i]);
				for(int k = 0; k < (5 - String.valueOf(xyz[i]).length()); k++) {
					result = result + "0";
				}
			} else {
				result = result + "  ";
				result = result + String.valueOf(xyz[i]);
				for(int k = 0; k < (4 - String.valueOf(xyz[i]).length()); k++) {
					result = result + "0";
				}
			}
		}
		result = result + "  ";
		for(int i = 0; i < 3; i++) {
			String temp = String.valueOf(angles[i]).trim();
			if(angles[i] < 0) {
				result = result + " ";
				for(int k = 0; k < (4 - temp.length()); k++) {
					result = result + " ";
				}
			} else {
				result = result + "  ";
				for(int k = 0; k < (3 - temp.length()); k++) {
					result = result + " ";
				}
			}
			result = result + temp;
		}
		result = result + "    ";
		return result;
	}

	private float getPosition(String pos) {
		Float number = new Float(pos);
		return number.floatValue();
	}
	
	private int getAngle(String angle) {
		Integer number = new Integer(angle);
		return number.intValue();
	}

}
