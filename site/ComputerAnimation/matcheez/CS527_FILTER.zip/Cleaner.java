import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JFrame;


@SuppressWarnings("serial")
public class Cleaner extends JFrame {
	private Vector[] data = new Vector[5];

	@SuppressWarnings("unchecked")
	public Cleaner() {
		JFileChooser fc = new JFileChooser();
		fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int result = fc.showOpenDialog(this);
		if(result == JFileChooser.CANCEL_OPTION) {
			this.dispose();
			return;
		}
		File[] fileArray = (fc.getSelectedFile()).listFiles();
		BufferedReader buffRead;
		BufferedWriter buffWrite;
		String currLine;
		StringTokenizer stringTok;
		String currData;
		for(int i = 0; i < fileArray.length; i++) {
			for(int w = 0; w < 5; w++) {
				data[w] = new Vector(); 
			}
			try {
				buffRead = new BufferedReader(new FileReader(fileArray[i]));
				currLine = buffRead.readLine();
				int counter = 0;
				int vectorCounter = 1;
				while(currLine != null) {
					stringTok = new StringTokenizer(currLine);
					SensorPoint sp = null;
					while(stringTok.hasMoreTokens()) {
						currData = stringTok.nextToken().trim();
						switch (counter) {
						case 0:
							data[0].add(new Float(currData));
							break;
						case 1:
							sp = new SensorPoint(currData);
							break;
						case 6:
							sp.setData(currData, counter);
							counter = 0;
							data[vectorCounter].add(sp);
							vectorCounter++;
							break;
						default:
							sp.setData(currData, counter);
							break;
						}
						counter++;
					}
					currLine = buffRead.readLine();
					counter = 0;
					vectorCounter = 1;
				}
				buffRead.close();
				
				for(int h = 0; h < 4; h++) {
					if (h !=0){
						Filter f = new Filter(data[0], data[h + 1], 8);
						data[h + 1] = f.getData();
					}
					if (h == 3){
						Filter f = new Filter(data[0], data[h + 1], 128);
						data[h + 1] = f.getData();				
					}
					if((fileArray[i].getName().equals("match_04_01")) && (h == 0)){
						FilterSp f = new FilterSp(data[0], data[h + 1], 32);
						data[h + 1] = f.getData();
					}
				}				
				
				buffWrite = new BufferedWriter(new FileWriter(fileArray[i].getPath() + "_ok"));
				String temp;
				for(int j = 0; j < data[0].size(); j++) {
					temp = ((Float)data[0].get(j)).toString();
					currLine = temp;
					for(int k = 0; k < (10 - temp.length()); k++) {
						currLine = currLine + " ";
					}
					for(int z = 0; z < 4; z++) {
						currLine = currLine + ((SensorPoint)data[z + 1].get(j)).pointToString();
					}
					buffWrite.write(currLine, 0, currLine.length());
					buffWrite.newLine();
					buffWrite.flush();
				}
				buffWrite.close();
			} catch(FileNotFoundException e) {
				e.printStackTrace();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
		this.dispose();
	}

	public static void main(String[] args) {
		new Cleaner();
	}

}
