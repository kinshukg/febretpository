/*
 * Implements a FIR filter of n coefficientes
 * In this case the number of coefficients are SAMPLES and
 * all have the same weight.
 * Special purpose!!!
 * 
 * */

import java.util.Vector;

public class FilterSp {
	private Vector outputData;
	private Vector time;
	private int SAMPLES; //32 still movement in <4>, loosing movement of head |8 128|

	public FilterSp(Vector time, Vector inputData, int actualSamples) {
		// temp vars
		SensorPoint tempPoint;
		float[] tempFlArr01, tempFlArr02;
		int[] tempIntArr01, tempIntArr02;
		
		// creation of dara structures
		SAMPLES = actualSamples;
		this.time = time;
		outputData = new Vector(inputData.size());
		
		// Filter
		for (int i = 0; i < inputData.size(); i++){
			if ((i < (int)(inputData.size() * 0.62)) || (i > (int)(inputData.size() * 0.87))){
				// equal
				outputData.add(i, inputData.get(i)); 
			}else{
				//create the point all zero
				tempPoint = new SensorPoint("0", "0", "0", "0", "0", "0");
				
				tempFlArr02 = tempPoint.getXyz();
				// Positions
				for (int j = 0; j < SAMPLES; j++){
					tempFlArr01 = ((SensorPoint)inputData.get(i-j)).getXyz();
					for (int k = 0; k < 3; k++){
						tempFlArr02[k] = tempFlArr01[k] + tempFlArr02[k];
					} // add the values										
				}
				for (int k = 0; k < 3; k++){
					tempFlArr02[k] = tempFlArr02[k]/SAMPLES;
				} // same weight of coefficients;
				tempPoint.setXyz(tempFlArr02);
								
				// Angles
				tempIntArr02 = tempPoint.getAngles();
				for (int j = 0; j <= SAMPLES; j++){
					tempIntArr01 = ((SensorPoint)inputData.get(i-j)).getAngles();					
					for (int k = 0; k < 3; k++){
						tempIntArr02[k] = tempIntArr01[k] + tempIntArr02[k];
					} // add the values
				}
				for (int k = 0; k < 3; k++){
					tempIntArr02[k] = (int)(tempIntArr02[k]/SAMPLES);
				} // same weight of coeficients
				tempPoint.setAngles(tempIntArr02);
				
				outputData.add(i, tempPoint);
				
			} // end if()
		} // end for (i..)		
	}

	public Vector getData() {
		return outputData;
	}

}
