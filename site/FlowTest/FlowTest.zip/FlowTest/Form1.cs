using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;

namespace FlowTest
{
    public partial class Form1 : Form
    {
        private int myGridHeight;
        private int myGridWidth;
        private List<Particle> myParticleList;

        private float[,] myPressureTable;
        private Random myRandom;

        private Bitmap myBackground;
        private bool myRefreshBackground = true;

        public Form1()
        {
            InitializeComponent();

            myParticleList = new List<Particle>();
            myRandom = new Random();

            myGridHeight = 10;
            myGridWidth = 10;

            myPressureTable = new float[myGridWidth, myGridHeight];

            for (int x = 0; x < myGridWidth; x++)
            {
                for (int y = 0; y < myGridHeight; y++)
                {
                    myPressureTable[x, y] = 2;
                }
            }
            myPressureTable[3, 0] = 1;
            myPressureTable[9, 9] = -1;

            myPressureTable[7, 0] = -1;
            myPressureTable[0, 5] = 1;

            redrawBackgroundBitmap();
        }


        private void addPressure(int x, int y, ref float accum, ref int counter)
        {
            if (x >= 0 && x < myGridWidth
                && y >= 0 && y < myGridHeight)
            {
                if (myPressureTable[x, y] != 2)
                {
                    accum += myPressureTable[x, y];
                    counter++;
                }
            }
        }

        void recomputePressureLevels()
        {
            bool done = false;
            int iterations = 0;
            Console.WriteLine("Starting pressure level recomputing...");
            Stopwatch sw = new Stopwatch();
            sw.Start();

            while (!done)
            {
                float[,] newPressureTable = new float[myGridWidth, myGridHeight];

                for (int x = 0; x < myGridWidth; x++)
                {
                    for (int y = 0; y < myGridHeight; y++)
                    {
                        if (myPressureTable[x, y] != 1 &&
                            myPressureTable[x, y] != -1 &&
                            myPressureTable[x, y] != 2)
                        {
                            float accum = 0;
                            int counter = 0;


                            addPressure(x, y + 1, ref accum, ref counter);
                            addPressure(x, y - 1, ref accum, ref counter);
                            addPressure(x, y, ref accum, ref counter);
                            addPressure(x - 1, y, ref accum, ref counter);
                            addPressure(x + 1, y, ref accum, ref counter);

                            newPressureTable[x, y] = accum / counter;

                        }
                        else
                        {
                            newPressureTable[x, y] = myPressureTable[x, y];
                        }

                    }
                }

                done = true;
                for (int x = 0; x < myGridWidth; x++)
                {
                    for (int y = 0; y < myGridHeight; y++)
                    {
                        if (Math.Abs(myPressureTable[x, y] - newPressureTable[x, y]) > 0.001)
                        {
                            done = false;
                            break;
                        }
                    }

                    if (!done)
                    {
                        break;
                    }
                }

                myPressureTable = newPressureTable;

                iterations++;
            }

            sw.Stop();
            Console.WriteLine(
                "Pressure level computation ended: {0} iterations, {1} ms",
                iterations, sw.ElapsedMilliseconds);

        }

        private float tilePressure(int x, int y)
        {
            if (x >= 0 && x < myGridWidth
                && y >= 0 && y < myGridHeight)
            {
                return myPressureTable[x, y];
            }

            return 2;
        }

        public void recomputeParticleSpeeds()
        {
            int stepX = ClientSize.Width / myGridWidth;
            int stepY = ClientSize.Height / myGridHeight;

            foreach (Particle p in myParticleList)
            {
                if (p.Life < 255)
                {
                    p.Life++;
                }
                if (!p.Moving)
                {
                    float curPressure = tilePressure(p.Tile.X, p.Tile.Y);

                    float u = curPressure - tilePressure(p.Tile.X, p.Tile.Y - 1);
                    float d = curPressure - tilePressure(p.Tile.X, p.Tile.Y + 1);
                    float l = curPressure - tilePressure(p.Tile.X - 1, p.Tile.Y);
                    float r = curPressure - tilePressure(p.Tile.X + 1, p.Tile.Y);

                    u = Math.Max(0, u /*> 0 ? 1 : -1*/);
                    d = Math.Max(0, d /*> 0 ? 1 : -1*/);
                    l = Math.Max(0, l /*> 0 ? 1 : -1*/);
                    r = Math.Max(0, r /*> 0 ? 1 : -1*/);

                    float s = u + d + l + r;

                    if (s > 0)
                    {
                        float rnd = (float)myRandom.NextDouble() * s;

                        Point newPoint = new Point(
                            myRandom.Next(0, stepX),
                            myRandom.Next(0, stepY));

                        p.Moving = true;
                        p.Start = p.Stop;
                        if (rnd < u)
                        {
                            p.Tile.Y = p.Tile.Y - 1;
                        }
                        else if (rnd >= u && rnd < u + d)
                        {
                            p.Tile.Y = p.Tile.Y + 1;
                        }
                        else if (rnd >= u + d && rnd < u + d + l)
                        {
                            p.Tile.X = p.Tile.X - 1;
                        }
                        else if (rnd >= u + d + l && rnd < u + d + l + r)
                        {
                            p.Tile.X = p.Tile.X + 1;
                        }

                        p.Stop.X = newPoint.X + p.Tile.X * stepX;
                        p.Stop.Y = newPoint.Y + p.Tile.Y * stepY;
                        PointF diff = new PointF(
                            p.Stop.X - p.Start.X,
                            p.Stop.Y - p.Start.Y);
                        p.Speed.X = diff.X / (Math.Abs(diff.X) + Math.Abs(diff.Y)) * 3;
                        p.Speed.Y = diff.Y / (Math.Abs(diff.X) + Math.Abs(diff.Y)) * 3;
                    }
                }
            }
        }
        
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            int stepX = ClientSize.Width / myGridWidth;
            int stepY = ClientSize.Height / myGridHeight;

            int x = e.X / stepX;
            int y = e.Y / stepY;

            if (e.Button == MouseButtons.Left)
            {
                Graphics g = CreateGraphics();

                if (myPressureTable[x, y] == 2)
                {
                    myPressureTable[x, y] = 0;
                    g.FillRectangle(
                        Brushes.Black,
                        x * stepX + 1,
                        y * stepY + 1,
                        stepX - 1,
                        stepY - 1);
                }
                else
                {
                    myPressureTable[x, y] = 2;
                    g.FillRectangle(
                        Brushes.LightGray,
                        x * stepX + 1,
                        y * stepY + 1,
                        stepX - 1,
                        stepY - 1);
                }

                recomputePressureLevels();
                redrawBackgroundBitmap();
                Refresh();
            }
            else
            {
                if(myPressureTable[x, y] != 2)
                {
                    Particle p = new Particle();
                    p.Tile  = new Point(x, y);
                    p.Stop = new Point(e.X, e.Y);
                    myParticleList.Add(p);
                }
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int count = 0;
            int stepX = this.ClientSize.Width / myGridWidth;
            int stepY = this.ClientSize.Height / myGridHeight;

            List<Particle> deadParticles = new List<Particle>();
            recomputeParticleSpeeds();

            if (myRandom.Next(0, 2) > 0)
            {
                for (int x = 0; x < myGridWidth; x++)
                {
                    for (int y = 0; y < myGridHeight; y++)
                    {
                        if (myPressureTable[x, y] == 1)
                        {
                            for (int c = 0; c < 3; c++)
                            {
                                Particle p = new Particle();
                                p.Tile.X = x;
                                p.Tile.Y = y;
                                p.Stop.X = x * stepX + myRandom.Next(4, stepX - 4);
                                p.Stop.Y = y * stepY + myRandom.Next(4, stepY - 4);
                                myParticleList.Add(p);
                            }
                        }
                    }
                }
            }

            foreach (Particle p in myParticleList)
            {
                count++;
                if (p.Moving)
                {
                    p.Old = p.Start;
                    PointF old = p.Start;
                    p.Start.X += p.Speed.X;
                    p.Start.Y += p.Speed.Y;
                    if (Math.Sign(p.Start.X - p.Stop.X) != Math.Sign(old.X - p.Stop.X)
                        || Math.Sign(p.Start.Y - p.Stop.Y) != Math.Sign(old.Y - p.Stop.Y))
                    {
                        p.Moving = false;
                        if (myPressureTable[p.Tile.X, p.Tile.Y] == -1)
                        {
                            deadParticles.Add(p);
                        }
                    }
                }
            }

            this.Text = "Blood particles: " + count.ToString();

            foreach (Particle p in deadParticles)
            {
                myParticleList.Remove(p);
            }

            redrawBlood();
        }

        private void redrawBackgroundBitmap()
        {
            myBackground = new Bitmap(
                ClientRectangle.Width,
                ClientRectangle.Height);

            Graphics g = Graphics.FromImage(myBackground);

            int stepX = this.ClientSize.Width / myGridWidth;
            int stepY = this.ClientSize.Height / myGridHeight;

            for (int x = 0; x <= Width; x += stepX)
            {
                //g.DrawLine(Pens.Yellow, x, 0, x, Height - (Height % stepY));
            }
            for (int y = 0; y <= Height; y += stepY)
            {
                //g.DrawLine(Pens.Yellow, 0, y, Width - (Width % stepX), y);
            }

            for (int x = 0; x < myGridWidth; x++)
            {
                for (int y = 0; y < myGridHeight; y++)
                {
                    if (myPressureTable[x, y] == 2)
                    {
                        g.FillRectangle(
                            Brushes.LightGray,
                            x * stepX,
                            y * stepY,
                            stepX,
                            stepY);
                    }
                    else
                    {
                        g.FillRectangle(
                            Brushes.Black,
                            x * stepX,
                            y * stepY,
                            stepX,
                            stepY);

                        /*g.DrawString(
                            myPressureTable[x, y].ToString("F2"),
                            this.Font,
                            Brushes.White,
                            x * stepX + 2,
                            y * stepY + 2);*/
                    }
                }
            }

            g.Dispose();

            myRefreshBackground = true;
        }

        private void redrawBlood()
        {
            Graphics g = CreateGraphics();

            if (myRefreshBackground)
            {
                myRefreshBackground = false;
                g.DrawImage(myBackground, Point.Empty);
            }

            int stepX = this.ClientSize.Width / myGridWidth;
            int stepY = this.ClientSize.Height / myGridHeight;

            foreach (Particle p in myParticleList)
            {
                Pen pen = new Pen(Color.FromArgb(255 - p.Life, 0, Math.Max(0, p.Life - 128)));
                g.DrawRectangle(pen, p.Start.X, p.Start.Y, 1, 1);
                g.DrawRectangle(Pens.Black, p.Old.X, p.Old.Y, 1, 1);
            }

            g.Dispose();
        }
    }

    class Particle
    {
        public bool Moving;
        public PointF Old;
        public PointF Start;
        public Point Stop;
        public Point Tile;
        public PointF Speed;
        public int Life;
    }
}